/**
*  BPO 플랫폼
*  @FileName 	Chart.js 
*  @Creator 	PJY
*  @CreateDate 	2019.10.10
*  @Desction    [참고] http://demo.riamore.net/HTML5demo/chart/index.html
************** 소스 수정 이력 ***********************************************
*  date          		Modifier                Description
*******************************************************************************
*  2019.10.10     		PJY       	      		최초 생성
*******************************************************************************
*/

var pForm = nexacro.Form.prototype;

// rMateChart 라이선스 : 2019/12/31까지 사용 가능
pForm.rMateChartH5License = "7284d56a46146a08aff022461013f735a188fbf0d1460eb46f75ee69c8a428e1:3200630b3648443a4f4220504c2056463a3332302e33302d2032503756303a31432d35362d4345324e442d2d36452e3730322d30453a564c41204c312033452f4c323a31742f203943313a303232303a31453920302a393a324833";

// 차트 공통 스타일
pForm.gvComChartStyle = "backgroundColor='#FFFFFF' borderStyle='none' paddingTop='10' paddingBottom='10' paddingLeft='10' paddingRight='10'";

/**
 * @class 차트생성
 * @param 	{Object} objChart	차트로 그릴 WebBrowser Object
 * @return 	N/A
 * @example gfnCreateChart(objChart)
 */
pForm.gfnCreateChart = function(objChart)
{
	var sUrl = this.gfnGetServerUrl();
	
	var htmlUrl = sUrl + "/resources/libs/rMateChart/nexacroChartH5_v6.0.html";			// 차트를 그릴 html의 url
	var scriptRootUrl = sUrl + "/resources/libs/rMateChart/rMateChartH5";			// rMateChartH5의 assets과 js가 저장된 url (이 디렉토리의 아래에 JS/ 와 Assets/ 디렉토리가 있어야 함)
	
	// Form이 완성된 후 차트를 생성합니다.
	this.rMateChartCreate(objChart, scriptRootUrl, htmlUrl, this.gfnMakeChartVars());
};

/**
 * @class gfnCreateChart 함수의 내부함수
 * @param 	N/A
 * @return 	{String} 설정정보 문자열
 * @example gfnMakeChartVars()
 */
pForm.gfnMakeChartVars = function() {
	var chartVars = "";
	var rMateOnLoadCallFunction = "rMateChartOnLoad";
	chartVars += "rMateOnLoadCallFunction="+rMateOnLoadCallFunction;

	return chartVars;
};

/**
 * @class 차트 기본레이아웃 반환 함수
 * @param 	{Sring}	id - DIV chart ID
 * @param 	{Sring} sLayoutType - 차트종류(Line/Bar/Column/Pie/MultiLine/MultiBar/MultiColumn)
 * @param 	{Array} arrOption - 차트옵션(문서참조)
 * @return 	{String} 차트레이아웃 문자열
 * @example gfnGetChartLayout(id, sLayoutType, arrOption)
 */
pForm.gfnGetChartLayout = function(id, sLayoutType, arrOption)
{
	var sLayout = "";
	
	if (sLayoutType == "Line")		// 라인차트(싱글)
	{
		sLayout+= "<rMateChart " + this.gvComChartStyle + ">\n";
		sLayout+= "<Options>\n";
		
		// 제목
		if (this.gfnIsNotNull(arrOption.title)) {
			sLayout+= "<Caption text='" + arrOption.title + "' />\n";
		}
		
		// 소제목
		if (this.gfnIsNotNull(arrOption.subtitle))	{
			sLayout+= "<SubCaption text='" + arrOption.subtitle + "' textAlign='right' />\n";
		}
		
		// 범례
		if (this.gfnIsNotNull(arrOption.legendoption))	{
			sLayout+= "<Legend " + arrOption.legendoption + "/>\n";
		}
		
		sLayout+= "</Options>\n";
		sLayout+= "<NumberFormatter id='numfmt' useThousandsSeparator='true'/>\n";		// 숫자형 포멧 추가(천단위,표시)
		sLayout+= "<Line2DChart showDataTips='true' dataTipDisplayMode='axis' itemClickJsFunction='chartClick'>\n";
		
		// X축 설정
		sLayout+= "<horizontalAxis>\n";
		sLayout+= "<CategoryAxis categoryField='" + arrOption.xfield + "'/>\n";
		sLayout+= "</horizontalAxis>\n";
		
		// Y축 설정
		sLayout+= "<verticalAxis>\n";
		sLayout+= "<LinearAxis formatter='{numfmt}'";
		if (this.gfnIsNotNull(arrOption.yaxisoption)) {
			sLayout+= " " + arrOption.yaxisoption;
		}
		sLayout+= " />\n";
		sLayout+= "</verticalAxis>\n";
		
		sLayout+= "<series>\n";
		
		// Y축 값 설정
		sLayout+= "<Line2DSeries id='" + arrOption.yfield + "' yField='" + arrOption.yfield + "' displayName='" + arrOption.displayName + "'  itemRenderer='CircleItemRenderer'";
		if (this.gfnIsNotNull(arrOption.seriesoption)) {
			sLayout+= " " + arrOption.seriesoption;
		}
		sLayout+= " >\n";
		
		sLayout+= "<showDataEffect>\n";
		sLayout+= "<SeriesInterpolate/>\n";
		sLayout+= "</showDataEffect>\n";		
		sLayout+= "</Line2DSeries>\n";
		sLayout+= "</series>\n";
		sLayout+= "</Line2DChart>\n";
		sLayout+= "</rMateChart>\n";
	}	
	else if (sLayoutType == "Bar")		// 가로막대형 차트(싱글)
	{
		sLayout+= "<rMateChart " + this.gvComChartStyle + ">\n";
		sLayout+= "<Options>\n";
		
		// 제목
		if (this.gfnIsNotNull(arrOption.title)) {
			sLayout+= "<Caption text='" + arrOption.title + "' />\n";
		}
		
		// 소제목
		if (this.gfnIsNotNull(arrOption.subtitle))	{
			sLayout+= "<SubCaption text='" + arrOption.subtitle + "' textAlign='right' />\n";
		}
		
		// 범례
		if (this.gfnIsNotNull(arrOption.legendoption))	{
			sLayout+= "<Legend " + arrOption.legendoption + "/>\n";
		}
		
		sLayout+= "</Options>\n";
		sLayout+= "<NumberFormatter id='numfmt' useThousandsSeparator='true'/>\n";		// 숫자형 포멧 추가(천단위,표시)
		sLayout+= "<Bar2DChart showDataTips='true' itemClickJsFunction='chartClick'>\n";
		
		// X축 설정
		sLayout+= "<horizontalAxis>\n";
		sLayout+= "<LinearAxis formatter='{numfmt}'";
		if (this.gfnIsNotNull(arrOption.xaxisoption)) {
			sLayout+= " " + arrOption.xaxisoption;
		}
		sLayout+= " />\n";
		sLayout+= "</horizontalAxis>\n";
		
		// Y축 설정
		sLayout+= "<verticalAxis>\n";
		sLayout+= "<CategoryAxis categoryField='" + arrOption.yfield + "'/>\n";
		sLayout+= "</verticalAxis>\n";
		
		
		sLayout+= "<series>\n";
		
		// X축 값 설정
		sLayout+= "<Bar2DSeries id='" + arrOption.xfield + "' xField='" + arrOption.xfield + "' displayName='" + arrOption.xfielddisplayname + "'";
		if (this.gfnIsNotNull(arrOption.seriesoption)) {
			sLayout+= " " + arrOption.seriesoption;
		}
		sLayout+= " >\n";
		
		sLayout+= "<showDataEffect>\n";
		sLayout+= "<SeriesInterpolate/>\n";
		sLayout+= "</showDataEffect>\n";	
		sLayout+= "</Bar2DSeries>\n";
		sLayout+= "</series>\n";
		sLayout+= "</Bar2DChart>\n";
		sLayout+= "</rMateChart>\n";
		
	}
	else if (sLayoutType == "Column")		// 세로막대형 차트(싱글)
	{
		sLayout+= "<rMateChart " + this.gvComChartStyle + ">\n";
		sLayout+= "<Options>\n";
		
		// 제목
		if (this.gfnIsNotNull(arrOption.title)) {
			sLayout+= "<Caption text='" + arrOption.title + "' />\n";
		}
		
		// 소제목
		if (this.gfnIsNotNull(arrOption.subtitle))	{
			sLayout+= "<SubCaption text='" + arrOption.subtitle + "' textAlign='right' />\n";
		}
		
		// 범례
		if (this.gfnIsNotNull(arrOption.legendoption))	{
			sLayout+= "<Legend " + arrOption.legendoption + "/>\n";
		}
		
		sLayout+= "</Options>\n";
		sLayout+= "<NumberFormatter id='numfmt' useThousandsSeparator='true'/>\n";		// 숫자형 포멧 추가(천단위,표시)
		sLayout+= "<Column2DChart showDataTips='true' dataTipDisplayMode='axis' itemClickJsFunction='chartClick'>\n";
		
		// X축 설정
		sLayout+= "<horizontalAxis>\n";
		sLayout+= "<CategoryAxis categoryField='" + arrOption.xfield + "'/>\n";
		sLayout+= "</horizontalAxis>\n";
		
		// Y축 설정
		sLayout+= "<verticalAxis>\n";
		sLayout+= "<LinearAxis formatter='{numfmt}'";
		if (this.gfnIsNotNull(arrOption.yaxisoption)) {
			sLayout+= " " + arrOption.yaxisoption;
		}
		sLayout+= " />\n";
		sLayout+= "</verticalAxis>\n";
		
		sLayout+= "<series>\n";
		
		// X축 값 설정
		sLayout+= "<Column2DSeries id='" + arrOption.yfield + "' yField='" + arrOption.yfield + "' displayName='" + arrOption.displayName +"'";
		if (this.gfnIsNotNull(arrOption.seriesoption)) {
			sLayout+= " " + arrOption.seriesoption;
		}
		sLayout+= " >\n";
		
		sLayout+= "<showDataEffect>\n";
		sLayout+= "<SeriesInterpolate/>\n";
		sLayout+= "</showDataEffect>\n";	
		sLayout+= "</Column2DSeries>\n";
		sLayout+= "</series>\n";
		sLayout+= "</Column2DChart>\n";
		sLayout+= "</rMateChart>\n";
	}
	else if (sLayoutType == "Pie")			// 원차트
	{
		sLayout+= "<rMateChart " + this.gvComChartStyle + ">\n";
		sLayout+= "<Options>\n";
		
		// 제목
		if (this.gfnIsNotNull(arrOption.title)) {
			sLayout+= "<Caption text='" + arrOption.title + "' />\n";
		}
		
		// 소제목
		if (this.gfnIsNotNull(arrOption.subtitle))	{
			sLayout+= "<SubCaption text='" + arrOption.subtitle + "' textAlign='right' />\n";
		}
		
		// 범례
		if (this.gfnIsNotNull(arrOption.legendoption))	{
			sLayout+= "<Legend " + arrOption.legendoption + "/>\n";
		} else {
			sLayout+= "<Legend position='right' direction='vertical' labelPlacement='right'/>\n";		// 범례기본(우측)
		}
		
		sLayout+= "</Options>\n";
		sLayout+= "<Pie2DChart showDataTips='false' itemClickJsFunction='chartClick'>\n";
		sLayout+= "<series>\n";
		
		// 값 설정
		sLayout+= "<Pie2DSeries id='" + arrOption.field + "' nameField='" + arrOption.fieldname + "' field='" + arrOption.field + "' labelPosition='callout' startAngle='270'";
		if (this.gfnIsNotNull(arrOption.seriesoption)) {
			sLayout+= " " + arrOption.seriesoption;
		}
		sLayout+= " >\n";
		
		sLayout+= "<showDataEffect>\n";
		sLayout+= "<SeriesInterpolate duration='500'/>\n";
		sLayout+= "</showDataEffect>\n";
		sLayout+= "</Pie2DSeries>\n";
		sLayout+= "</series>\n";
		sLayout+= "</Pie2DChart>\n";
		sLayout+= "</rMateChart>\n";
	}
	else if (sLayoutType == "MultiLine")	// 멀티라인차트
	{
	    var arrYfield = arrOption.yfield.split(",");
		var arrDisplayName = arrOption.displayName.split(",");

		sLayout+= "<rMateChart " + this.gvComChartStyle + ">\n";
		sLayout+= "<Options>\n";
		
		// 제목
		if (this.gfnIsNotNull(arrOption.title)) {
			sLayout+= "<Caption text='" + arrOption.title + "' />\n";
		}
		
		// 소제목
		if (this.gfnIsNotNull(arrOption.subtitle))	{
			sLayout+= "<SubCaption text='" + arrOption.subtitle + "' textAlign='right' />\n";
		}
		
		// 범례
		if (this.gfnIsNotNull(arrOption.legendoption))	{
			sLayout+= "<Legend " + arrOption.legendoption + "/>\n";
		} else {
			sLayout+= "<Legend />\n";
		}
		
		sLayout+= "</Options>\n";
		sLayout+= "<NumberFormatter id='numfmt' useThousandsSeparator='true'/>\n";		// 숫자형 포멧 추가(천단위,표시)
		sLayout+= "<Line2DChart showDataTips='true' itemClickJsFunction='chartClick'>\n";
		
		// X축 설정
		sLayout+= "<horizontalAxis>\n";
		sLayout+= "<CategoryAxis categoryField='" + arrOption.xfield + "'/>\n";
		sLayout+= "</horizontalAxis>\n";
		
		// Y축 설정
		sLayout+= "<verticalAxis>\n";
		sLayout+= "<LinearAxis formatter='{numfmt}'";
		if (this.gfnIsNotNull(arrOption.yaxisoption)) {
			sLayout+= " " + arrOption.yaxisoption;
		}
		sLayout+= " />\n";
		sLayout+= "</verticalAxis>\n";
		
		// 시리즈 설정
		sLayout+= "<series>\n";				
		for(var i=0; i<arrYfield.length;i++)
		{
			sLayout+= "<Line2DSeries id='" + arrYfield[i] + "' yField='" + arrYfield[i] + "' displayName='" + arrDisplayName[i] + "' itemRenderer='CircleItemRenderer'";
			
			if (this.gfnIsNotNull(arrOption.arrSeriesoption)) {
				sLayout+= " " + arrOption.arrSeriesoption[i];
			} else if (this.gfnIsNotNull(arrOption.seriesoption)) {
				sLayout+= " " + arrOption.seriesoption;
			} 
			sLayout+= " >\n";
		
			sLayout+= "<showDataEffect>\n";
			sLayout+= "<SeriesInterpolate/>\n";
			sLayout+= "</showDataEffect>\n";	
			sLayout+= "</Line2DSeries>\n";
		}		
		sLayout+= "</series>\n";
		
		sLayout+= "</Line2DChart>\n";
		sLayout+= "</rMateChart>\n";
	}	
	else if (sLayoutType == "MultiBar")		// 멀티 가로막대형 차트
	{
	    var arrXfield = arrOption.xfield.split(",");
		var arrXfieldDisplayName = arrOption.xfielddisplayname.split(",");
		
		sLayout+= "<rMateChart " + this.gvComChartStyle + ">\n";
		sLayout+= "<Options>\n";
		
		// 제목
		if (this.gfnIsNotNull(arrOption.title)) {
			sLayout+= "<Caption text='" + arrOption.title + "' />\n";
		}
		
		// 소제목
		if (this.gfnIsNotNull(arrOption.subtitle))	{
			sLayout+= "<SubCaption text='" + arrOption.subtitle + "' textAlign='right' />\n";
		}
		
		// 범례
		if (this.gfnIsNotNull(arrOption.legendoption))	{
			sLayout+= "<Legend " + arrOption.legendoption + "/>\n";
		} else {
			sLayout+= "<Legend position='right' direction='vertical' labelPlacement='right'/>\n";		// 범례기본(우측)
		}
		
		sLayout+= "</Options>\n";
		sLayout+= "<NumberFormatter id='numfmt' useThousandsSeparator='true'/>\n";		// 숫자형 포멧 추가(천단위,표시)
		sLayout+= "<Bar2DChart showDataTips='true' itemClickJsFunction='chartClick'>\n";
		
		// X축 설정
		sLayout+= "<horizontalAxis>\n";
		sLayout+= "<LinearAxis formatter='{numfmt}'";
		if (this.gfnIsNotNull(arrOption.xaxisoption)) {
			sLayout+= " " + arrOption.xaxisoption;
		}
		sLayout+= " />\n";
		sLayout+= "</horizontalAxis>\n";
		
		// Y축 설정
		sLayout+= "<verticalAxis>\n";
		sLayout+= "<CategoryAxis categoryField='" + arrOption.yfield + "'/>\n";
		sLayout+= "</verticalAxis>\n";
		
		// 시리즈 설정
		sLayout+= "<series>\n";
		
		// Stacked, 100%
		if (this.gfnIsNotNull(arrOption.settype))	{
			sLayout+= "            <Bar2DSet type='" + arrOption.settype + "' ";
			
			// 옵션
			if (this.gfnIsNotNull(arrOption.setoptin))	{
				sLayout+= arrOption.settype + " >\n";
			}
			sLayout+= " >\n";
			
			sLayout+= "                <series>\n";
		}
		
		for(var i=0; i<arrXfield.length;i++)
		{						
			sLayout+= "<Bar2DSeries id='" + arrXfield[i] + "' xField='" + arrXfield[i] + "' displayName='" + arrXfieldDisplayName[i] + "'";
			
			if (this.gfnIsNotNull(arrOption.arrSeriesoption)) {
				sLayout+= " " + arrOption.arrSeriesoption[i];
			} else if (this.gfnIsNotNull(arrOption.seriesoption)) {
				sLayout+= " " + arrOption.seriesoption;
			} 
			sLayout+= " >\n";
			
			sLayout+= "<showDataEffect>\n";
			sLayout+= "<SeriesInterpolate/>\n";
			sLayout+= "</showDataEffect>\n";	
			sLayout+= "</Bar2DSeries>\n";
		}		
		
		if (this.gfnIsNotNull(arrOption.settype))	{
			sLayout+= "                </series>\n";
			sLayout+= "            </Bar2DSet>\n";
		}
		
		sLayout+= "</series>\n";
		sLayout+= "</Bar2DChart>\n";
		sLayout+= "</rMateChart>\n";
	}
	else if (sLayoutType == "MultiColumn")		// 멀티 세로막대형 차트
	{
	    var arrYfield = arrOption.yfield.split(",");
		var arrDisplayName = arrOption.displayName.split(",");

		sLayout+= "<rMateChart " + this.gvComChartStyle + ">\n";
		sLayout+= "<Options>\n";
		
		// 제목
		if (this.gfnIsNotNull(arrOption.title)) {
			sLayout+= "<Caption text='" + arrOption.title + "' />\n";
		}
		
		// 소제목
		if (this.gfnIsNotNull(arrOption.subtitle))	{
			sLayout+= "<SubCaption text='" + arrOption.subtitle + "' textAlign='right' />\n";
		}
		
		// 범례
		if (this.gfnIsNotNull(arrOption.legendoption))	{
			sLayout+= "<Legend " + arrOption.legendoption + "/>\n";
		} else {
			sLayout+= "<Legend />\n";
		}
		
		sLayout+= "</Options>\n";
		sLayout+= "<NumberFormatter id='numfmt' useThousandsSeparator='true'/>\n";		// 숫자형 포멧 추가(천단위,표시)
		sLayout+= "<Column2DChart showDataTips='true' itemClickJsFunction='chartClick'>\n";
		
		// X축 설정
		sLayout+= "<horizontalAxis>\n";
		sLayout+= "<CategoryAxis categoryField='" + arrOption.xfield + "'/>\n";
		sLayout+= "</horizontalAxis>\n";
		
		// Y축 설정
		sLayout+= "<verticalAxis>\n";
		sLayout+= "<LinearAxis formatter='{numfmt}'";
		if (this.gfnIsNotNull(arrOption.yaxisoption)) {
			sLayout+= " " + arrOption.yaxisoption;
		}
		sLayout+= " />\n";
		sLayout+= "</verticalAxis>\n";
		
		// 시리즈 설정
		sLayout+= "<series>\n";
		
		// Stacked, 100%
		if (this.gfnIsNotNull(arrOption.settype))	{
			sLayout+= "            <Bar2DSet type='" + arrOption.settype + "' ";
			
			// 옵션
			if (this.gfnIsNotNull(arrOption.setoptin))	{
				sLayout+= arrOption.settype + " >\n";
			}
			sLayout+= " >\n";
			
			sLayout+= "                <series>\n";
		}
		
		for(var i=0; i<arrYfield.length;i++)
		{
			sLayout+= "<Column2DSeries id='" + arrYfield[i] + "' yField='" + arrYfield[i] + "' displayName='" + arrDisplayName[i] + "'";
			
			if (this.gfnIsNotNull(arrOption.arrSeriesoption)) {
				sLayout+= " " + arrOption.arrSeriesoption[i];
			} else if (this.gfnIsNotNull(arrOption.seriesoption)) {
				sLayout+= " " + arrOption.seriesoption;
			} 
			sLayout+= " >\n";
			
			sLayout+= "<showDataEffect>\n";
			sLayout+= "<SeriesInterpolate/>\n";
			sLayout+= "</showDataEffect>\n";	
			sLayout+= "</Column2DSeries>\n";
		}
		
		if (this.gfnIsNotNull(arrOption.settype))	{
			sLayout+= "                </series>\n";
			sLayout+= "            </Bar2DSet>\n";
		}
		
		sLayout+= "</series>\n";
		sLayout+= "</Column2DChart>\n";
		sLayout+= "</rMateChart>\n";
	}
	
	return sLayout;
};