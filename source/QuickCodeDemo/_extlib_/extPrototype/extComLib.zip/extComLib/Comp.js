/**
*  BPO 플랫폼
*  @FileName 	Comp.js 
*  @Creator 	PJY
*  @CreateDate 	2019.06.24
*  @Desction    Grid외 컴포넌트 관련 함수
************** 소스 수정 이력 ***********************************************
*  date          		Modifier                Description
*******************************************************************************
*  2019.06.24     		PJY       	      		최초 생성
*  2019.08.02     		sepia       	      	콤보박스 셋팅 공통 함수 추가
*******************************************************************************
*/

var pForm = nexacro.Form.prototype;


/**
 * @class 해당 콤포넌트의 form으로 부터의 경로를 구하는 함수
 * @param	{Object} obj - 콤포넌트
 * @return	{String} 해당 콤포넌트의 form으로 부터의 경로
 */
pForm.gfnGetCompId = function (obj)
{
	var sCompId = obj.name;
	var objParent = obj.parent;
	
	while (true)
	{
		//trace("" + objParent + " / " + objParent.name);
		if (objParent instanceof nexacro.ChildFrame )
		{
			break;
		}
		else {
			sCompId = objParent.name + "." + sCompId;
		}
		objParent = objParent.parent;		
	}
	return sCompId;
};

/**
 * @class 전체건수 설정
 * @param	{Object} objTotalCnt - 건수 표시할 Static콤포넌트
 * @param	{Number} nTotalCount - 전체건수
 * @return	N/A
 */
pForm.gfnSetTotalCnt = function (objTotalCnt, nTotalCount)
{
	if (this.gfnIsNotNull(objTotalCnt)) {
		var nTotCnt = nexacro.toNumber(nTotalCount,0);
		var sMsg = this.gfnGetWord("GRID_TOT_CNT",["<b v='true'><fc v='#da291c'>" + (nTotCnt.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")) + "</fc></b>"]);
		
		objTotalCnt.set_fittocontents("none");
		objTotalCnt.set_text(sMsg);
		objTotalCnt.set_fittocontents("width");
	}
	
	//체크박스 해제	
	if (this.gfnIsNotNull(objTotalCnt.parent.parent.form)) {
		var components = objTotalCnt.parent.parent.form.components;
		var cnt = components.length;
		for(var i = 0 ; i < cnt ; i++) {
			var obj = components[i];
			if(obj instanceof nexacro.Grid) {
				var ds = obj.getBindDataset();
				if(obj.getCellProperty("head",0,"displaytype") == "checkboxcontrol") {
					obj.set_enableevent(false);
					obj.setCellProperty("head", 0, "text", "0");
					
					//체크박스 체크 (그리드가 전체 선택이 되어 있으면)
					if(ds.rowcount > 0 && ds.rowcount == ds.getCaseCount("CHK=='1'")) {
						obj.setCellProperty("head",0,"text","1");
					}
					
					obj.set_enableevent(true);
				}
			}
		}		
	}
};

/**
 * @class 공통코드 조회
 * @param	{Array} arrComCodeArg - 조회할 공통코드 정보
	  - cdGrpId : 공통코드 그룹ID
	  - obj     : 조회된 공통코드를 적용할 객체(Dataset/Combo). Combo 선택시 첫번째 index 자동설정
	  - firstcd : 첫번째 Row에 추가할 CD값. ex) all
	  - firstnm : 첫번째 Row에 추가할 값 ex) 전체
	  - filter : expr로 추가할 filter 문자열 ex) COMN_CD<='100'
 * @return N/A
 */
pForm.gfnSearchCommonCode = function(arrComCodeArg) 
{
	var objGdsCode = pForm.gfnGetApplication().gdsCommCode;
	
	for(var i=0; i<arrComCodeArg.length; i++)
	{
		pForm.gfnGetCommonCode(objGdsCode,arrComCodeArg[i]);
	}
};

/**
 * @class 화주사 공통코드 조회
 * @param	{Array} arrComCodeArg - 조회할 화주사 공통코드 정보
	  - mppCdGrpId : 공통코드 그룹ID
	  - obj     : 데이터셋
	  - shpprcoCd : 화주사 코드 (옵션)
	  - firstcd : 첫번째 Row에 추가할 CD값. ex) all (옵션)
	  - firstnm : 첫번째 Row에 추가할 값 ex) 전체 (옵션)
	  - filter : expr로 추가할 filter 문자열 ex) COMN_CD<='100' (옵션)
 * @return N/A
 */
pForm.gfnShppSearchCommonCode = function(arrComCodeArg)  {
	var objGdsCode = pForm.gfnGetApplication().gdsShppCommCode;
	var objGdsCmmCode = pForm.gfnGetApplication().gdsCommCode;
	var objTemp = pForm.gfnGetApplication().gdsTemp;
	var shpprcoCd = this.gfnGetUserInfo("DFT_SHPPRCO_CD");
	
	objGdsCode.set_enableevent(false);	
	//화주사 공통 코드에 있는지 여부 체크
	var mppList = [];	
	for(var i = 0 ; i < arrComCodeArg.length ; i++) {
		var mppCdGrpId = arrComCodeArg[i].mppCdGrpId;
		var filter = "MPP_COMN_CD_GRP_CD=='" + mppCdGrpId + "'";		
		
		objGdsCode.filter(filter);
		if(objGdsCode.rowcount == 0) {
			mppList.push(mppCdGrpId);		//현재 글로벌 데이터셋에 있는지 여부 확인
		}		
	}
	
	//화주사 공통 코드에 없는 데이터만 DB에서 조회
	if(mppList.length > 0) {
		var oParam = {
			  searchId		: "com.bpo.com.svc.service.CommonService.selectShppCmmCdList"			
		};
		var sArgs = "MPP_GRP_IN_LIST=" + nexacro.wrapQuote(mppList.join(","));
		
		objTemp.clearData();
		this.gfnTranCommSearch("shppSearchCommonCode", oParam, objTemp, sArgs, null, false);
		
		//조회된 결과을 삽입한다.
		if(objTemp.rowcount > 0) {
			objGdsCode.appendData(objTemp, true);
		}			
		
		//매핑 코드가 없는 건에 대해서도 데이터 삽입
		for(key in mppList) {						
			objGdsCode.filter("MPP_COMN_CD_GRP_CD=='" + mppList[key] + "'");
			if(objGdsCode.rowcount == 0) {
				objGdsCode.insertRow(0);
				objGdsCode.setColumn(0, "MPP_COMN_CD_GRP_CD", mppList[key]);
				objGdsCode.setColumn(0, "COMN_CD_GRP_CD", "NO_DATA");
			}
		}
	}	
	
	//데이터셋 제작 (화주사 공통코드 또는 공통코드에서)
	for(var i = 0 ; i < arrComCodeArg.length ; i++) {
		var elem = arrComCodeArg[i];
		var shpprco = shpprcoCd;
		if( this.gfnIsNotNull(elem.shpprcoCd) ){
			shpprco = elem.shpprcoCd;
		}
		var filter = "MPP_COMN_CD_GRP_CD=='" + elem.mppCdGrpId + "' && SHPPRCO_CD == '" + shpprco + "' && COMN_CD_GRP_CD != 'NO_DATA'";		
		if( this.gfnIsNotNull(elem.filter) ){
			filter += " && " + elem.filter;
		}
		objGdsCode.filter(filter);
		
		elem.obj.set_enableevent(false);
		if(objGdsCode.rowcount > 0) {
			elem.obj.copyData(objGdsCode, true);					
		}else {
			filter = "COMN_CD_GRP_CD=='" + elem.mppCdGrpId + "'";
			if( this.gfnIsNotNull(elem.filter) ){
				filter += " && " + elem.filter;
			}
			objGdsCmmCode.filter(filter);
			elem.obj.copyData(objGdsCmmCode, true);
		}
		
		pForm.gfnSetFirstCd(elem.obj, elem.firstnm, elem.firstcd);
		elem.obj.set_enableevent(true);
	}
	
	objGdsCmmCode.filter("");
	objGdsCode.set_enableevent(true);	
}


/**
 * @class 조회된 공통코드를 컴포넌트에 셋팅
 * @param	{Object}	objDsComm		: 공통코드 Dataset
 * @param	{Array}	arrComCodeArg 	: 조회할 공통코드 정보
	  - cdGrpId : 공통코드 그룹ID
	  - obj     : 조회된 공통코드를 적용할 객체(Dataset/Combo). Combo 선택시 첫번째 index 자동설정
	  - firstcd : 첫번째 Row에 추가할 CD값. ex) all
	  - firstnm : 첫번째 Row에 추가할 값 ex) 전체
	  - filter : expr로 추가할 filter 문자열 ex) COMN_CD<='100'
 * @return N/A
 */
pForm.gfnGetCommonCode = function(objDsComm, oCommArg) 
{
	var objDs;		// 대상 데이터셋
	var objCbo;		// 대상 콤보
	
	var obj = oCommArg.obj
	
	if( obj instanceof nexacro.Combo ){		//obj 가 콤보일경우
		objDs = obj.getInnerDataset();
		objCbo = obj;
	} else if( obj instanceof Dataset){		//obj 가 데이터셋일경우
		objDs = obj;
		objCbo = null;
	}
	
	if( objDs == null )
	{	
		this.gfnLog("gfnGetCommonCode :  [Dataset]이 Null 입니다. ","error");
		return;
	}
	
	objDsComm.set_enableevent(false);
	objDs.set_enableevent(false);
	
   	var strFilter = "COMN_CD_GRP_CD==" + nexacro.wrapQuote(oCommArg.cdGrpId); 		

   	//FIlter조건 추가
    if(!pForm.gfnIsNull(oCommArg.filter)) {
     	strFilter = strFilter + " && " + oCommArg.filter;
    }
	
	objDsComm.filter(strFilter);
	objDs.copyData(objDsComm, true);
	objDsComm.filter("");
	objDs.set_enableevent(true);
	objDsComm.set_enableevent(true);
	
	// first set 세팅
	pForm.gfnSetFirstCd(obj, oCommArg.firstnm, oCommArg.firstcd);
};

/**
 * @class 첫번째 Row에 데이터 추가(콤보용)
 * @param {Object}	objComp 		: 적용할 객체(Dataset/Combo). Combo 선택시 첫번째 index 자동설정
 * @param {String}	sFirstNm 		: 첫번째 Row에 추가할 값 ex) 전체
 * @param {String}	sFirstCd 		: 첫번째 Row에 추가할 CD값. ex) 00
 * @param {String}	sFirstNmCol 	: 첫번째 Row에 추가할 값 컬럼ID. (기본값:Combo의 경우 codecolumn값 사용. Dataset은 "COMN_CD")
 * @param {String}	sFirstCdCol 	: 첫번째 Row에 추가할 CD값  컬럼ID. (기본값:Combo의 경우 datacolumn값 사용. Dataset은 "COMN_CD_NM")
 * @return N/A
 */
pForm.gfnSetFirstCd = function(objComp, sFirstNm, sFirstCd, sFirstNmCol, sFirstCdCol) 
{
	var objDs;		// 대상 데이터셋
	var objCbo;		// 대상 콤보
	
	var sCodeCol = sFirstCdCol;
	var sDataCol = sFirstNmCol;
	
	var obj = objComp;
	
	if( obj instanceof nexacro.Combo ){		//obj 가 콤보일경우
		objDs = obj.getInnerDataset();
		objCbo = obj;
		
		if(this.gfnIsNull(sCodeCol)) {
			sCodeCol = objCbo.codecolumn;
		}
		
		if(this.gfnIsNull(sDataCol)) {
			sDataCol = objCbo.datacolumn;
		}
		
	} else if( obj instanceof Dataset){		//obj 가 데이터셋일경우
		objDs = obj;
		objCbo = null;
	}
	
	if(this.gfnIsNull(sCodeCol)) {
		sCodeCol = "COMN_CD";
	}
	
	if(this.gfnIsNull(sDataCol)) {
		sDataCol = "COMN_CD_NM";
	}
		
	if( objDs == null )
	{	
		this.gfnLog("gfnGetCommonCode :  [Dataset]이 Null 입니다. ","error");
		return;
	}
	
	// first set 세팅
	if(this.gfnIsNull(sFirstNm) != true)
	{
		objDs.insertRow(0);
		if(sFirstCd == "")
		{
			objDs.setColumn(0, sCodeCol, "");
		}
		else
		{
			objDs.setColumn(0, sCodeCol, sFirstCd);
		}
		
		objDs.setColumn(0, sDataCol, sFirstNm);
	}
	
	//콤보값을 넘긴 경우 0번째 인덱스 설정
	if( this.gfnIsNotNull(objCbo) ){
		objCbo.set_index(0);
	}
};

/*
// 공통코드를 조회하는 경우 참고용
pForm._commCodeArg = null;
pForm.gfnSearchCommonCode = function(arrComCodeArg, sCallBackNm, isAsync) 
{
	var arrGroupCd = new Array();
	this._commCodeArg = null;
	
	var objApp = pForm.gfnGetApplication();
	var objDs = objApp.gdsTemp;
	
	// 파라미터값 조회
	this._commCodeArg = arrComCodeArg;
	
	for(var i=0; i<arrComCodeArg.length; i++)
	{
		arrGroupCd.push(arrComCodeArg[i].cdGrpId);
	}
	
	//this.gfnLog("GROUP_CODE => " + arrGroupCd.toString());
	
	// 데이터 초기화
	objDs.clearData();
	
	// 파라미터값 조회
	this._commCodeArg = arrComCodeArg;
	
	var svcId	= "gfnSearchCommonCode";
	var service	= this.gfnGetPreUrl() + "/common/selectShpprCmmCdList.do";
	var inDs 	= "";
	var outDs 	= objDs.name + "=OUT_LIST";
	var args 	= "SHPPRCO_GRP_CDS=" + nexacro.wrapQuote(arrGroupCd.toString());
	var callBackFnc = "gfnCommonCallback";
	
	if(!pForm.gfnIsNull(sCallBackNm))		svcId = svcId + "^" + sCallBackNm;
	if(pForm.gfnIsNull(isAsync))			isAsync = true;
	
	this.gfnTransaction(svcId, service, inDs, outDs, args, callBackFnc, isAsync);
}

pForm.gfnCommonCallback = function(svcID,errCd,errMsg) 
{
	if (errCd < 0)
	{
		var objRtn = pForm.gfnCommSetError(errCd, errMsg);
		if (objRtn == false)		return;
	}
	
	var arrSvc =  svcID.split("^");
	
	if (arrSvc[0] == "gfnSearchCommonCode") {
		
		var sCallBackNm = arrSvc[1];
		
		for(var i=0; i<this._commCodeArg.length; i++)
		{
			pForm.gfnGetCommonCode(pForm.gfnGetApplication().gdsTemp,this._commCodeArg[i]);
		}
		
		this._commCodeArg = null;
		
		// form에 callback 함수가 있을때
		if (this[sCallBackNm]) {
			this.lookupFunc(sCallBackNm).call(arrSvc[0], errCd, errMsg);
		}
	}
};
*/

/**
 * @class object에 속성들(name, value) 를 dataset로 부터 구성한다.
 * dataset의 Column들의 id를 속성 명칭,
 * Column에 nRow번째 row 값을 value로 object 속성으로 구성된다.
 * @param {object} object Dataset값을 참조해서 새로 구성되는 객체
 * @param {dataset} ds 객체구성시 참조되는 Dataset
 * @param {int} 대상 Row 위치
 * @return N/A
*/
pForm.gfnDatasetToPram = function(object, ds, nRow)
{
	if (pForm.gfnIsNull(ds))		return;
	if (ds.rowcount == 0)			return;
	if (pForm.gfnIsNull(nRow))		nRow = ds.rowposition;
	
	var i, len, name, value;
	
	for(i = 0, len = ds.getColCount(); i < len; i++)
	{
		name = ds.getColID(i);
		if (pForm.gfnIsNull(name)) continue;
		
		value = ds.getColumn(nRow, name) || "";
		object[name] = value;
	}
}

/* SearchDiv관련 변수 */
pForm.fvSearchDivClose = 48;							// 접었을때 사이즈
pForm.fvCondHeight = 35;								// 조회조건 높이
pForm.fvCondWidth = 370;								// 조회조건 넓이
pForm.fvSearchDivRightGap = 105;						// 오른쪽 여백(조회버튼, 초기화버튼 영역)

/**
 * @class 조회 Div에 있는 컴포넌트에서 엔터시 조회기능 추가하는 메소드
 * @param  {Object} objDiv - 조회 Div
 * @param  {Object} objBtn - 조회영역 토글버튼
 * @param  {Boolean} bOpen - 초기오픈 여부(기본값:true-펼침)
 * @param  {String} sSearchFnNm - 조회함수명. 미설정시 fnSearch() 실행
 * @param  {Boolean} bMove - 조회조건이 사이즈에 따라 이동할지 여부(기본값:true-이동)
 * @return N/A
 * @example	
	this.gfnSetSearchDiv(this.divSearch,this.btnSearchOpenClose);
 */
pForm.gfnSetSearchDiv = function(objDiv, objBtn, bOpen, sSearchFnNm, bMove)
{
	if (this.gfnIsNull(bOpen))			bOpen = true;
	if (this.gfnIsNull(bMove))			bMove = true;
	
	objDiv.set_formscrollbartype("none");		// 스크롤바 없음
	
	// 조회영역 접었다 폈다 설정
	if (this.gfnIsNotNull(objBtn)) {
	
		var nHeight = objDiv.getOffsetHeight();
		var sStatus = bOpen == true ? "open" : "close";
		
		// 기본값 설정
		if (objDiv._openHeight == null) {
			objDiv._openHeight = nHeight;
		}
		
		objDiv._openBtn = objBtn;
		objBtn._searchDiv = objDiv;
		
		objBtn.addEventHandler("onclick", this._gfn_btnSearchOpenClose_onclick, this);
		
		this._gfnSetSearchOpenClose(objBtn,sStatus);
		
	}
	
	if (bMove) {
		// 화면 리사이즈 설정
		this._gfnSetSearchDivResize(objDiv.form, objDiv);
	}
	
	// 엔터시 조회 설정
	objDiv.searchFnNm = sSearchFnNm;
	this._gfnSetEnter(objDiv.form, sSearchFnNm);
};

/**
 * @class 조회영역 open/close 설정
 * @param  {Object} obj - 조회 Div
 * @param  {String} sStatus - 설정할 조회영역 상태 : 열기(open)/닫기(close)
 * @return N/A
 * @example	
	this.gfnSetSearchDiv(this.divSearch,this.btnSearchOpenClose);
 */
pForm._gfnSetSearchOpenClose= function(obj,sStatus)
{
	var objDiv = obj._searchDiv;
	
	if (sStatus == "close") {
		objDiv.set_height(pForm.fvSearchDivClose);
		obj.set_cssclass("btn_WF_searchArea_toggle_open");
	} else {
		objDiv.set_height(objDiv._openHeight);
		obj.set_cssclass("btn_WF_searchArea_toggle_close");
	}
	
	objDiv["_openclose"] = sStatus;
	
	objDiv.parent.resetScroll();
};

/**
 * @class 조회영역 open/close 버튼 클릭 이벤트
 * @param {Object} obj - 버튼 객체
 * @param {Evnet}  e - 클릭이벤트
 * @return N/A
 */
pForm._gfn_btnSearchOpenClose_onclick= function(obj,e)
{
	if (obj.cssclass == "btn_WF_searchArea_toggle_close") {
		this._gfnSetSearchOpenClose(obj,"close");
	} else {
		this._gfnSetSearchOpenClose(obj,"open");
	}
};

/**
 * @class 조회영역 리사이즈 설정 함수
 * @param {Object} obj - 조회조건 Div의 부모 form객체
 * @param {Object}  objDiv - SerchDiv 객체
 * @return N/A
 */
pForm._gfnSetSearchDivResize = function(obj, objDiv)
{
	var arrComp = obj.components;
	var arrSearchCond = new Array();
	
	// Div객체만 추가
	for (var i=0; i<arrComp.length; i++)
	{
		if (arrComp[i] instanceof nexacro.Div)
		{
			arrSearchCond.push(arrComp[i]);
		}
	}
	
	// taborder로 Sort하는 함수(taborder기준으로 정렬)
	var Sortfunc = function (compA, compB) {
		if  (compA.taborder > compB.taborder ) return 1;
		if  (compA.taborder < compB.taborder ) return -1;
		return 0;
	}
	
	arrSearchCond.sort(Sortfunc);

	// 이동시킬 객체를 저장
	objDiv._arrSearchCond = arrSearchCond;
	
	// 리사이즈 실행
	pForm.gfnSearchDivResize(objDiv);
	
	// 이벤트 추가
	this._gfnEventAdd(objDiv,"onsize", this._gfnSearchDiv_onsize,0);
};

/**
 * @class 조회 Div 리사이즈 이벤트
 * @param {Object} obj - 조회 Div
 * @param {Evnet}  e - 클릭이벤트
 * @return N/A
 */
pForm._gfnSearchDiv_onsize = function(obj,e)
{
	if (obj["_arrSearchCond"] == null)		return;
	
	pForm.gfnSearchDivResize(obj);
};

/**
 * @class 조회영역 리사이즈시 컴포넌트 이동 실행
 * @param {Object} obj - SerchDiv 객체
 * @param  {Boolean} bSkip - 한줄에 표시될 갯수가 동일한 경우 스킵할지 여부. 성능을 위해 동일 표시갯수일때 리사이즈 안함. (기본값:true-스킵,false-동일사이즈에서도 이동)
 * @return N/A
 */
pForm.gfnSearchDivResize = function(obj,bSkip)
{
	if (obj["_arrSearchCond"] == null)		return;
	
	if (this.gfnIsNull(bSkip))		bSkip = true;
	
	var nWidth = obj.getOffsetWidth();
	var nHeight = obj.getOffsetHeight();
	var nCondBaseWidth = nWidth -  pForm.fvSearchDivRightGap;
	var nCondCnt = Math.floor(nCondBaseWidth / pForm.fvCondWidth);
	var nLeft = 0;
	var nTop = 5;				// 기본높이
	var nCnt = 0;
	var nLine = 0;
	var objComp;
	var nDivHeight = 0;
	
	// 같은 갯수 표시시 스킵
	if (bSkip ==true && obj["_condCnt"] == nCondCnt)		return;
	if (nCondCnt == 0)										return;
	
	var arrComp = obj["_arrSearchCond"];
	
	// 컴포넌트 이동
	for (var i=0; i<arrComp.length; i++)
	{
		objComp = arrComp[i];
		
		// 보이는 컴포넌트만 이동시킴.
		if (objComp.visible == true) {
			if (nCnt == 0) {				// 줄이 바뀔때마다 라인수 증가
				nLine++;
			}
		
			objComp.move(nLeft,nTop,pForm.fvCondWidth,pForm.fvCondHeight);
			
			nLeft = nLeft + pForm.fvCondWidth;
			nCnt++;
		}
		
		if (nCnt == nCondCnt) {			// 다음행으로 이동
			nCnt = 0;
			nLeft = 0;
			nTop = nTop + pForm.fvCondHeight;
		}
	}
	
	obj.form.resetScroll();
	
	// Div 높이지정
	var sOpenClose = this.gfnNvl(obj["_openclose"],"open");
	nDivHeight = pForm.fvSearchDivClose + (pForm.fvCondHeight * (nLine-1));
	obj._openHeight = nDivHeight;
	
	if (sOpenClose == "open") {
		obj.set_height(nDivHeight);
		obj.parent.resetScroll();
	}
	
	// 버튼 보이기/숨기기 설정
	if (obj["_openBtn"] != null) {
		if (nDivHeight == pForm.fvSearchDivClose) {
			obj._openBtn.set_visible(false);
		} else {
			obj._openBtn.set_visible(true);
		}
	}
	
	obj["_condCnt"] = nCondCnt;
};

/**
 * @class 조회 Div에 있는 컴포넌트에서 제어 메소드
 * @param  {Object} objDiv - 조회 Div
 * @param  {Object} objBtn - 조회영역 토글버튼
 * @param  {Boolean} bOpen - 초기오픈 여부(기본값:true-펼침)
 * @param  {String} sScrnId - 동적조회값이 설정되어 있는 화면 ID (기본값 : 현재 화면ID)
 * @return N/A
 * @example	
	this.gfnSetComSearchDiv(this.divSearch,this.btnSearchOpenClose);
 */
pForm.gfnSetComSearchDiv = function(objDiv, objBtn, bOpen, sScrnId)
{
	if (this.gfnIsNull(bOpen))			bOpen = true;
	
	objDiv.set_formscrollbartype("none");		// 스크롤바 없음
	var scrnId = this.gfnGetArgument("scrnId");
	if(this.gfnIsNotNull(sScrnId)) {
		scrnId = sScrnId;
	}
	
	//조회 Div에 조회조건 component를 생성하는 메소드
	this.gfnSetSrchCond(objDiv, scrnId, this.gfnGetUserInfo("DFT_SHPPRCO_CD"));
	
	// 조회영역 접었다 폈다 설정
	if (this.gfnIsNotNull(objBtn)) {
	
		var nHeight = objDiv.getOffsetHeight();
		var sStatus = bOpen == true ? "open" : "close";
		
		// 기본값 설정
		if (objDiv._openHeight == null) {
			objDiv._openHeight = nHeight;
		}
		
		objDiv._openBtn = objBtn;
		objBtn._searchDiv = objDiv;
		
		objBtn.addEventHandler("onclick", this._gfn_btnComSearchOpenClose_onclick, this);
		
		this._gfnSetComSearchOpenClose(objBtn,sStatus);
		
	}
	
	// 엔터시 조회 설정
	//objDiv.searchFnNm = sSearchFnNm;
	//this._gfnSetEnter(objDiv.form, sSearchFnNm);
	this._gfnSetEnter(objDiv.form);
};

/**
 * @class 조회영역 open/close 설정
 * @param  {Object} obj - 조회 Div
 * @param  {String} sStatus - 설정할 조회영역 상태 : 열기(open)/닫기(close)
 * @return N/A
 * @example	
	this.gfnSetSearchDiv(this.divSearch,this.btnSearchOpenClose);
 */
pForm._gfnSetComSearchOpenClose= function(obj,sStatus)
{
	var objDiv = obj._searchDiv;
	
	if (sStatus == "close") {
		objDiv._openHeight = objDiv.getOffsetHeight(); //
		objDiv.set_height(this.fvSearchDivClose);
		obj.set_cssclass("btn_WF_searchArea_toggle_open");
	} else {
		objDiv.set_height(objDiv._openHeight);
		obj.set_cssclass("btn_WF_searchArea_toggle_close");
	}
	
	objDiv["_openclose"] = sStatus;
	
	objDiv.parent.resetScroll();
};

/**
 * @class 조회영역 open/close 버튼 클릭 이벤트
 * @param {Object} obj - 버튼 객체
 * @param {Evnet}  e - 클릭이벤트
 * @return N/A
 */
pForm._gfn_btnComSearchOpenClose_onclick= function(obj,e)
{
	if (obj.cssclass == "btn_WF_searchArea_toggle_close") {
		this._gfnSetComSearchOpenClose(obj,"close");
	} else {
		this._gfnSetComSearchOpenClose(obj,"open");
	}
};


/**
 * @class 조회영역 엔터시 처리
 * @param	{Object} obj - 화면
 * @param	{String} sSearchFnNm - 조회함수명. 미설정시 fnSearch() 실행
 * @return	N/A
 * @example 
 * this._gfnSetEnter(this);
 */
pForm._gfnSetEnter = function(objForm, sSearchFnNm)
{
	var arrComp = objForm.components;
	var nLength = arrComp.length;
	var sUrl;
	
	if (this.gfnIsNull(sSearchFnNm))		sSearchFnNm = "fnSearch";

	for (var i=0; i<nLength; i++)
	{
		if (arrComp[i] instanceof nexacro.Div)
		{
			// URL로 링크된 경우에는 존재하는 경우에는 해당 링크된 Form Onload에서 처리하도록 한다.
			if (this.gfnIsNull(arrComp[i].url))	this._gfnSetEnter(arrComp[i].form, sSearchFnNm);
		}
		else
		{
			// Edit,Calendar 처리
			if( arrComp[i] instanceof nexacro.Edit
				|| arrComp[i] instanceof nexacro.Calendar)
			{
				arrComp[i].addEventHandler("onkeyup", this._gfn_searchComp_onkeyup, this);
				
				if (arrComp[i].searchFnNm ==  null)
				{
					arrComp[i].searchFnNm = sSearchFnNm;
				}
			}
			
			// 해당 객체에 MenuParam값 설정
			//this._gfnSetObjMenuParam(arrComp[i]);
		}
	}
};

/*
// 해당 객체에 MenuParam값 설정(안과장님 요청으로 임시로 만듬)
pForm._gfnSetObjMenuParam = function(obj)
{
	var sName = obj.name;
	var MenuParam	= this.gfnGetMenuParam(sName);
	
	if (this.gfnIsNotNull(MenuParam)) {
		if( obj instanceof nexacro.Calendar
			|| obj instanceof nexacro.CheckBox
			|| obj instanceof nexacro.Combo
			|| obj instanceof nexacro.Edit
			|| obj instanceof nexacro.ListBox
			|| obj instanceof nexacro.MaskEdit
			|| obj instanceof nexacro.Radio
			|| obj instanceof nexacro.Spin
			|| obj instanceof nexacro.TextArea)
		{
			obj.set_value(MenuParam);
		}
		else if(obj instanceof nexacro.Div)
		{
			var sUrl = arrComp[i].url;
			
			// TODO : 유저컴포넌트 작업
			if (this.gfnIsNotNull(sUrl)) {
				if (sUrl == "com::comCalMonth.xfdl")
				{
					obj.form.fnSetDate(MenuParam);
				}
				else if (sUrl == "com::comMultiCombo.xfdl")
				{
					obj.form.fnSetValue(MenuParam);
				}
			}
		}
	}
};
*/

/**
 * @class 엔터시 조회함수 호출 
 * @param {Object} obj - 입력컴포넌트 객체
 * @param {Evnet}  e - 키입력 중 눌렸던 키보드가 떼어질 때 이벤트
 * @return N/A
 */
pForm._gfn_searchComp_onkeyup = function(obj,e)
{
	// 엔터시 조회
	if(e.keycode == 13)
	{
		var sFunction = obj.searchFnNm;
		
		if(this.gfnIsNotNull(sFunction))
		{	
			this.lookupFunc(sFunction).call();	
		}
	}
};

/**
 * @class 콤보박스 값을 셋팅
 * @param  sCboType - 콤보박스 종류 -> 쿼리 ID를 사용할 경우 (bpo.adm.xxx.xxx.dao.xxxDAO.selectXXX) 지정된 쿼리의 값으로 Combo 생성
 * @param  dsList - 결과값을 리턴받을 데이터 셋
 * @param  sCallBack - 콜백함수
 * @param  strArg - 아규먼트  
 * @param  isMulti - 멀티콤보 여부 확인
 */
pForm.gfnSetCombox = function(sCboType, dsList, strArg, sCallBack, isMulti) 
{
	
	var oParam = {
			  searchId		: "com.bpo.com.svc.service.MdmService."			
			, pool			: this.MODULE.adm
	};
		
	dsList.clearData();	
	if(sCboType == "mdul") {		
		oParam.searchId += "selectMdulList";		//모듈 마스터
		if(this.gfnIsNotNull(strArg)) {			
			strArg	= "IS_ADMIN=" + nexacro.wrapQuote(strArg);			
		}
	}else if(sCboType == "sapCorp") {				//SAP 법인 마스터
		oParam.searchId += "selectSapCorpList";				
	}else if(sCboType == "hrSrcCorp") {				//HR 법인 마스터
		oParam.searchId += "selectHrSrcCorpList";
	}else if(sCboType == "intrRgn") {				//국제 권역 마스터
		oParam.searchId += "selectIntrRgnList";
	}else if(sCboType == "dmstPostNoSidoDvsn") {	//국내 우편 번호 - 시도 구분 마스터
		oParam.searchId += "selectDmstPostNoSidoDvsnList";
	}else if(sCboType == "dmstPostNoSignGuDvsn") {	//국내 우편 번호 - 시군구 구분 마스터
		oParam.searchId += "selectDmstPostNoSignGuDvsnList";
	}else if(sCboType == "lgistCent") {
		oParam.searchId += "selectLgistCentList";	//물류 센터 마스터
	}else if(sCboType == "comnCd") {				//공통 팝업		
		var objGdsCode = pForm.gfnGetApplication().gdsCommCode;		
		if(!isMulti) {
			this.gfnGetCommonCode(objGdsCode, {cdGrpId:strArg, obj:dsList, firstnm:" "});
		}else {
			this.gfnGetCommonCode(objGdsCode, {cdGrpId:strArg, obj:dsList});			
		}
		this.gfnCboAfter("search" + sCboType);
	} else if(sCboType == "custom"){	//사용자 정의 쿼리 호출
		oParam.searchId = strArg; 
		var temp = strArg.split(".");
		sCboType = temp[temp.length - 1];
	}else {	//사용자 정의 쿼리 호출
		oParam.searchId = sCboType;
		var temp = sCboType.split(".");
		sCboType = temp[temp.length - 1];
	}
	
	
	if(sCboType != "comnCd") {
		//사용자 정의 쿼리 데이터가 NONE인 경우 제외
		if(oParam.searchId != "NONE") {
			this.gfnTranCommSearch("search" + sCboType, oParam, dsList, strArg, sCallBack, true);	
		}else if(oParam.searchId == "NONE") {
			//동적조회조건의 사용자 정의 쿼리옵션값이 NONE인경우 콜백
			this.lookupFunc("gfnCboAfter").call("searchNone", "NONE"); 
		}
	}
};


/**
 * @class 조회 Div에 조회조건 component를 생성하는 메소드
 * @param  {object} objDiv - 조회 Div
 * @param  {String} sScrnId - 화면ID (세션값)
 * @param  {object} sDftShpprId - 화주ID (세션값)
 * @return N/A
 * @example
	this.gfnSetSrchCond(this.divSearch, this.gfnGetArgument("scrnId"), this.gfnGetUserInfo("DFT_SHPPR_ID"));
 */
pForm.gfnSetSrchCond = function(objDiv, sScrnId, sDftShpprId){
	var urlSet = "com::";
	var strFilter = "SCRN_ID == '"+sScrnId+"'";
	nexacro.getApplication().gdsSrchCondition.filter(strFilter);
	var nRow = nexacro.getApplication().gdsSrchCondition.findRow( "SHPPRCO_CD", sDftShpprId );
	if(sDftShpprId != undefined && nRow > -1){
		strFilter = strFilter + "&& SHPPRCO_CD == '" + sDftShpprId + "'";
		nexacro.getApplication().gdsSrchCondition.filter(strFilter);    //userinfo 에서 화주 정보 필요함
	}
	if(nexacro.getApplication().gdsSrchCondition.rowcount > 0 ){	// 0건이면 화면에 세팅된 조건 보여줌
		objDiv.srchConditionCnt = nexacro.getApplication().gdsSrchCondition.rowcount;	//공통조회조건수 - 조회영역 접었다 폈다 설정에 이용 
		objDiv.strFilter = strFilter;
		objDiv.set_url(urlSet + "comCondSearchCond.xfdl");
	}
};

/**
 * @class 검색조건 화면객체id별 value 값 세팅
 * @param  {object} oForm - 화면obj
 * @param  {String} strId - 조회조건 화면객체ID
 * @param  {String} strValue - 조회조건 세팅할 값
 * @param  {String} strValue2 - 코드코드명에 네임영역에 셋팅할 값
 * @return N/A
 * @example
	this.gfnSetSearchCondId(this, "NAT_NM", "대한민국");
 */
pForm.gfnSetSearchCondId = function( oForm, strId, strValue, strValue2)
{
	var srchCondDs ;
	var srchCondDiv ;
	var srchCondTpcd ;
	var insLmtTpcd ;
	var gvCondId = "SEARCHID";
	var sSearchId ;
	var objDiv;
	var rtnRslt ;
	var idx = 0;

 	//trace("oForm.sSearchDivNm:"+ oForm.sSearchDivNm);
 	var sDivNm = oForm.sSearchDivNm;  //'FORM 변수 선언 영역에  this.sSearchDivNm = '공통조회조건 DIV id'
 	var objSearchArea = oForm.components[sDivNm];
	
 	srchCondDs = objSearchArea.form.dsSrchCondition;
 	srchCondDiv = objSearchArea.form.divSearchCond;
	
// 	if(oForm.searchArea == null){
// 		srchCondDs = oForm.divSearch.form.dsSrchCondition;
// 		srchCondDiv = oForm.divSearch.form.divSearchCond;
// 	}else{
// 		srchCondDs = oForm.searchArea.form.dsSrchCondition;
// 		srchCondDiv = oForm.searchArea.form.divSearchCond;	
// 	}

	var nRow = srchCondDs.findRowAs("SCRN_OBJ_1_ID", strId);

	if(nRow < 0){
		nRow = srchCondDs.findRowAs("SCRN_OBJ_2_ID", strId);
		idx = 1;
	}
	
	srchCondTpcd = srchCondDs.getColumn(nRow, "SRCH_COND_TPCD");
	insLmtTpcd   = srchCondDs.getColumn(nRow, "INS_LMT_TPCD");

	sSearchId = gvCondId + nRow;
	objDiv = srchCondDiv.form.components[sSearchId];
	//trace("objDiv.id:" + objDiv.id);

	if(srchCondTpcd == "005"){//팝업코드ONLY
		this.fnSetEditPopValue(objDiv, strValue);
	}else if(srchCondTpcd == "006"){//팝업코드코드명
		this.fnSetEditNmPopValue(objDiv, strValue, strValue2);
	}else if(srchCondTpcd == "003" || srchCondTpcd == "004" || srchCondTpcd == "010"){//단일텍스트박스문자-단건, 단일텍스트박스숫자, 단일텍스트박스문자-다건
		this.fnSetEditValue(objDiv, strValue);
	}else if(srchCondTpcd == "007"){//단일콤보박스
		this.fnSetComboValue(objDiv, strValue);
	}else if(srchCondTpcd == "008"){//다중콤보박스
		this.fnSetComboMulti(objDiv, strValue, idx);
	}else if(srchCondTpcd == "009"){//멀티콤보박스
		this.fnSetMultiComboValue(objDiv, strValue);
	}else if(srchCondTpcd == "002"){//범위텍스트박스일자
		this.fnSetDatePeriodValue(objDiv, strValue, idx, insLmtTpcd);
	}else if(srchCondTpcd == "001"){//단일텍스트박스일자
		this.fnSetDateValue(objDiv, strValue, insLmtTpcd);
	}else if(srchCondTpcd == "011" || srchCondTpcd == "012"){//범위텍스트박스숫자(011), 범위텍스트박스문자(012)
		this.fnSetEditMultiPopValue(objDiv, strValue, strValue2, idx);
	}
};

/**
 * @class 검색조건 화면객체id별 value 값 return 
 * @param  {object} oForm - 화면obj
 * @param  {String} strId - 조회조건 화면객체ID
 * @return N/A
 * @example
	this.gfnGetSearchCondId(this, "NAT_NM");
 */
pForm.gfnGetSearchCondId = function(oForm, strId)
{
	var srchCondDs ;
	var srchCondDiv ;
	var srchCondTpcd ;
	var insLmtTpcd ;
	var gvCondId = "SEARCHID";
	var sSearchId ;
	var objDiv;
	var rtnRslt ;
	var idx = 0;
	
 	//trace("oForm.sSearchDivNm:"+ oForm.sSearchDivNm);
 	var sDivNm = oForm.sSearchDivNm;  //'FORM 변수 선언 영역에  this.sSearchDivNm = '공통조회조건 DIV id'
 	var objSearchArea = oForm.components[sDivNm];
 	
 	srchCondDs = objSearchArea.form.dsSrchCondition;
 	srchCondDiv = objSearchArea.form.divSearchCond;
	
// 	if(oForm.searchArea == null){
// 		srchCondDs = oForm.divSearch.form.dsSrchCondition;
// 		srchCondDiv = oForm.divSearch.form.divSearchCond;
// 	}else{
// 		srchCondDs = oForm.searchArea.form.dsSrchCondition;
// 		srchCondDiv = oForm.searchArea.form.divSearchCond;	
// 	}
	
	var nRow = srchCondDs.findRowAs("SCRN_OBJ_1_ID", strId.concat("_"));
	if(nRow < 0){
		nRow = srchCondDs.findRowAs("SCRN_OBJ_2_ID", strId.concat("_"));
		idx = 1;
	}
	
	srchCondTpcd = srchCondDs.getColumn(nRow, "SRCH_COND_TPCD");
	insLmtTpcd   = srchCondDs.getColumn(nRow, "INS_LMT_TPCD");

	sSearchId = gvCondId + nRow;
	objDiv = srchCondDiv.form.components[sSearchId];

	if(srchCondTpcd == "005"){//팝업코드ONLY
		rtnRslt = this.fnGetEditPopValue(objDiv);
	}else if(srchCondTpcd == "006"){//팝업코드코드명
		rtnRslt = this.fnGetEditNmPopValue(objDiv);
	}else if(srchCondTpcd == "003" || srchCondTpcd == "004" || srchCondTpcd == "010"){//단일텍스트박스문자-단건, 단일텍스트박스숫자, 단일텍스트박스문자-다건
		rtnRslt = this.fnGetEditValue(objDiv);
	}else if(srchCondTpcd == "007"){//단일콤보박스
		rtnRslt = this.fnGetComboValue(objDiv);
	}else if(srchCondTpcd == "008"){//다중콤보박스
		rtnRslt = this.fnGetComboMulti(objDiv, idx);
	}else if(srchCondTpcd == "009"){//멀티콤보박스
		rtnRslt = this.fnGetMultiComboValue(objDiv);
	}else if(srchCondTpcd == "002"){//범위텍스트박스일자
		rtnRslt = this.fnGetDatePeriodValue(objDiv, idx, insLmtTpcd);
	}else if(srchCondTpcd == "001"){//단일텍스트박스일자
		rtnRslt = this.fnGetDateValue(objDiv, insLmtTpcd);
	}else if(srchCondTpcd == "011" || srchCondTpcd == "012") { //범위텍스트박스숫자(011), 범위텍스트박스문자(012)
		rtnRslt = this.fnGetMultiEditValue(objDiv, idx);
	}
	return rtnRslt;
};

/**
 * @class 검색조건 화면객체id별 label 값 세팅
 * @param  {object} oForm - 화면obj
 * @param  {String} strId - 조회조건 화면객체ID
 * @param  {String} sWord - 조회조건 세팅할 다국어값 
 * @return N/A
 * @example
	this.gfnSetSearchCondLabel(this, "NAT_NM", "대한민국");
 */
pForm.gfnSetSearchCondLabel = function( oForm, strId, sWord)
{
	var srchCondDs ;
	var srchCondDiv ;
	var srchCondTpcd ;
	var insLmtTpcd ;
	var gvCondId = "SEARCHID";
	var sSearchId ;
	var objDiv;
	var rtnRslt ;
	var idx = 0;
 
	var sDivNm = oForm.sSearchDivNm;  //'FORM 변수 선언 영역에  this.sSearchDivNm = '공통조회조건 DIV id'
 	var objSearchArea = oForm.components[sDivNm];
	
 	srchCondDs = objSearchArea.form.dsSrchCondition;
 	srchCondDiv = objSearchArea.form.divSearchCond;
	
	var nRow = srchCondDs.findRowAs("SCRN_OBJ_1_ID", strId);
	srchCondTpcd = srchCondDs.getColumn(nRow, "SRCH_COND_TPCD");
	
	sSearchId = gvCondId + nRow;
	objDiv = srchCondDiv.form.components[sSearchId];
	
	objDiv.form.label.set_text(this.gfnGetWord(sWord));
};

/**
 * @class 검색조건 화면객체id별 ReadOnly
 * @param  {object} oForm - 화면obj
 * @param  {String} strId - 조회조건 화면객체ID
 * @param  {String} sWord - readOnly 값 
 * @return N/A
 * @example
	this.gfnSetSearchReadOnly(this, "NAT_NM", true);
 */
pForm.gfnSetSearchReadOnly = function( oForm, strId, bStatus) {
	var srchCondDs ;
	var srchCondDiv ;
	var srchCondTpcd ;
	var insLmtTpcd ;
	var gvCondId = "SEARCHID";
	var sSearchId ;
	var objDiv;
	var rtnRslt ;
	var idx = 0;
 
	var sDivNm = oForm.sSearchDivNm;  //'FORM 변수 선언 영역에  this.sSearchDivNm = '공통조회조건 DIV id'
 	var objSearchArea = oForm.components[sDivNm];
	
 	srchCondDs = objSearchArea.form.dsSrchCondition;
 	srchCondDiv = objSearchArea.form.divSearchCond;
	
	var nRow = srchCondDs.findRowAs("SCRN_OBJ_1_ID", strId);
	srchCondTpcd = srchCondDs.getColumn(nRow, "SRCH_COND_TPCD");
	
	sSearchId = gvCondId + nRow;
	objDiv = srchCondDiv.form.components[sSearchId];
	
	if(srchCondTpcd == "005" || srchCondTpcd == "006") {	// 팝업코드ONLY, 팝업코드코드명
		objDiv.form.fnSetCommPopReadOnly(bStatus);
	}else {
		objDiv.form.fnSetCommReadOnly(bStatus);
	}
}


/**
 * @class 검색조건 화면객체id별 label 값 가져오기
 * @param  {object} oForm - 화면obj
 * @param  {String} strId - 조회조건 화면객체ID 
 * @return N/A
 * @example
	this.gfnGetSearchCondLabel(this, "NAT_NM");
 */
pForm.gfnGetSearchCondLabel = function( oForm, strId)
{
	var srchCondDs ;
	var srchCondDiv ;
	var srchCondTpcd ;
	var insLmtTpcd ;
	var gvCondId = "SEARCHID";
	var sSearchId ;
	var objDiv;
	var rtnRslt ;
	var idx = 0;
 
	var sDivNm = oForm.sSearchDivNm;  //'FORM 변수 선언 영역에  this.sSearchDivNm = '공통조회조건 DIV id'
 	var objSearchArea = oForm.components[sDivNm];
	
 	srchCondDs = objSearchArea.form.dsSrchCondition;
 	srchCondDiv = objSearchArea.form.divSearchCond;
	
	var nRow = srchCondDs.findRowAs("SCRN_OBJ_1_ID", strId);
	srchCondTpcd = srchCondDs.getColumn(nRow, "SRCH_COND_TPCD");
	
	sSearchId = gvCondId + nRow;
	objDiv = srchCondDiv.form.components[sSearchId];
	
	return objDiv.form.label.text;
};


//코드팝업 코드값 Get
pForm.fnGetEditPopValue = function (objDiv){
	var rtnRslt = "";
	rtnRslt = objDiv.form.divCodePop01.form.edtCode.value;
	return rtnRslt;
};

//코드팝업 코드값 Set
pForm.fnSetEditPopValue = function (objDiv, strValue){
	objDiv.form.divCodePop01.form.edtCode.set_value(strValue);	
};

//코드네임팝업 코드값 Get
pForm.fnGetEditNmPopValue = function (objDiv){
	var rtnRslt = "";
	rtnRslt = objDiv.form.divCodeNamePop01.form.edtCode.value;
	return rtnRslt;
};

//코드네임팝업 코드값 Set
pForm.fnSetEditNmPopValue = function (objDiv, strValue, strValue1){
	objDiv.form.divCodeNamePop01.form.edtCode.set_value(strValue);
	if (this.gfnIsNull(strValue1)) {
		objDiv.form.divCodeNamePop01.form.edtName.set_value("");
	}else {
		objDiv.form.divCodeNamePop01.form.edtName.set_value(strValue1);
	}	
	
	//sepia 임시방편 추후 근본적인 원인파악 및 해결책이 필요
	if(this.gfnGetArgument("mdulCd") == "WMS") {
		this.setFocus(false, false);
	}
};

//범위텍스트박스숫자, 범위텍스트박스문자
pForm.fnSetEditMultiPopValue = function (objDiv, strValue1, strValue2, idx){	
	if(idx == 0) {
		objDiv.form.edtValue1.set_value(strValue1);
		if (this.gfnIsNotNull(strValue2)) {
			objDiv.form.edtValue2.set_value(strValue2);
		}
	}else if(idx == 1) {
		objDiv.form.edtValue2.set_value(strValue1);
	}
};

//입력박스값 Get
pForm.fnGetEditValue = function (objDiv){
	var rtnRslt = "";
	rtnRslt = objDiv.form.edtValue.value;
	return rtnRslt;
};

//범위텍스트박스숫자(011), 범위텍스트박스문자(012) Get
pForm.fnGetMultiEditValue = function (objDiv, nIdx){	//nIdx:0 ,1 
	var rtnRslt = "";
	rtnRslt = objDiv.form.edtValue1.value;
	if(nIdx == 1)	rtnRslt = objDiv.form.edtValue2.value;
	return rtnRslt;
}

//입력박스값 Set
pForm.fnSetEditValue = function (objDiv, strValue){
	objDiv.form.edtValue.set_value(strValue);
};

//콤보박스값 Get
pForm.fnGetComboValue = function (objDiv){
	var rtnRslt = "";
	rtnRslt = objDiv.form.cboValue.value;
	return rtnRslt;
};

//콤보박스값 Set
pForm.fnSetComboValue = function (objDiv, strValue){
	if(this.gfnIsNotNull(strValue)) {
		if(objDiv.form.cboValue.getInnerDataset().findRow("COMN_CD",strValue) == -1) {
			objDiv.form.cboValue.set_index(0);
		}else {
			objDiv.form.cboValue.set_value(strValue);
		}
	}else if(this.gfnIsNull(strValue)) {
		objDiv.form.cboValue.set_index(0);
	}else {
		objDiv.form.cboValue.set_value(strValue);
	}	
};

//다중콤보 Get
pForm.fnGetComboMulti = function (objDiv, nIdx){//nIdx:0 ,1 
	var rtnRslt = "";
	
	rtnRslt = objDiv.form.cboCode.value;
	if(nIdx == 1)	rtnRslt = objDiv.form.cboCode2.value;
	return rtnRslt;
};

//다중콤보 Set
pForm.fnSetComboMulti = function (objDiv, strValue, nIdx){//nIdx:0 ,1 
	if(nIdx == 1){
		objDiv.form.cboCode2.set_value(strValue);
	}else{
		objDiv.form.cboCode.set_value(strValue);
	}
};

//멀티콤보 Get
pForm.fnGetMultiComboValue = function (objDiv){
	var rtnRslt = "";
	rtnRslt = objDiv.form.mcbMultCombo.form.fnGetValue();
	return rtnRslt;
};

//멀티콤보 Set
pForm.fnSetMultiComboValue = function (objDiv, strValue){
	objDiv.form.mcbMultCombo.form.fnSetValue(strValue);
};

//기간년월, 달력값 Get
pForm.fnGetDatePeriodValue = function (objDiv, nIdx, insLmtTpcd){
	var rtnRslt = "";
	if(insLmtTpcd == "04"){//04  DT8
		rtnRslt = objDiv.form.divCalFromTo.form.calFrom.value;
		if(nIdx == 1)	rtnRslt = objDiv.form.divCalFromTo.form.calTo.value;
	}else{//03  DT6
		rtnRslt = objDiv.form.divCalMFromTo.form.calFrom.value;
		if(nIdx == 1)	rtnRslt = objDiv.form.divCalMFromTo.form.calTo.value;
	}
	return rtnRslt;
};

//기간년월, 달력값 Set
pForm.fnSetDatePeriodValue = function (objDiv, strValue, nIdx, insLmtTpcd){
	if(insLmtTpcd == "04"){//04  DT8
		if(nIdx == 0){
			objDiv.form.divCalFromTo.form.fnSetFromDate(strValue); 
		}else{
			objDiv.form.divCalFromTo.form.fnSetToDate(strValue);
		}
	}else{
		if(nIdx == 0){
			objDiv.form.divCalMFromTo.form.fnSetFromDate(strValue); 
		}else{
			objDiv.form.divCalMFromTo.form.fnSetToDate(strValue);
		}
	}
};

//단일년월, 달력값 Get
pForm.fnGetDateValue = function (objDiv, insLmtTpcd){
	var rtnRslt = "";
	if(insLmtTpcd == "04"){//04  DT8
		rtnRslt = objDiv.form.calFrom.value;
	}else{
		rtnRslt = objDiv.form.divCalMM.form.calYM.value;
	}
	return rtnRslt;
};

//단일년월, 달력값 Set
pForm.fnSetDateValue = function (objDiv, strValue, insLmtTpcd){
	if(insLmtTpcd == "04"){//04  DT8
		objDiv.form.calFrom.set_value(strValue);
	}else{
		objDiv.form.divCalMM.form.fnSetDate(strValue);
	}
};

/**
 * @class 개인정보처리 로그 사용 파라미터 셋팅
 * @param  {String} 현재 아큐먼트 내용
 * @param  {String} 정보처리내용
 * @return {String} 개인정보처리 로그 사용 내용 
 */
pForm.gfnGetPsnLog = function(sArg, sProcInf) {	
	if(this.gfnIsNotNull(sArg)) {
		return " PSN_PROC_LOG=Y PROC_INF_CONTT=" + nexacro.wrapQuote(this.gfnIsNullEmpty(sProcInf));
	}
	return "PSN_PROC_LOG=Y PROC_INF_CONTT=" + nexacro.wrapQuote(this.gfnIsNullEmpty(sProcInf));
}

/**
 * @class  DLL의 full 경로를 리턴
 * @param  {String} 컴포넌트 DLL 파일명
 * @return {String} 해당 DLL의 실제 경로
 */
pForm.gfnGetDLLPath = function(sFileName)
{
	var strpath = "";
	var xadl = nexacro.getProjectPath();
	
	// studio로 실행
    if (xadl.indexOf("file://") != -1) {        
		xadl = xadl.replace("file://", "");
        strpath  = nexacro.replaceAll(xadl.substring(0, xadl.lastIndexOf("/")), "/", "\\")+"\\..\\resources\\install\\dll\\"+sFileName;
    }
	// 웹 접속
    else {
		strpath = system.convertRealPath("%USERAPP%\\bpo\\Component\\" + sFileName);
	}
	
    return strpath;
};

/**
 * @class 컴포넌트 DLL 을 로딩하고 그 결과 Object를 리턴
 * @param {String}  컴포넌트 DLL 파일명
 * @return {Object} DLL 컴포넌트 Object
 */ 
pForm.gfnOpenDLL = function(sFileName)
{
	var objApp = this.gfnGetApplication();
	
	if (this.gfnIsNull(objApp[sFileName])) {
		objApp[sFileName] = {};
	}
	else {
		return objApp[sFileName];
	}

	// 로컬/웹 접근에 따른 파일 full 경로 가져오기
	var strpath = this.gfnGetDLLPath(sFileName);
	
	// dll load
	objApp[sFileName] = nexacro._addExtensionModule(strpath);

	return objApp[sFileName];
};

/**
 * @class 컴포넌트 DLL 을 로딩하고 그 결과 Object를 리턴
 * @return N/A
 */  
pForm.gfnCloseDLL = function(sFileName)
{
	// 로컬/웹 접근에 따른 파일 full 경로 가져오기
	var strpath = this.gfnGetDLLPath(sFileName);
	
	// dll 등록 해제
	nexacro._clearExtensionModule(strpath);
	
	// 객체 null 처리
	var objApp = this.gfnGetApplication();
	objApp[sFileName] = null;
};

/**
 * @class 확장 컴포넌트 DLL를 로딩하고 그 결과 Object를 리턴
 * @return {Object} 확장 컴포넌트 Object
 */ 
pForm.gfnGetExtCommon = function()
{
	var strFile = "";

	// nexacro 엔진 버전 체크
	var navigatorFullName = system.navigatorfullname;
	
	if (navigatorFullName == "nexacro platform 17 Engine (Windows XP)" ) {
		strFile = "ExtCommonV17_XP.dll";
	}
	else if (navigatorFullName == "nexacro platform 17 Engine (x86)") {
		strFile = "ExtCommonV17_32.dll";
	}
	else {
		strFile = "ExtCommonV17_64.dll";
	}	
	
	return this.gfnOpenDLL(strFile);
};

/**
 * @class확장 컴포넌트 DLL를 해제한다.
 * @return N/A
 */  
pForm.gfnCloseExtCommon = function()
{
	var strFile = "";

	// nexacro 엔진 버전 체크
	var navigatorFullName = system.navigatorfullname;
	
	if (navigatorFullName == "nexacro platform 17 Engine (Windows XP)" ) {
		strFile = "ExtCommonV17_XP.dll";
	}
	else if (navigatorFullName == "nexacro platform 17 Engine (x86)") {
		strFile = "ExtCommonV17_32.dll";
	}
	else {
		strFile = "ExtCommonV17_64.dll";
	}	
	this.gfnCloseDLL(strFile);
};

/**
 * @class 한글여부 체크
 * @return boolean
 */  
pForm.gfnIsHangul = function(value) {
	if(this.gfnIsNull(value))
		return false;
		
	var kor = /[ㄱ-ㅎ|ㅏ-ㅣ|가-힣]/;
	return kor.test(value);
}

/**
 * @class AAA=BBB를 {AAA:"BBB"} 형태로 변환
 * @return object
 */  
pForm.gfnConvertParam = function(value) {
	var obj = {};
	if(this.gfnIsNull(value))
		return obj;
		
	var elems = value.split(",");
	var elem;
	for(var i = 0 ; i < elems.length ; i++) {
		elem = elems[i].split("=");
		obj[elem[0]] = elem[1];
	}
	
	return obj;
}

/**
 * @class 단일 달력 포멧 형식 변경
 * @param  {Object 또는 array} 달력 컴포넌트 ID
 */
pForm.gfnSetSingleDateFormat = function (obj) {
	var locale = this.gfnGetUserInfo("LOCALE");
	if(this.gfnIsNotNull(locale) && locale != "ko_KR") {				
		if(this.gfnIsArray(obj)) {
			//배열
			for(var i = 0 ; i < obj.length ; i++) {
				var elem = obj[i];
				if(elem.dateformat == "SHORTDATE") {
					elem.set_locale(locale);				
				}else {
					//월달력
				}
			}
		}else {				
			//단일건
			if(obj.dateformat == "SHORTDATE") {
				obj.set_locale(locale);				
			}else {
				//월달력
			}
			
		}
	
	}
}