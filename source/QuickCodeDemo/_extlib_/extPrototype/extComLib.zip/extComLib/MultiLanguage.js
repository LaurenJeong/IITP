/**
*  BPO 플랫폼
*  @FileName 	MultiLanguage.js 
*  @Creator 	PJY
*  @CreateDate 	2019.06.24
*  @Desction    
************** 소스 수정 이력 ***********************************************
*  date          		Modifier                Description
*******************************************************************************
*  2019.06.24     		PJY		       	      	최초 생성
*******************************************************************************
*/

var pForm = nexacro.Form.prototype;

/**
 * @class  해당 form의 하위 콤포넌트 모두 찾아 다국어 처리
 * @param  {Form} objForm - 대상 form
 * @return N/A
 */
pForm.gfnInitLang = function (objForm)
{
	var objApp   = nexacro.getApplication();
	var nUserCnt = this.gfnGetApplication().gdsUserInfo.getRowCount();
	var sNowLang = objApp.gvLanguage;
	
	// Language 변경 전/후 값 확인	//TODO sepia 20200219 다국어 처리
	//if (sNowLang == "ko_KR") 	return;
	if(nUserCnt == 0) return;

	var arrComp = objForm.components;
	var nLength = arrComp.length;

	for (var i=0; i<nLength; i++)
	{
		if (arrComp[i] instanceof nexacro.Div) 
		{
			// URL로 링크된 경우에는 존재하는 경우에는 해당 링크된 Form Onload에서 처리하도록 한다.
			if (this.gfnIsNull(arrComp[i].url)) this.gfnInitLang(arrComp[i].form); //재귀함수			
		}
		else if (arrComp[i] instanceof nexacro.Tab)
		{
			var nPages = arrComp[i].tabpages.length;

			for (var j=0; j<nPages;j++)
			{
				// URL로 링크된 경우에는 존재하는 경우에는 해당 링크된 Form Onload에서 처리하도록 한다.
				if (this.gfnIsNull(arrComp[i].tabpages[j].url)) {
					this.gfnChangeLang(arrComp[i].tabpages[j]);
					this.gfnInitLang(arrComp[i].tabpages[j].form); //재귀함수
				}
			}
		}
		else {
			this.gfnChangeLang(arrComp[i]); //다국어설정
		}
	}
	
	// text 사이즈 변경으로 인한 화면 갱신 필요
	objForm.resetScroll();
};


/**
 * @class  해당 Component에 대해 다국어 처리
 * @param  {Object} objComp - 대상 Object
 * @return N/A
 */
pForm.gfnChangeLang = function (objComp)
{
	var sWord = "";		// 용어 code
	var sVal  = "";		// 치환될 값
	
	// Button, Static, CheckBox, Tabpage
	if (objComp instanceof nexacro.Button || objComp instanceof nexacro.Static || objComp instanceof nexacro.CheckBox || objComp instanceof nexacro.Tabpage)
	{
		sWord = objComp.uWord;
		if (this.gfnIsNull(sWord) || this.gfnIsNull(objComp.text)) return;
	
		sVal = this.gfnGetWord(sWord);
		
		if (this.gfnIsNotNull(sVal)) {
			objComp.set_text(sVal);
		}
	}
	// Grid
	else if (objComp instanceof nexacro.Grid)
	{
		objComp.set_enableevent(false);
		var nCol = objComp.getCellCount("head");

		for (var j=0; j<nCol; j++)
		{
			// Grid의 경우 용어 code를 Header의 subsumtext Property에 기술
			sWord = objComp.getCellProperty("Head", j, "subsumtext");	// 용어 code
			
			if (this.gfnIsNull(sWord)) continue;
		
			sVal = this.gfnGetWord(sWord);
			
			if (this.gfnIsNotNull(sVal)) {
				objComp.setCellProperty("Head", j, "text", String(sVal))
			}
		}
		objComp.set_enableevent(true);
	}	
};

/**
 * @class  다국어 용어 반환
 * @param  {String} sWord - 메시지ID
 * @return {Array}  arrArg - 메세지에 치환될 부분은 "{0~N}"이 되고 치환값은 배열로 넘김 
 * @return {String} 다국어 용어
 */
pForm.gfnGetWord = function (sWord, arrArg)
{
	var objApp 	  = pForm.gfnGetApplication();
	var objLangDs = objApp.gdsLang;
	var arrMsgArr = arrArg;
	
	var sVal = sWord;
	var nRow = objLangDs.findRow("MLANG_ID",sVal);
	if (nRow != -1)
	{
		sVal = objLangDs.getColumn(nRow, "MLANG_NM");
	}
	
	if (this.gfnIsArray(arrArg) == false) {
		if(this.gfnIsNotNull(arrArg)) {
			arrMsgArr = [arrArg];
		}
	}
	
	if(this.gfnIsNotNull(arrMsgArr)) {
		sVal = this.gfnConvertMessage(sVal, arrMsgArr);
	}
	
	return sVal;
};

/**
 * @class	TODO : 국가에 해당하는 날짜 포멧 반환
 * @param 	{String} sType - "DATE","DATETIME","YEARMONTH"
 * @param 	{String} sLocale - locale값(없는 경우 현재 locale)
 * @return	{String} 국가에 해당하는 날짜 포멧
 */
pForm.gfnGetFormatString = function(sType, sLocale)
{
	if(this.gfnIsNull(sLocale))		sLocale = this.gfnGetLocale();
	if(this.gfnIsNull(sLocale))		sLocale = "ko_KR";
	
	var sVal = "";
	var sDateFormat = nexacro.Locale._makeDateMaskString(sLocale, "SHORTDATE");
	
	if (sType == "DATE") {
		sVal = sDateFormat;
	} else if (sType == "YEARMONTH") {
		var localeInfo = nexacro.Locale.getLocaleInfo(sLocale);
		var sShortDate = localeInfo.shortdate_format;
		var sSeparator = sShortDate.substr(sShortDate.lastIndexOf("%")-1, 1);
		
		var arrDateFormat = sDateFormat.split(sSeparator);
		
		for(var i=arrDateFormat.length-1 ; i >=0 ; i--) {
			if (arrDateFormat[i].substr(0,1) == "d") {	// 년월일때는 일 제외
				arrDateFormat.splice(i, 1);
			}
		}
		sVal = arrDateFormat.join(sSeparator);
	} else {
		sVal = sDateFormat + " HH:mm";
	}
	
	return sVal;
};