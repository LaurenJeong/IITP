﻿/**
*  @FileName 	Grid.js 
*/
var pForm = nexacro.Form.prototype;

/*
grid propertiy
	checkbox : 체크박스
	no : 순번
	page : 페이징순번
	status : 상태
	sort : 정렬(그리드헤더더블클릭)
	
	sortasc : 오름차순 정렬(그리드우클릭)
	sortdesc : 내림차순 정렬(그리드우클릭)
	colfix : 틀고정 (열)
	rowfix : 틀고정 (행)
	filter : 그리드 필터
	find : 찾기
	colhide : 컬럼숨기기/보이기
	personal : 그리드포맷 저장
	shppr : 화주포맷 저장
	initial : 초기상태로
	
	cellcopy	: 클립보드 복사
	cellpaste	: 붙여넣기
	cellmove	: 컬럼이동
	cellsize 	: 컬럼사이즈조정
	autoenter	: autoenter
*/

pForm.defaultmenulis = "cellmove,cellsize,autoenter,sort,cellcopy,sortasc,sortdesc,colfix,find,filter,colhide,personal,shppr,initial";
pForm.popupmenulist = "sortasc,sortdesc,colfix,filter,find,colhide,personal,shppr,initial";

//소트
// 헤더 클릭시 정렬 false= 오름/내림 true= 오름/내림/없음
pForm.SORT_TOGGLECANCEL = true;
pForm.MARKER_TYPE = "text"; // 정렬 표시자 구분 (text or image)
// Grid Head 에 정렬 상태를 표시할 텍스트 또는 이미지 경로 지정 
pForm.MARKER = ["↑", "↓"];// [오름차순표시, 내림차순표시]
//pForm.MARKER = ["cell_WF_Up", "cell_WF_Down"];
//cell copy and paste 시 chorme용 textarea 저장 object
pForm.tragetGrid = "";
pForm._rowposchangedEvent = {};			//rowposition 이벤트 임시 저장 변수 20.04.04 sepia

pForm.FILTER_MARKER = "ᛉ";

pForm.COM_PAGING_CNT = 100;		// 기본페이징 수

pForm.COM_CHECK_ID = "CHK";
pForm.COM_PAGE_ID = "PAGING_NUM";
pForm.COM_STATUS_ID = "STATUS";
pForm.COM_GRIDNO_NM = "No.";
pForm.COM_GRIDSTATUS_NM = "상태";

pForm.COM_STATUS_INSERT = "C";
pForm.COM_STATUS_UPDATE = "U";
pForm.COM_STATUS_DELETE = "D";

// filter가능한 displaytype
pForm.COM_FILTER_TYPE = ["normal","calendarcontrol","date","checkboxcontrol","combocontrol"
			,"combotext","currency","editcontrol","mask","maskeditcontrol"
			,"number","text","textareacontrol"];
/**
 * @class Grid에 기능 추가
 * @param {Object} obj	- 대상그리드
 * @return N/A
 * @example
 * this.gfnSetGrid(this.grdMain);	
*/
pForm.gfnSetGrid = function(objGrid)
{
	//Grid의 binddataset설정
	var objDs = objGrid.getBindDataset();

	// grid에 바인드된 Dataset이 없는 경우 return;
	if (this.gfnIsNull(objDs)) {
		this.gfnLog(objGrid.name + "에 데이터셋이 설정되지 않아 공통기능이 적용되지 않습니다.","info");
		return;
	}
	// Validation에서 foucus 처리시 사용
	else {
		objDs.bindgrid = objGrid;
	}
	
	// Grid의 UserProperty설정
	var arrProp = this._getGridUserProperty(objGrid);
	
	// 설정할 속성 없음
	if (this.gfnIsNull(arrProp)) {
		return;
	}
	
	objGrid.set_enableevent(false);
	objGrid.set_enableredraw(false);	
	objDs.set_enableevent(false);
	
	objGrid.arrprop = arrProp;
	this._gfnGridAddProp(objGrid);
	objGrid.orgcurformat = objGrid.getCurFormatString(false);			// 개인화 전 현재포멧 저장
	
	// 그리드 개인화 설정
	var objApp = pForm.gfnGetApplication();
	var objGds = objApp.gdsGridPersonal;
	
	var sGridId = this._getUniqueId(objGrid);
	
	var sFormat, sFormatPsn, sFormatShpr, sOrgFormats, sGridFormats;
	var nCnt, nCntPsn, nCntShpr;
	var nFindRow = objGds.findRow("GRID_ID", sGridId);
	
	nCnt = this.COM_PAGING_CNT;
	
	sGridFormats = objGrid.getCurFormatString(false);//objGrid.getFormatString();
	
	if (nFindRow > -1) {
		sOrgFormats = objGds.getColumn(nFindRow, "GRID_INIT_CONTT");		// 원본포멧
		sFormatPsn	= objGds.getColumn(nFindRow, "GRID_PSN_CONTT");			// 개인화포멧
		sFormatShpr	= objGds.getColumn(nFindRow, "GRID_SHPR_CONTT");		// 화주포멧
		
		nCntPsn		= nexacro.toNumber(objGds.getColumn(nFindRow, "GRID_PSN_CNT"));		// 개인화 페이징 갯수
		nCntShpr	= nexacro.toNumber(objGds.getColumn(nFindRow, "GRID_SHPR_CNT"));	// 화주 페이징 갯수
		
		var parser      = new DomParser;//DOMParser();
		var sOrgXml     = parser.parseFromString(sOrgFormats,"text/xml").getElementsByTagName("Band")[0];
		var sGridXml    = parser.parseFromString(sGridFormats,"text/xml").getElementsByTagName("Band")[0];
		var xmlOrgNode  = sOrgXml.getElementsByTagName("Cell");
		var xmlGridNode = sGridXml.getElementsByTagName("Cell");
		var isCompare   = true;
		//자식 노드 (Cell) 갯수 비교
		if(xmlOrgNode.length != xmlGridNode.length) {
			isCompare = false;
		} else {
			var attr1 = "";
			var attr2 = "";
			var loop = 0;
			var isLoopComplete = true;
			for(var i = 0 ; i < xmlOrgNode.length ; i++) {
				//속성 갯수가 다른 경우
				var attrCnt = xmlOrgNode[i].attributes.length;
				if(attrCnt != xmlGridNode[i].attributes.length) {
					isCompare = false;
					break;
				}
				
				for(var j = 0 ; j < attrCnt ; j++) {
					attr1 = xmlOrgNode[i].attributes[j];					
					for(var k = 0 ; k < attrCnt ; k++) {
						attr2 = xmlGridNode[i].attributes[k];
						if((attr1.name != attr2.name) || (attr1.value != attr2.value) ) {							
							loop++;
						}						
					}
					
					if(loop == attrCnt) {
						isCompare      = false;
						isLoopComplete = false;
						break;
					}
					loop = 0;
				}
				
				if(!isLoopComplete) {					
					break;
				}				
			}
		}
		
		//if (sOrgFormats == sGridFormats) {		// 저장시점의 포멧과 현재화면 포멧이 변경되지 않았을 경우만 적용
		if(isCompare) {
			objGrid.orgformats = sOrgFormats;
			objGrid.shprformats = sFormatShpr;
			objGrid.shprcnt = nCntShpr;
			
			// 개인화 포멧이 있는 경우 개인화, 없는 경우 화주포멧
			if (this.gfnIsNotNull(sFormatPsn)) {
				sFormat = sFormatPsn;
				nCnt = nCntPsn;
			} else {
				sFormat = sFormatShpr;
				nCnt = nCntShpr;
			}
			
			if (this.gfnIsNotNull(sFormat)) {
				//objGrid.set_autosizingtype("none");
				objGrid.set_formats("<Formats>" + sFormat + "</Formats>");
			}
			
		} else {		// 포멧이 달라진 경우 기존 저장된 포멧은 삭제
			this.gfnLog("기본포멧이 다름 : " + sGridId);
			this._gfnTranPersonalizeReset(sGridId, objGrid);
		}
	} else {
		objGrid.orgformats = sGridFormats;
	}
	
	objGrid.pagingcnt = nCnt;
	
	// 그리드 popupmenu 미생성
	var nPopupList = nexacro.getPopupFrames(this);
	if(nPopupList.length <= 0) {
		this._gfnMakeGridPopupMenu(objGrid,arrProp);
	}
	
	// 공통팝업 제외 popupmenu 생성
	for(var i = 0; i < nPopupList.length; i++) {
		var sPopUrl      = nPopupList[nPopupList.length - 1].arguments.popupUrl;
		var sPopId       = nPopupList[nPopupList.length - 1].arguments.popupId;
		var sMenuId      = nPopupList[nPopupList.length - 1].arguments.menuId;
		var nFindGridRow = objGds.findRowExpr("String(GRID_ID).indexOf('" + sPopId + "') >= 0");
		var nFindMenuRow = objGds.findRowExpr("String(MNU_ID).indexOf('" + sMenuId + "') >= 0");
		var sDataMenuId  = objGds.getColumn(nFindGridRow, "MNU_ID");
		
		if(nFindGridRow > -1 && nFindMenuRow < 0 || nFindGridRow > -1 && nFindMenuRow > -1 && sDataMenuId != sMenuId) continue;
		
		if(sPopUrl.indexOf("COMZZZ") < 0 && i == 0) {
			this._gfnMakeGridPopupMenu(objGrid,arrProp);
		}
	}
	
	
	/*********************************************** 이벤트추가 START ***********************************************/
	objGrid.addEventHandler("onheadclick", this.gfnGrid_onheadclick, this); 		// 헤드 클릭시 체크
	objGrid.addEventHandler("onheaddblclick", this.gfnGrid_onheaddblclick, this); 	// 헤드 더블클릭시 Sort
	
	for (var k = 0, s = arrProp.length; k < s; k++) {
		var arr = this.popupmenulist.split(",");
		for (var n = 0, t = arr.length; n < t; n++) {
			if (arrProp[k] == arr[n]) {
				//우클릭 이벤트 중 하나라도 있어야 팝업 이벤트 사용 가능
				//우클릭이벤트추가 
				this._gfnEventAdd(objGrid,"onrbuttondown", this.gfnGrid_onrbuttondown);
				break;
			}
		}
		if (arrProp[k] == "cellcopy" || arrProp[k] == "cellpaste") {
			objGrid[arrProp[k]] = true;
			this._gfnEventAdd(objGrid,"onkeydown", this.gfnGrid_onkeydown);
		}
	}
	/*********************************************** 이벤트추가 END *************************************************/
	
	//로케일 정보 삽입	//테스트 내용으로 공지사항에만 적용
	if(this.gfnGetArgument("scrnId") == "ADMNTC001") {
		var locale = this.gfnGetUserInfo("LOCALE");
		if(this.gfnIsNotNull(locale) && locale != "ko_KR") {
			objGrid.set_locale(locale);
		}
	}
	
	objGrid.set_enableevent(true);
	objGrid.set_enableredraw(true);	
	objDs.set_enableevent(true);
};

/**
 * @class gfnInitGrid 그리드 초기화(체크박스 초기화)
 * @param {Object} objGrid	- 대상그리드
 * @return N/A
 * @example
 * this.gfnInitGrid(this.grdMain);	
 */
pForm.gfnInitGrid = function (objGrid)
{
	// 체크박스 클리어
	var nChkIdx = objGrid.getBindCellIndex( "body", this.COM_CHECK_ID);
	if (nChkIdx >= 0) {
		 objGrid.setCellProperty("head", nChkIdx, "text", "0");
	}
};

/**
 * @class body cell index로 binding 된 컬럼명을 얻어온다.
 * @param {Object}  grid 대상 Grid Component
 * @param {Number} headCellIndex head cell index
 * @return{String} column id
 * @example
 * this.gfnGetGridBindName(obj, e.cell);	
 */  
pForm.gfnGetGridBindName = function(grid, index) 
{
	var text = "";
	var columnid = "";
	var subCell = grid.getCellProperty("body", index, "subcell");
	if (subCell > 0) {
		text = grid.getSubCellProperty("body", index, 0, "text");
	} else {
		text = grid.getCellProperty("body", index, "text");
	}
	
	columnid = pForm._gfnGetGridBindColId(text);
	
	return columnid;
};

/**
 * @class text에서 bind 컬럼명 반환
 * @param {String} text - 체크할 문자열(grid.getCellProperty("body", index, "text"))
 * @return{String} column id
 */ 
pForm._gfnGetGridBindColId = function(text) 
{
	var columnid = "";
	
	if (this.gfnIsNotNull(text)) {
		if (text.search(/^BIND\(/) > -1) {	
			columnid = text.replace(/^BIND\(/, "");
			columnid = columnid.substr(0, columnid.length - 1);
		} else if ( text.search(/^bind:/) > -1) {
			columnid = text.replace(/^bind:/, "");
		}
	}
	
	return columnid;
};

/**
 * @class Cell index에 해당하는 bind ColId 반환(calendarweekformat) 사용
 * @param {Object} grid		- 대상그리드
 * @param {Number} index	- Cell index
 * @param {Number} nRow		- Cell의 Row값(-1인 경우 head영역)
 * @return {String}	Bind컬럼ID
 * @example
 * var sColID = this._gfnGetBindColId(this.grdMain,e.cell);	
*/
pForm._gfnGetBindColId = function(grid, index, nRow) 
{
	var bUserHeader = this._gfnGridUserHeaderFlg(grid);
	var sColId = "";
	
	if (nRow == -1) {
		if (bUserHeader) {
			sColId = pForm._gfnGetGridBindColId(grid.getCellProperty("head", index, "calendarweekformat"));
		} else {
			sColId = pForm.gfnGetGridBindName(grid, index);
		}
	} else {
		sColId = pForm.gfnGetGridBindName(grid, index);
	}
	
	return sColId;
};

/**
 * @class ColId로 Cell index에 반환.(calendarweekformat) 사용
 * @param {Object} grid		- 대상그리드
 * @param {String}	Bind컬럼ID
 * @param {Number} nRow		- Cell의 Row값(-1인 경우 head영역)
 * @return {Number} index	- Cell index
*/
pForm.gfnGetBindCellIndex = function (objGrid, sColId, nRow)
{
	var nIdx = -1;
	if (nRow == -1) {
		var bUserHeader = this._gfnGridUserHeaderFlg(objGrid);
		
		if (bUserHeader) {
			for (var i = 0; i < objGrid.getCellCount("Head"); i++) {
				if (pForm._gfnGetGridBindColId(objGrid.getCellProperty("head", i, "calendarweekformat")) == sColId)  {
					nIdx = i;
					break;
				}
			}
		} else {
			nIdx = objGrid.getBindCellIndex("body", sColId);
		}
	} else {
		nIdx = objGrid.getBindCellIndex("body", sColId);
	}
	
	return nIdx;
	
};

/**
 * @class 공통컬럼(Checkbox, 상태, No)인지 여부
 * @param {Object} grid		- 대상그리드
 * @param {Number} index	- Cell index
 * @return {Boolean} 공통컬럼(Checkbox, 상태, No)인지 여부
*/
pForm._gfnGridComnonCol = function(grid, index) 
{
	var bCommonCol = false;
	
	var sColNm = pForm._gfnGetBindColId(grid, index);
	var sHeadText = grid.getHeadValue(index);
	
	if(sColNm == this.COM_CHECK_ID 
		|| sHeadText == this.COM_GRIDNO_NM 
		|| sHeadText == this.COM_GRIDSTATUS_NM) {
		bCommonCol = true;
	}
	
	return bCommonCol;
};

/**
 * @class 유저헤더사용여부반환
 * @param {Object} objGrid - 대상그리드
 * @return {Boolean} 유저헤더사용여부 true/false
 * @example
 * this._gfnGridUserHeaderFlg(this.grdMain);
 */
pForm._gfnGridUserHeaderFlg = function (objGrid)
{
	var arr = objGrid.arrprop;
	var bUserHeader = false;
	for (var i = 0, s = arr.length; i < s; i++) {
		if (arr[i] == "userheader") {
			bUserHeader = true;
		}
	}
	return bUserHeader;
};

/**
 * @class  그리드 설정 내부함수<br>
		   그리드에 유저프로퍼티를 Array형태로 반환한다.
 * @param  {Object}objGrid	- 대상그리드
 * @return {Array} user property
 * @example
 * this._getGridUserProperty(this.grdMain);	
 */
pForm._getGridUserProperty = function (objGrid)
{
	var sProp = objGrid.commSet;
	
	var arrdefault = this.defaultmenulis.split(",");
	var arrprop = [];
	
	if (this.gfnIsNotNull(sProp)) {
		arrprop = sProp.split(",");
		for (var i = 0, s = arrprop.length; i < s; i++) {
			if (arrprop[i].indexOf("!") == 0) {
				//TODO.DEFAULT에서제거
				for (var j = 0, t = arrdefault.length; j < t; j++) {
					if (arrdefault[j] == arrprop[i].substr(1)) {
						arrdefault[j] = "";
					}
				}
				arrprop[i] = "";
			}
		}
	}
	
	var arrmyprop = [];
	for (var i = 0, s = arrdefault.length; i < s; i++) {
		if (this.gfnIsNotNull(arrdefault[i])) {
			arrmyprop.push(arrdefault[i]);
		}
	}
	
	for (var i = 0, s = arrprop.length; i < s; i++) {
		if (this.gfnIsNotNull(arrprop[i])) {
			arrmyprop.push(arrprop[i]);
		}
	}
	return arrmyprop;
};

/**
 * @class Grid에 공통 컬럼 추가(가변 그리드에서 사용)
 * @param {Object} objGrid	- 대상그리드
 * @return N/A
*/
pForm.gfnGridAddComnonCol = function (objGrid)
{
	var arrGrdProp = objGrid.arrprop;
	var arrProp = new Array();
	
	if (arrGrdProp != null) {
		for (var i = 0; i < arrGrdProp.length; i++) {
			if (arrGrdProp[i] == "checkbox"
				|| arrGrdProp[i] == "no"
				|| arrGrdProp[i] == "page"
				|| arrGrdProp[i] == "status")
			{
				arrProp.push(arrGrdProp[i]);
			}
		}
	}
	
	if (arrProp.length > 0) {
		this._gfnGridAddProp(objGrid, arrProp);
	}
};

/**
 * @class Grid에 기능 추가(addCol..)
 * @param {Object} objGrid	- 대상그리드
 * @return N/A
 * @example
 * this._gfnGridAddProp(this.grdMain);	
*/
pForm._gfnGridAddProp = function (objGrid, arrProp)
{
	if (this.gfnIsNull(arrProp))		arrProp = objGrid.arrprop;
	
	// 설정한 순서대로 표시하기 위해 역순으로 추가
	var objDs = objGrid.getBindDataset();
	for (var i = arrProp.length -1, s = 0; i >= s; i--) {
		switch (arrProp[i]) {
			case "checkbox":
				this._gfnGridCheckboxNoStatusAdd(objGrid, objDs, "checkbox");
				break;
			case "no":
				this._gfnGridCheckboxNoStatusAdd(objGrid, objDs, "no");
				break;
			case "page":
				this._gfnGridCheckboxNoStatusAdd(objGrid, objDs, "page");
				break;
			case "status":
				this._gfnGridCheckboxNoStatusAdd(objGrid, objDs, "status");
				break;
			case "sort":
				objGrid.sort = "true";
				break;
			case "filter":
				objGrid.filterInfos = {};
				
				var objDs = objGrid.getBindDataset();
				if (objDs != null) {
					objDs["orgFilterstr"] = "";
				}
				break;
			case "cellmove":
				objGrid.set_cellmovingtype("col");
				break;
			case "cellsize":
				objGrid.set_cellsizingtype("col");
				objGrid.set_cellsizebandtype("allband");
				break;
			case "autoenter":
				objGrid.set_autoenter("select");
				break;
			default: break;
		}
	}
};

/**
 * @class 공통컬럼 추가
 * @param {Object} objGrid	- 대상그리드
 * @param {Object} objDs	- 대상데이터셋
 * @param {Array} addProp	- 기능
 * @return N/A
 * @example
 * this._gfnGridCheckboxNoStatusAdd(this.grdMain, this.dsList, [checkbox,no,status]);	
*/
pForm._gfnGridCheckboxNoStatusAdd = function(objGrid, objDs, addProp)
{	
	var nHeadColIndex;
	if (this.gfnIsNull(objDs.insertheadcell)) {
		nHeadColIndex = 0;
	} else {
		nHeadColIndex = objDs.insertheadcell;
	}

	var nBodyColIndex;
	if (this.gfnIsNull(objDs.insertbodycell)) {
		nBodyColIndex = 0;
	} else {
		nBodyColIndex = objDs.insertbodycell;
	}
	
	var nFormatRowCount = objGrid.getFormatRowCount();
	var nHeadCount = -1;
	var nBodyCount = -1;
	for (var i = 0; i < nFormatRowCount; i++) {
		if (objGrid.getFormatRowProperty(i, "band") == "head") {
			nHeadCount++;
		}
		if (objGrid.getFormatRowProperty(i, "band") == "body") {
			nBodyCount++;
		}
	}

	var sNo = this.COM_GRIDNO_NM;			// 순번
	var sStatus = this.COM_GRIDSTATUS_NM;	// 상태
	var sCheckYn = this.gfnNvl(objGrid.checkboxyn, "");

	//체크박스
	if (addProp == "checkbox") {
		objDs.set_enableevent(false); 
		var idx = -1;
		for (var j = 0, s = objDs.getColCount(); j < s; j++) {
			var tmpcol = objDs.getColID(j);
			if (tmpcol == this.COM_CHECK_ID) {
				idx = j;
			}
		}
		if (idx < 0) {
			objDs.addColumn(this.COM_CHECK_ID, "STRING", 1);
		}
		objDs.set_enableevent(true); 
		
		for (var i = 0, s = objGrid.getCellCount("head"); i < s; i++) {
			//헤드텍스트
			var tmp = objGrid.getCellProperty("head", i, "text");
			if (tmp == "0") {
				// head cell index 에 해당하는 body cell index
				var bodyCellIndex = this._gfnGridGetBodyCellIndex(objGrid, i);
				// body cell index 에 해당하는 바인드 컬럼명
				var columnName = this.gfnGetGridBindName(objGrid, bodyCellIndex);
				if (columnName == this.COM_CHECK_ID) {
					//return;
					objGrid.deleteContentsCol("left", i);
				}
			}
		}
		objGrid.insertContentsCol("left", nBodyColIndex);			
		objGrid.setFormatColProperty(nBodyColIndex, "size", "30");	
		
		objGrid.setCellProperty("head", nHeadColIndex, "displaytype", "checkboxcontrol");
		objGrid.setCellProperty("head", nHeadColIndex, "edittype", "checkbox");
		objGrid.setCellProperty("head", nHeadColIndex, "text", "0");
		objGrid.setCellProperty("head", nHeadColIndex, "cssclass", "fix");
		
		if (this.gfnIsNull(sCheckYn)) {
			objGrid.setCellProperty("body", nBodyColIndex, "displaytype", "checkboxcontrol");
			objGrid.setCellProperty("body", nBodyColIndex, "edittype", "checkbox");
		} else {
			objGrid.setCellProperty("body", nBodyColIndex, "displaytype", "expr:CHK_YN=='Y'?'checkboxcontrol':'none'");
			objGrid.setCellProperty("body", nBodyColIndex, "edittype", "expr:CHK_YN=='Y'?'checkbox':'none'");
		}
		objGrid.setCellProperty("body", nBodyColIndex, "text", "bind:" + this.COM_CHECK_ID);
		
		objGrid.mergeContentsCell("head", 0, nBodyColIndex, nHeadCount, nBodyColIndex, nHeadColIndex, false);	
		objGrid.mergeContentsCell("body", 0, nBodyColIndex, nBodyCount, nBodyColIndex, nBodyColIndex, false);		
		
		nHeadColIndex++;
 		nBodyColIndex++;
		
		this._gfnEventRemove(objDs, "oncolumnchanged", this._gfn_status_oncolumnchanged);
		this._gfnEventAdd(objDs,"oncolumnchanged",this._gfn_status_oncolumnchanged,0);
	}
	//번호
	if (addProp == "no") {
		for (var i = 0, s = objGrid.getCellCount("head"); i < s; i++) {
			var tmp = objGrid.getCellProperty("head", i, "text");
			if (tmp == "NO" || tmp == this.COM_GRIDNO_NM) {
				//return;
				objGrid.deleteContentsCol("left", i);
			}
		}
		objGrid.insertContentsCol("left", nBodyColIndex);	
		objGrid.setFormatColProperty(nBodyColIndex, "size", "50");	
 		objGrid.setCellProperty("head", nHeadColIndex, "text", sNo);	
		objGrid.setCellProperty("head", nHeadColIndex, "textAlign", "center");
		objGrid.setCellProperty("head", nHeadColIndex, "cssclass", "fix");
		objGrid.setCellProperty("body", nBodyColIndex, "text", "expr:currow+1");
		objGrid.setCellProperty("body", nBodyColIndex, "textAlign", "center");
		objGrid.mergeContentsCell("head", 0, nBodyColIndex, nHeadCount, nBodyColIndex, nHeadColIndex, false);	
		objGrid.mergeContentsCell("body", 0, nBodyColIndex, nBodyCount, nBodyColIndex, nBodyColIndex, false);			
		
		nHeadColIndex++;
 		nBodyColIndex++;
	}
	//페이징번호
	if (addProp == "page") {
		for (var i = 0, s = objGrid.getCellCount("head"); i < s; i++) {
			var tmp = objGrid.getCellProperty("head", i, "text");
			if (tmp == "No." || tmp == this.COM_GRIDNO_NM) {
				//return;
				objGrid.deleteContentsCol("left", i);
			}
		}
		objGrid.insertContentsCol("left", nBodyColIndex);	
		objGrid.setFormatColProperty(nBodyColIndex, "size", "50");	
 		objGrid.setCellProperty("head", nHeadColIndex, "text", sNo);	
		objGrid.setCellProperty("head", nHeadColIndex, "textAlign", "center");
		objGrid.setCellProperty("head", nHeadColIndex, "cssclass", "fix");
		objGrid.setCellProperty("body", nBodyColIndex, "text", "bind:" + this.COM_PAGE_ID);
		objGrid.setCellProperty("body", nBodyColIndex, "textAlign", "center");
		objGrid.mergeContentsCell("head", 0, nBodyColIndex, nHeadCount, nBodyColIndex, nHeadColIndex, false);	
		objGrid.mergeContentsCell("body", 0, nBodyColIndex, nBodyCount, nBodyColIndex, nBodyColIndex, false);			
		
		nHeadColIndex++;
 		nBodyColIndex++;
	}
	//상태
	if (addProp == "status") {
		for (var i = 0, s = objGrid.getCellCount("head"); i < s; i++) {
			var tmp = objGrid.getCellProperty("head", i, "text");
			if (tmp == this.COM_GRIDSTATUS_NM || tmp == "Status") {
				//return;
				objGrid.deleteContentsCol("left", i);
			}
		}
		
		objGrid.insertContentsCol("left", nBodyColIndex);	
		objGrid.setFormatColProperty(nBodyColIndex, "size", "30");	
		objGrid.setCellProperty("head", nHeadColIndex, "text", sStatus);
		objGrid.setCellProperty("head", nHeadColIndex, "displaytype", "none");
		objGrid.setCellProperty("head", nHeadColIndex, "cssclass", "fix");
		objGrid.setCellProperty("body", nBodyColIndex, "cssclass", "bind:"+ this.COM_STATUS_ID);
		objGrid.mergeContentsCell("head", 0, nBodyColIndex, nHeadCount, nBodyColIndex, nHeadColIndex, false);	
		objGrid.mergeContentsCell("body", 0, nBodyColIndex, nBodyCount, nBodyColIndex, nBodyColIndex, false);			
		
		nHeadColIndex++;
 		nBodyColIndex++;
		
		this._gfnEventRemove(objDs, "oncolumnchanged", this._gfn_status_oncolumnchanged);
		this._gfnEventAdd(objDs,"oncolumnchanged",this._gfn_status_oncolumnchanged,0);
	}
};

/**
 * @class  그리드헤드클릭 이벤트 [Checkbox]
 * @param {Object} objGrid - 대상그리드
 * @param {Evnet}  e	   - 헤드클릭이벤트
 * @return  N/A
 * @example
 * objGrid.addEventHandler("onheadclick", 	 this.gfnGrid_onheadclick, 	 this);
 */
pForm.gfnGrid_onheadclick = function(objGrid, e)
{
// 	var sColNm = pForm._gfnGetBindColId(objGrid, e.cell);
// 	
// 	// 공통 체크인 경우만 전체체크 동작하도록 수정
// 	if(sColNm != this.COM_CHECK_ID) {
// 		return;
// 	}
// 	
	var sType = objGrid.getCellProperty("head", e.cell, "displaytype");
	if (sType == "checkboxcontrol") {
		//head display type이 checkbox일 경우 all/none check기능추가
		this.gfnHeadCheckSelectAll(objGrid, e);
	}
	
	//호출할 함수가 있는 경우 호출 ( 공통 함수명 : fnHeadColumnChanged )
	if(this.gfnIsNotNull(this.fnHeadColumnChanged)) {
		this.lookupFunc("fnHeadColumnChanged").call(objGrid, e);
	}
};

/**
 * @class  그리드헤드 더블클릭 이벤트 [Sort]
 * @param {Object} objGrid - 대상그리드
 * @param {Evnet}  e	   - 헤드클릭이벤트
 * @return  N/A
 * @example
 * objGrid.addEventHandler("onheadclick", 	 this.gfnGrid_onheadclick, 	 this);
 */
pForm.gfnGrid_onheaddblclick = function(objGrid, e)
{
	var sType = objGrid.getCellProperty("head", e.cell, "displaytype");
	var sText  = objGrid.getCellProperty("body", e.cell, "text");
	
	if (sType != "checkboxcontrol" && sText != ("bind:" + this.COM_PAGE_ID)) {
		//공통컬럼 정렬 제외 20.04.14 sepia
		var sCol = sText.replace("bind:","")
		if("REGR_ID,REGR_NM,REG_PGM_ID,REG_IP,UPDR_ID,UPDR_NM,UPD_PGM_ID,UPD_IP".indexOf(sCol) > -1) {
			return;
		}
		//sort
		if (this.gfnIsNull(objGrid.sort) || objGrid.sort == "false") {
			return;
		} else if (objGrid.sort == "true") {
			var bMultiple = false;
			var bSearch = false;
			var nCell = e.cell;
			var sSortStatus = null;
			
			if (e.ctrlkey) {
				bMultiple = true;// Ctrl 키
			}
			
			if (this.gfnIsNotNull(objGrid.sortcallbackfunc)) {			// 그리드 Sort
				bMultiple = false;
				bSearch = true;
			}
			
			this.gfnGridSort(objGrid, nCell, sSortStatus, bMultiple, bSearch);
		}
	}
};
/**
 * @class 유저헤더를 이용한 정렬
 * @param {Object} grid - 대상그리드
 * @param {Number} headCellIndex - 대상셀INDEX
 * @param {Boolean}multiple - 멀티소트여부 
 * @return N/A
 * @example
 * this._gfnGirdUserHeaderExcuteSort(objGrid);
 */
pForm._gfnGirdUserHeaderExcuteSort = function (objGrid, headCellIndex, multiple)
{
	var bindCol = objGrid.getCellProperty("head", headCellIndex, "calendarweekformat");
	if (this.gfnIsNull(bindCol)) {
		return false; //헤더에 바인드없음
	}

	var bodyCellIdx = 0;
	var nbodyCnt = objGrid.getCellCount("body");
	for (var i = 0; i < nbodyCnt; i++) {
		var tmp =  objGrid.getCellProperty("body", i, "text");
		if (tmp == bindCol) {
			bodyCellIdx = i;
			break;
		}
	}
	var rtn = this._gfnGridSetSortStatus(objGrid, headCellIndex, multiple, "", bodyCellIdx);
	if (rtn) {
		this._gfnGridExecuteSort(objGrid);
	}
};

/**
 * @class 정렬가능여부리턴
 * @param {Object} grid - 대상그리드
 * @param {Number} headCellIndex - 대상셀INDEX
 * @param {Boolean}multiple - 멀티소트여부 
 * @param {Number} sortStatus - 소트상태  
 * @return{Boolean} sort 가능/불가능 여부
 * @example
 * this._gfnGridSetSortStatus(obj, e.cell, multiple);	
 */
pForm._gfnGridSetSortStatus = function(grid, headCellIndex, isMultiple, sortStatus, bodyCellIndex, bSearch)
{
	// head cell index 에 해당하는 body cell index
	if (this.gfnIsNull(bodyCellIndex)) {
		bodyCellIndex = this._gfnGridGetBodyCellIndex(grid, headCellIndex);
	}
	if (bodyCellIndex < 0) {
		return false;
	}
	
	// body cell index 에 해당하는 바인드 컬럼명
	var columnName = this.gfnGetGridBindName(grid, bodyCellIndex);
	if (this.gfnIsNull(columnName)) {
		trace("Check Grid body cell bind value");
		return false;
	}
	
	if (this.gfnIsNull(isMultiple)) {
		isMultiple = false;
	}
	if (this.gfnIsNull(sortStatus)) {
		sortStatus = -1;
	}
	if (this.gfnIsNull(bSearch)) {
		bSearch = false;
	}
	
	// 대상 grid 에 정렬정보를 가지는 사용자 속성 확인/추가
	if (this.gfnIsNull(grid.sortInfos)) {
		grid.sortInfos = {};
	}
	
	// 정렬대상컬럼 (순서중요)
	if (this.gfnIsNull(grid.sortItems)) {
		grid.sortItems = [];
	}
	
	var sortInfos = grid.sortInfos,
		sortItems = grid.sortItems,
		sortInfo = sortInfos[columnName],
		sortItem,
		status;
	
	grid.sortSearch = bSearch;
	if (bSearch == false) {
		grid.sortSearchArg = "";
	}
	
	if (this.gfnIsNull(sortInfo)) {
		var headText = grid.getCellText(-1, headCellIndex);
		
		// executeSort에서 정렬 표시를 위해 cell index 가 필요한데
		// cell moving 될 경우 index는 변하므로 cell object 를 참조하여 값을 얻어온다. 		
		var refCell = this._gfnGridGetGridCellObject(grid, "head", headCellIndex);
		sortInfo = sortInfos[columnName] = {
			status: 0
		  , text: headText
		  , refCell: refCell
		};
	}
	
	// set sort status
	if (isMultiple) {
		status = sortInfo.status;
		if (sortStatus == -1) {
			if (status == 0) {
				sortInfo.status = 1;
			} else if (status == 1) {
				sortInfo.status = 2;
			} else if (status == 2) {
				sortInfo.status = (this.SORT_TOGGLECANCEL ? 0 : 1);
			}
		} else {
			sortInfo.status = sortStatus;
		}
	} else {
		for (var p in sortInfos) {
			if (sortInfos.hasOwnProperty(p)) {
				sortInfo = sortInfos[p];
				if (p == columnName) {
					status = sortInfo.status;
					if (sortStatus == -1) {
						if (status == 0) {
							sortInfo.status = 1;
						} else if ( status == 1 ) {
							sortInfo.status = 2;
						} else if ( status == 2) {
							sortInfo.status = (this.SORT_TOGGLECANCEL ? 0 : 1);
						}
					} else {
						if (sortInfo.status == sortStatus) {
							sortInfo.status = 0;
						} else {
							sortInfo.status = sortStatus;
						}
					}
				} else {
					sortInfo.status = 0;
				}
				if (sortInfo.status == 0) {
					for (var j = 0, len2 = sortItems.length; j < len2; j++) {
						if (sortItems[j] !== columnName) {
							sortItems.splice(j, 1);
							break;
						}
					}
				}
			}
		}
	}
	
	// 컬럼정보 등록
	var hasItem = false;
	for (var i = 0, len = sortItems.length; i < len; i++) {
		if (sortItems[i] == columnName) {
			hasItem = true;
			break;
		}
	}	
	if (!hasItem) {
		sortItems.push(columnName);
	}
	return true;
}; 

/**
 * @class head cell에 match되는 body cell을 얻어온다
 * @param {Object}  grid 대상 Grid Component
 * @param {Number} eadCellIndex head cell index
 * @return{Number}  body cell index
 * @example
 * this._gfnGridSetSortStatus(obj, e.cell, multiple);	
 */ 
pForm._gfnGridGetBodyCellIndex = function(grid, headCellIndex, useColspan) 
{	//, useColspan) 
	if( this.gfnIsNull(useColspan)) useColspan=false;
	// Max Head Row Index
	var maxHeadRow = 0;
	for (var i = 0, len = grid.getCellCount("head"); i < len; i++) {
		var row = grid.getCellProperty("head", i, "row");
		if (maxHeadRow < row) {
			maxHeadRow = row;
		}
	}
	// Max Body Row Index
	var maxBodyRow = 0;
	for (var i = 0, len = grid.getCellCount("body"); i < len; i++) {
		var row = grid.getCellProperty("body", i, "row");
		if (maxBodyRow < row) {
			maxBodyRow = row;
		}
	}
	
	if (maxHeadRow == 0 && maxBodyRow == 0) {
// 		var headcolspan = grid.getCellProperty("head", headCellIndex, "colspan");
// 		var bodycolspan = grid.getCellProperty("body", headCellIndex, "colspan");
// 		
// 		if( headcolspan == bodycolspan ){
// 			return headCellIndex;
// 		}
		useColspan = true;
	}
	
	// Body Row 가 1개 이상일 경우
	// Head의 row 가 Body의 row 보다 클 경우 차이 row 를 뺀 것을 대상으로 찾고
	// Body의 row 가 Head의 row 보다 크거나 같을 경우 row index가 같은 대상을 찾는다.			
	var cellIndex = -1;
	var sRow = -1;
	var nRow = parseInt(grid.getCellProperty("head", headCellIndex, "row"));
	var nCol = parseInt(grid.getCellProperty("head", headCellIndex, "col"));
	var nColspan = parseInt(grid.getCellProperty("head", headCellIndex, "colspan"));				
	
	if (maxHeadRow > maxBodyRow) {
		sRow = nRow - (maxHeadRow - maxBodyRow);
		sRow = (sRow < 0 ? 0 : sRow);
	} else {
		sRow = nRow;
	}
	var cRow, cCol, cColspan, cRowspan;
	for (var i = 0, len = grid.getCellCount("body"); i < len; i++) {
		cRow = parseInt(grid.getCellProperty("body", i, "row"));
		cCol = parseInt(grid.getCellProperty("body", i, "col"));	
		cColspan = parseInt(grid.getCellProperty("body", i, "colspan"));					
		cRowspan = parseInt(grid.getCellProperty("body", i, "rowspan"));
		if (cRowspan > 1) {
			if (useColspan) {
				if (sRow >= cRow && nCol <= cCol && cCol < (nCol + nColspan)) {		
					cellIndex = i;
					break;
				}
			} else {
				if (sRow >= cRow && nCol == cCol && nColspan == cColspan) {		
					cellIndex = i;
					break;
				}
			}
		} else {	
			if (useColspan) {
				if (sRow == cRow && nCol <= cCol && cCol < (nCol + nColspan)) {		
					cellIndex = i;
					break;
				}		
			} else {
				if (sRow == cRow && nCol == cCol && nColspan == cColspan) {		
					cellIndex = i;
					break;
				}
			}
		}
	}
	return cellIndex;
};

pForm.gfnGridSort = function(objGrid, nCell, sSortStatus, bMultiple, bSearch)
{
	if (this.gfnIsNull(nCell)) {
		return;
	}
	
	var arr = objGrid.arrprop;
	
	var bUserHeader = this._gfnGridUserHeaderFlg(objGrid);
	var multiple = false;
	var search = false;
	
	if (this.gfnIsNotNull(bMultiple)) {
		multiple = bMultiple;
	}
	
	if (this.gfnIsNotNull(bSearch)) {
		search = bSearch;
	}
	
	if (!bUserHeader) {
		// 정렬 상태 변경이 성공하면 정렬을 실행한다.
		var rtn = this._gfnGridSetSortStatus(objGrid, nCell, multiple, sSortStatus, null, search);
		if (rtn) {
			this._gfnGridExecuteSort(objGrid);
		}
	} else {
		this._gfnGirdUserHeaderExcuteSort(objGrid, nCell, multiple, search);
	}
};
/**
 * @class 소트를 실행한다
 * @param {Object}  grid 대상 Grid Component
 * @return{String}  N/A
 * @example
 * this._gfnGridExecuteSort(obj);	
 */  
pForm._gfnGridExecuteSort = function(grid) 
{
	var sortInfo, 
		sortItem,
		sortInfos = grid.sortInfos,
		sortItems = grid.sortItems,
		columnName,
		status,
		cell,
		sortString = "";
		
	if (this.gfnIsNull(sortInfos) || this.gfnIsNull(sortItems)) {
		return;
	}

	// keystring 조합
	for (var i = 0, s = sortItems.length; i < s; i++) {
		columnName = sortItems[i];
		sortInfo = sortInfos[columnName];
		status = sortInfo.status;
		cell = sortInfo.refCell;
		
		// 컬럼삭제 등으로 제거될 수 있으므로 실제 column 이 존재하는지
		// 확인하여 없으면 제거해 준다.
		if (this.gfnIsNull(cell) || grid.getBindCellIndex("body", columnName) < 0) {
			// 컬럼정보제거
			sortItems.splice(i, 1);
			sortInfos[columnName] = null;
			delete sortInfos[columnName];
			
			i--;
		} else if (status > 0) {
			sortString += (status == 1 ? "+" : "-") + columnName;
		}
	}
	
	var ds = grid.getBindDataset();
	// keystring 확인
	var curKeyString = ds.keystring;
	var groupKeyString = "";
	
	if (curKeyString.length > 0 && curKeyString.indexOf(",") < 0) {
		var sIndex = curKeyString.indexOf("S:");
		var gIndex = curKeyString.indexOf("G:");

		if (sIndex > -1) {
			groupKeyString = "";
		} else {
			if (gIndex < 0) {
				groupKeyString = "G:" + curKeyString;
			} else {
				groupKeyString = curKeyString;
			}
		}
	} else {
		var temps = curKeyString.split(",");
		var temp;
		for (var i = 0, len = temps.length; i < len; i++) {
			temp = temps[i];
			if (temp.length > 0 && temp.indexOf("S:") < 0) {
				if (temp.indexOf("G:") < 0) {
					groupKeyString = "G:" + temp;
				} else {
					groupKeyString = temp;
				}
			}
		}
	}
	
	if (sortString.length > 0) {
		var sortKeyString = "S:" + sortString;
		
		if (grid.sortSearch == true) {
			ds.set_keystring(groupKeyString);
		} else {
			if (groupKeyString.length > 0) {
				ds.set_keystring(sortKeyString + "," + groupKeyString);
			} else {
				ds.set_keystring(sortKeyString);
			}
		}
		
		grid.sortKeyString = sortKeyString;
	} else {		
		ds.set_keystring(groupKeyString);
		grid.sortKeyString = "";
	}
	
	// 정렬표시
	var type = this.MARKER_TYPE;
	var index, marker;
	var sSortCol, sStatus = 0;
	
	for (var p in sortInfos) {
		if ( sortInfos.hasOwnProperty(p) )
		{
			sortInfo = sortInfos[p];			
			cell = sortInfo.refCell;
			
			//20.04.06 sepia 정렬 오류 수정
			if(p == columnName) {
				sSortCol = p;
				sStatus = sortInfo.status;
			}
			
			if ( cell )
			{
				index = cell._cellidx;
				marker = this.gfnDecode(sortInfo.status, 1, this.MARKER[0], 2, this.MARKER[1], "");
				grid.setCellProperty( "head", index, "text", sortInfo.text + marker);
			}
		}
	}
	
	var sSortArg = "";
	
	if (grid.sortSearch == true) {			// 그리드 Sort
		if (this.gfnIsNotNull(sSortCol) && sStatus != 0) {
			sSortArg =  " CMM_SRT_COL=" + nexacro.wrapQuote(this.gfnNvl(sSortCol,""));
			sSortArg += " CMM_SRT_WAY=" + nexacro.wrapQuote(this.gfnDecode(sStatus, 1, "ASC", 2, "DESC", ""));
		}
		
		grid.sortSearchArg = sSortArg;
		
		try {
			var svcId = grid.name;
			
			this.lookupFunc(grid.sortcallbackfunc).call(svcId, sSortArg); 
		} catch(e) {
			this.gfnLog(sCallback+ "() 함수 실행시 오류가 발생했습니다. \n" + e.message);
		}
	}
};

/**
 * @class 그리드 Sort시 사용한 파라미터값 반환
 * @param {Object}  grid 대상 Grid Component
 * @return{String}  N/A
 */ 
pForm.gfnGetGridSort = function(grid)
{
	var sSortArg = "";
	
	if (grid.sortSearch == true) {			// 그리드 Sort
		sSortArg = grid.sortSearchArg;
	}
	
	return sSortArg;
};

/**
 * Cell object 를 반환 (Grid 내부 속성이므로 get 용도로만 사용)
 * @param {Grid} grid 대상 Grid Component
 * @param {string} band 얻고자 하는 cell 의 band (head/body/summ);
 * @param {number} index 얻고자 하는 cell 의 index
 * @return {object} cell object
 */
pForm._gfnGridGetGridCellObject = function(grid, band, index)
{
	// 내부속성을 통해 얻어온다.
	var refCell;
	var format = grid._curFormat;
	if (format) {
		if (band == "head") {
			refCell = format._headcells[index];
		} else if (band == "body") {
			refCell = format._bodycells[index];
		} else if (band == "summ" || band == "summary") {
			refCell = format._summcells[index];
		}
	}
	return refCell;
};

/**
 * @class 그리드의 Sort Mark 제거
 * @param {Object} Grid 대상그리드
 * @return N/A
 */  
pForm.gfnClearSortMark = function(obj)
{
	var sortInfos = obj.sortInfos;
	var sortItems = obj.sortItems;
	
	if (this.gfnIsNull(sortInfos) || this.gfnIsNull(sortItems)) {
		return;
	}
	
	// 정렬상태 초기화.
	for (var j = 0, s = sortItems.length; j < s; j++) {
		var col = sortItems[j];
		var sortInfo = sortInfos[col];
		sortInfo.status = 0;
	}
	
	// 정렬실행
	this._gfnGridExecuteSort(obj);
	
	// 정보 초기화
	obj.sortInfos = {};
	obj.sortItems = [];
};

/**
 * @class  그리드헤드클릭이벤트 내부함수 (헤드클릭시 체크 ALL/None)
 * @param {Object} objGrid - 대상그리드
 * @param {Evnet}  e	   - 헤드클릭이벤트
 * @param {String}  sCheckYn - 체크여부 컬럼ID
 * @return  N/A
 * @example
 * this.gfnHeadCheckSelectAll(objGrid, e); //ALL CHECK
 */
pForm.gfnHeadCheckSelectAll = function (objGrid, e)
{
	var sCHkYn =  objGrid.getCellProperty("head", e.cell, "combodataset");
	if (objGrid.readonly == true || sCHkYn == "none") {
		return;
	}
	
	var sType;
	var sChk;
	var sVal;
	var sChkVal;
	var oDsObj;
	var nHeadCell = e.cell;
	var nBodyCell;
	var nSubCnt = objGrid.getSubCellCount("head", nHeadCell);
	var sCheckYn;
	
	oDsObj = objGrid.getBindDataset();
	
	if (oDsObj.getRowCount() < 1) {
		return;
	}
	
	if (objGrid.getCellCount("body") != objGrid.getCellCount("head")) {
		nBodyCell = parseInt(objGrid.getCellProperty("head", nHeadCell, "col"));
	} else {
		nBodyCell = e.cell;
	}
	sChkVal = objGrid.getCellProperty("body", nBodyCell, "text");
	sChkVal = sChkVal.toString().replace("bind:", "");
		
	// Merge한 셀이 없는 경우
	sType = objGrid.getCellProperty("head", nHeadCell, "displaytype");

	if (sType != "checkboxcontrol") {
		return;
	}
	
	// 공통인 경우 그리드 속성값으로 처리, 그외는 subsumtext로 처리
	if (sChkVal == pForm.COM_CHECK_ID) {
		sCheckYn = this.gfnNvl(objGrid.checkboxyn, "");
	} else {
		sCheckYn = this.gfnNvl(objGrid.getCellProperty("head", nHeadCell, "subsumtext"), "");
	}
	
	// Head셋팅
	sVal = objGrid.getCellProperty("head", nHeadCell, "text");

	if (sVal == "0") {
		objGrid.setCellProperty("head", nHeadCell, "text", "1");
		sChk = 1;
	} else {
		objGrid.setCellProperty("head", nHeadCell, "text", "0");
		var bodyCellIndex = this._gfnGridGetBodyCellIndex(objGrid, nHeadCell);
		// body cell index 에 해당하는 바인드 컬럼명
		var columnName = this.gfnGetGridBindName(objGrid, bodyCellIndex);
		if (columnName == this.COM_CHECK_ID) {
			 sChk = 0;
		} else {
			sChk = 0;
		}
	}
	
	// Body셋팅
	oDsObj.set_enableevent(false);
	for (var i = 0, s = oDsObj.rowcount; i < s; i++) {
		if (this.gfnIsNull(sCheckYn)) {
			oDsObj.setColumn(i, sChkVal, sChk);
		} else {
			if (oDsObj.getColumn(i, sCheckYn) == "Y") {
				oDsObj.setColumn(i, sChkVal, sChk);
			}
		}
	}
	oDsObj.set_enableevent(true);
};

/**
 * @class  마우스우클릭시 표현될 팝업메뉴생성
 * @param 	{Object} objGrid - 대상그리드
 * @param	{Array} arrProp - 그리드 설정값
 * @return  N/A
 * @example
 * this._gfnGetHeadBodyIndex(this.grdMain, this.dsMain);	
 */
pForm._gfnMakeGridPopupMenu = function (objGrid, arrProp)
{
	var objApp = pForm.gfnGetApplication();
	var objMenuDs = objApp.gdsGridPopupMenu;
	var objParentForm = objGrid.parent;
	
	var sPopupDsMenu = "dsPopupMenu_" + objGrid.name + "_" + this.name;
	var objPopupDs = new Dataset(sPopupDsMenu);
	objParentForm.addChild(sPopupDsMenu, objPopupDs); 
	objPopupDs.copyData(objApp.gdsGridPopupMenu);
	
	// Auth설정
	this._gfnSetAuthPopUpMenu(objPopupDs, arrProp);
	
	var sPopMenu = "popMenu_" + objGrid.name + "_" + this.name;
	var objPopMenu = new PopupMenu(sPopMenu, 0, 0, 100, 100);
	
	objParentForm.addChild(objPopMenu.name, objPopMenu);
	
	objPopMenu.set_innerdataset(sPopupDsMenu);
	objPopMenu.set_captioncolumn("CAPTION");
	objPopMenu.set_enablecolumn("ENABLE");
	objPopMenu.set_idcolumn("ID");
	objPopMenu.set_levelcolumn("LEVEL");
	objPopMenu.set_userdatacolumn("USERDATA");
 	objPopMenu.addEventHandler("onmenuclick", this.gfnPopupmenu_onmenuclick, objParentForm);
	objPopMenu.show();
	
	//objPopMenu.set_itemheight(28);
	
	objPopMenu.grid = objGrid;
	objGrid.popupMenu = objPopMenu;
};

/**
 * @class  	그리드메뉴 데이터셋 권한값 설정
 * @param  	{Object} objPopupDs	- 대상 그리드
 * @param	{Array} arrProp - 그리드 설정값
 * @return  N/A
 */
pForm._gfnSetAuthPopUpMenu = function (objPopupDs, arrProp)
{
	var sMenu, sUpMenu;
	var nFRow, nUpRow;
	
	var bAdmin = this.gfnIsMdulAdmin();
	
	for (var i = 0, s = arrProp.length; i < s; i++) {
		for (var j = 0, t = objPopupDs.rowcount; j < t; j++) {
			sMenu = objPopupDs.getColumn(j, "ID");
			if (this.gfnIsNull(sMenu)) {
				continue;
			}
			
			if (sMenu.indexOf(arrProp[i]) > -1) {
				
				// 화주포멧 저장 권한 체크
				if (sMenu == "shppr") {
					if (bAdmin == false) {		// 화주권한이 없는 경우 권한 설정 안함.
						continue;
					}
				}
				
				objPopupDs.setColumn(j, "AUTH", "Y");
				
				// '-' 설정
				if (objPopupDs.getColumn(j, "LEVEL") == 0 && j>0) {
					nFRow = objPopupDs.findRowExpr("GROUPID == '" + objPopupDs.getColumn(j, "GROUPID") + "' && CAPTION=='-'");
					if (nFRow > 0) {
						objPopupDs.setColumn(nFRow, "AUTH", "Y");
						
						if (objPopupDs.getColumn(j, "HEADYN") == "Y") {
							objPopupDs.setColumn(nFRow, "HEADYN", "Y");
						}
						
						if (objPopupDs.getColumn(j, "BODYYN") == "Y") {
							objPopupDs.setColumn(nFRow, "BODYYN", "Y");
						}
					}
				}
				
				// 하위레벨인 경우 상위레벨 enable설정
				if (objPopupDs.getColumn(j, "LEVEL") == 1) {
					sUpMenu = objPopupDs.getColumn(j, "UPMENU");
					nUpRow = objPopupDs.findRow("ID", sUpMenu);
					if (nUpRow > -1) {
						objPopupDs.setColumn(nUpRow, "AUTH", "Y");
					}
				}
			}
		}
	}
	
	// 화주포멧 저장 권한 있는 경우 개인포멧 저장 불가
	if (bAdmin == true) {		// 화주권한이 없는 경우 권한 설정 안함.
		var nFRow = objPopupDs.findRow("ID","shppr");
		if (objPopupDs.getColumn(nFRow, "AUTH") == "Y") {
			nFRow = objPopupDs.findRow("ID","personal");
			if (objPopupDs.getColumn(nFRow, "AUTH") == "Y") {
				objPopupDs.setColumn(nFRow, "AUTH","N");
			}
		}
	}
};

/**
 * @class  	우클릭한 위치에따라 그리드 공통메뉴 활성화/비활성화 설정
 * @param 	{Object} objGrid - 대상그리드
 * @param  	{String} sColId	- 컬럼ID
 * @param	{Number} nHeadCell - Head Cell Index
 * @param	{Number} nBodyCell - Body Cell Index
 * @param	{Number} nRow - Row index
 * @return  N/A
 */
pForm.gfnSetEnablePopUpMenu = function (objGrid, sColId, nHeadCell, nBodyCell, nRow)
{
	var objMenuDs = objGrid.popupMenu.getInnerDataset();
	var sMenuId, sComMenu, sGroupId;
	
	var sHeadText = objGrid.getHeadValue(nHeadCell);
	var bCommCol = pForm._gfnGridComnonCol(objGrid, nHeadCell);
	var sDisplayType = objGrid.getCellProperty("body", nBodyCell, "displaytype");
	
	objMenuDs.filter("");
	
	// '-'라벨 처리
	var nFRow = objMenuDs.findRow("HEADYN", "Y");
	if (objMenuDs.getColumn(nFRow,"CAPTION") == "-") {
		objMenuDs.setColumn(nFRow,"HEADYN","N");
	}
	
	nFRow = objMenuDs.findRow("BODYYN", "Y");
	if (objMenuDs.getColumn(nFRow,"CAPTION") == "-") {
		objMenuDs.setColumn(nFRow,"BODYYN","N");
	}
	
	var sFilter = "AUTH=='Y'";
	
	if (nRow == -1) {
		sFilter += " && HEADYN=='Y'";
		
	} else {
		sFilter += " && BODYYN=='Y'";
	}
	
	objMenuDs.filter(sFilter);
	
	//trace(objMenuDs.saveXML());
	
	for(var i=0; i < objMenuDs.rowcount; i++) {
		sMenuId 	= objMenuDs.getColumn(i,"ID");
		sComMenu	= objMenuDs.getColumn(i,"USERDATA");
		sGroupId	= objMenuDs.getColumn(i,"GROUPID");
		
		if (sComMenu != "COM")				continue;
		if (this.gfnIsNull(sMenuId))		continue;
		
		// 초기화
		objMenuDs.setColumn(i,"ENABLE","true");
		
		// cell과 row 영역이 아닌곳에서 우클릭시, 포멧관련 메뉴가 아닌 경우 사용못함.
		if ((nHeadCell == -1 && nRow == -9)) {
			if (sGroupId != "PERSONAL") {
				objMenuDs.setColumn(i,"ENABLE","false");
				continue;
			}
		}
		
		if (sMenuId == "sortasc" || sMenuId == "sortdesc") {
			
			if (this.gfnIsNull(sColId))	{
				objMenuDs.setColumn(i,"ENABLE","false");
			}
			
			// 공통컬럼 제외
			if(bCommCol) {
				objMenuDs.setColumn(i,"ENABLE","false");
			}
		} else if(sMenuId == "filter") {
			// 바인드된 컬럼 있는지 체크
			if (this.gfnIsNull(sColId))	{
				objMenuDs.setColumn(i,"ENABLE","false");
			}
			
			// 공통컬럼 제외
			if(bCommCol) {
				objMenuDs.setColumn(i,"ENABLE","false");
			}
			
			// displaytype 체크
			if (this.gfnIsExistInArray(this.COM_FILTER_TYPE, sDisplayType) == false) {
				objMenuDs.setColumn(i,"ENABLE","false");
			}
		} else if(sMenuId == "colfix") {
			if (nHeadCell < 0) {
				objMenuDs.setColumn(i,"ENABLE","false");
			}
		} else if(sMenuId == "rowfix") {
			if (nRow < 0) {
				objMenuDs.setColumn(i,"ENABLE","false");
			}
		}
	}
};

/**
 * @class  마우스우클릭이벤트
 * @param  {Object} objGrid	- 대상그리드
 * @param  {Event}  e		- 우클릭이벤트 
 * @return  N/A
 * @example
 * this.gfnGrid_onrbuttondown(this.grdMain, this.dsMain);	
 */
pForm.gfnGrid_onrbuttondown = function (objGrid, e)
{
	// 그리드 엑셀 권한
	var objApp = pForm.gfnGetApplication();
	
	var objPopupMenu = objGrid.popupMenu;
	if (this.gfnIsNull(objPopupMenu))		return;
	
	var nCell = e.cell;
	var nRow = e.row;
	var nCol = e.col;
	var nHeadCell, nBodyCell;
	
	var sColId = pForm._gfnGetBindColId(objGrid, nCell, nRow);
	
	if (nRow == -1) {
		nHeadCell = nCell;
		nBodyCell = this.gfnGetBindCellIndex(objGrid, sColId, 0);
	} else {
		nBodyCell = nCell;
		nHeadCell = this.gfnGetBindCellIndex(objGrid, sColId, -1);
	}
	
	// 대상 그리드와 셀 정보를 추가
	objGrid.popupMenu.grid = objGrid;
	objGrid.popupMenu.colId = sColId;
	objGrid.popupMenu.cellindex = nCell;
	objGrid.popupMenu.rowindex = nRow;
	objGrid.popupMenu.colindex = nCol;
	objGrid.popupMenu.headcellidx = nHeadCell;
	objGrid.popupMenu.bodycellidx = nBodyCell;
	

	// trackPopupByComponent 이용
	var x = nexacro.toNumber(system.getCursorX()) - nexacro.toNumber(system.clientToScreenX(objGrid, 0));
	var y = nexacro.toNumber(system.getCursorY()) - nexacro.toNumber(system.clientToScreenY(objGrid, 0));
	
	// 스튜디오 사용시 팝업메뉴 위치 조정
	var sRunMode = nexacro.getEnvironmentVariable("evQuikView");
	if (sRunMode == "Y") {
		y += 83;
	}
	
	// 그리드 공통팝업메뉴 Enable 설정
	this.gfnSetEnablePopUpMenu(objGrid, sColId, nHeadCell, nBodyCell, nRow);
	
	objGrid.popupMenu.trackPopupByComponent(objGrid, x, y);
};

//////////////////////////////////////////////////////////////////////////Popupmenu//////////////////////////////////////////////////////////////////////////
/**
 * @class  gfnCreatePopupMenu 내부함수로 팝업메뉴 클릭 시 발생하는 이벤트
 * @param {Object} objGrid	- 대상그리드
 * @param {Evnet}  e 		- 팝업메뉴클릭이벤트
 * @return N/A
 * @example
 * this.gfnPopupmenu_onmenuclick(this.grdMain, nexacro.MenuClickEventInfo);	
 */
pForm.gfnPopupmenu_onmenuclick = function (objMenu, e)
{
	var selectId  	= e.id;
	var grid 	   	= objMenu.grid;
	var sColId		= objMenu.colId;
	var nCellIndex 	= objMenu.cellindex;	
	var nRowIndex  	= objMenu.rowindex;
	var nColIndex  	= objMenu.colindex;
	var nHeadCell	= objMenu.headcellidx;
	var nBodyCell	= objMenu.bodycellidx;

	switch(selectId) {
		case "sortasc":		// 오름차순 정렬
			this.gfnGridSort(grid, nHeadCell, 1);
			break;
		case "sortdesc":	// 내림차순 정렬
			this.gfnGridSort(grid, nHeadCell, 2);
			break;
		case "colfix": 		// 틀고정 열
			grid.fixedCol = nColIndex;
			this._gfnGridcellFix(grid, nCellIndex, nRowIndex);
			break;
		case "colfixfree": // 틀고정 열 해제
			this._gfnGridCellFree(grid);
			break;
		case "rowfix": 		// 틀고정 행
			if(nRowIndex<0) return;
			grid.fixedRow = nRowIndex;
			this._gfnGridSetCssclass(grid);
			break;
		case "rowfixfree": // 틀고정 행 해제
			grid.fixedRow = -1;
			this._gfnGridSetCssclass(grid);
			break;
		case "filter": 		// 필터
			this._gfnGridFilter(grid, sColId, nHeadCell, nBodyCell);
			break;
		case "filterfree": // 필터해제
			this._gfnGridCellFilterFree(grid);
			break;
		case "find": 		// 찾기
			this._gfnGridCellFind(grid, nCellIndex, nRowIndex);
			break;
		case "colhide": 	// 컬럼숨기기
			this._gfnGridColHideShow(grid, nRowIndex);
			break;	
		case "colhidefree": // 컬럼숨기기 해제
			this._gfnGridColHideShowFree(grid);
			break;	
		case "personal": 	// 그리드포맷 저장
			this._gfnGridPersonalize(grid);
			break;
		case "shppr": 		// 화주포맷 저장
			this._gfnGridPersonalizeShppr(grid);
			break;
		case "initial": 	// 초기화
			this._gfnGridPersonalizeInit(grid);
			break;
		default: break;
	}
};

/**
 * @class 그리드 우클릭 POPUPMENU 내부함수<br>
		  셀고정(colfix)
 * @param {Object} objGrid  - 대상그리드
 * @param {Number} nCellIdx - 셀고정 셀인덱스
 * @param {Number} nRowIdx  - 셀고정 로우 인덱스
 * @return N/A
 * @example
 * this._gfnGridcellFix(this.grdMain, 1, 2);	
 */
pForm._gfnGridcellFix = function (objGrid, nCellIdx, nRowIdx)
{
	var sBandType;
	if (nRowIdx == -1) {
		sBandType = "Head";
	} else if (nRowIdx == -2) {
		sBandType = "Summary";
	} else {
		sBandType = "Body";
	}
	
	var nCol = nexacro.toNumber(objGrid.getCellProperty(sBandType, nCellIdx, "col"));
	var nColSpan = nexacro.toNumber(objGrid.getCellProperty(sBandType, nCellIdx, "colspan"));
	var nRowSpan = nexacro.toNumber(objGrid.getCellProperty(sBandType, nCellIdx, "rowspan"));
	var nVal = objGrid.getCellpos
	var nMaxCol = 0;
	var i;
	var nRealCol;
	var nRealColSpan;
	var nRealColEnd;
	var nFixCol = nCol;
	var sCssClass, orgCssClass;
	
	objGrid.set_enableredraw(false);
	
	objGrid.setFormatColProperty(0, "band", "body");	
	
	for (var i = 0, s = objGrid.getCellCount("Head"); i < s; i++) {
		nRealCol = nexacro.toNumber(objGrid.getCellProperty("Head", i, "col"));
		nRealColSpan = nexacro.toNumber(objGrid.getCellProperty("Head", i, "colspan"));
		
		nRealColEnd = nRealCol + nRealColSpan - 1;
		
		sCssClass = objGrid.getCellProperty("Head", i, "cssclass");
		orgCssClass = objGrid.getCellProperty("Head", i, "calendardisplaynulltext");
		
		// Body에서 사용할 Col값 셋팅
		if (nRealCol == nCol || nRealColEnd == nCol) {
			if (nRealColSpan > 1) {
				nCol = nRealColEnd;
			} else {
				nCol = nRealColEnd;
			}
		}
		
		// 디자인 설정
		if (this.gfnIsNull(orgCssClass)) {
			objGrid.setCellProperty("Head", i, "calendardisplaynulltext", sCssClass);
		} else {
			sCssClass = orgCssClass;
		}
		
		if (nRealCol <= nFixCol || nRealColEnd <= nFixCol) {
			if (sCssClass == "essential") {
				objGrid.setCellProperty("Head", i, "cssclass", "fix_essential");
			} else {
				objGrid.setCellProperty("Head", i, "cssclass", "fix");
			}
		} else {
			objGrid.setCellProperty("Head", i, "cssclass", "");
		}
	}	
	
	objGrid.setFormatColProperty(nCol, "band", "left");	
	objGrid.set_enableredraw(true);
};

/**
 * @class 그리드 우클릭 POPUPMENU 내부함수<br>
		  셀고정해제(colfree)
 * @param {Object} objGrid - 대상그리드
 * @return N/A
 * @example
 * this._gfnGridCellFree(this.grdMain);	
 */
pForm._gfnGridCellFree = function(objGrid)
{
	var sCss, sOrgCss, sCssClass;
	var nComIdx = -1;
	
	for (var i = 0, s = objGrid.getFormatColCount(); i < s; i++) {
		objGrid.setFormatColProperty(i, "band", "body");	
	}
	
	for (var i = 0, s = objGrid.getCellCount("Head"); i < s; i++) {
		sCss 	= objGrid.getCellProperty("Head", i, "cssclass");
		sOrgCss = objGrid.getCellProperty("Head", i, "calendardisplaynulltext");
		
		// 디자인 설정
		if (this.gfnIsNull(sOrgCss)) {
			sCssClass = sCss;
		} else {
			sCssClass = sOrgCss;
		}
		
		if (sCssClass == "fix_essential" || sCssClass == "essential") {
			objGrid.setCellProperty("Head", i, "cssclass", "essential");
		} else if (sCssClass == "fix" ) {
			objGrid.setCellProperty("Head", i, "cssclass", "");
		}
	}
	
	objGrid.fixedCol = -1;
};

/**
 * @class  _gfnGridSetCssclass 행고정/해제시 css설정
 * @param {Object} objGrid	- 대상그리드
 * @return N/A
 * @example
 * this._gfnGridSetCssclass(this.grdMain);	
 */
pForm._gfnGridSetCssclass = function (objGrid)
{
	var clname = "grdWF_cell_fixed";
	clname = nexacro.wrapQuote(clname);
			
	objGrid.set_enableredraw(false);

	for (var k = 0, s = objGrid.getFormatColCount(); k < s; k++) {
		var expr = "";
		if (objGrid.fixedRow >= 0) {
			expr = "expr:comp.fixedRow==currow?" + clname + ":''";
		}
		objGrid.setCellProperty("body", k, "cssclass", expr);
	}
	objGrid.set_enableredraw(true);
	objGrid.setFixedRow(objGrid.fixedRow);
};

/**
 * @class 그리드 우클릭 POPUPMENU 내부함수<br>
          셀필터(cellFilter)
 * @param	{Object} objGrid - 대상그리드	
 * @param  	{String} sColId	- 컬럼ID
 * @param	{Number} nHeadCell - Head Cell Index
 * @param	{Number} nBodyCell - Body Cell Index
 * @return N/A
 * @example
 * this._gfnGridFilter(this.grdMain);	
 */
pForm._gfnGridFilter = function(objGrid, sColId, nHeadCell, nBodyCell)
{
	var sHeadText = pForm.gfnIsNullEmpty(objGrid.getHeadValue(nHeadCell));
	var bCommCol = pForm._gfnGridComnonCol(objGrid, nHeadCell);
	
	if(this.gfnIsNull(sColId)) return;
	if(bCommCol) return;
	
	var oArg = {pvGrid: objGrid
				, pvColId : sColId
				, pvColHeadNm : sHeadText
				, pvHeadCell : nHeadCell
				, pvBodyCell : nBodyCell
				};
	var oOption		= {title:"데이터 필터 설정", width:300, height:384, popuptype:"modal"};
	var sPopupCallBack = "gfnGridFilterCallback";
	this.gfnPopup("comGridFilterPop", "pop::comGridFilterPop.xfdl", oArg, sPopupCallBack, oOption);	
};

/**
 * @class 그리드 우클릭 POPUPMENU 내부함수<br>
          셀필터해제(cellfilterfree)
 * @param {Object} objGrid - 대상그리드
 * @return N/A
 * @example
 * this._gfnGridCellFilterFree(this.grdMain);	
 */
pForm._gfnGridCellFilterFree = function(objGrid)
{
	var objDs = objGrid.getBindDataset();
	var sOrgFilterstr = this.gfnGetOrgFilterstr(objGrid);
	
	objDs.set_filterstr(sOrgFilterstr);
	
	// 헤더 클리어
	var sHeadText = "";
	for (var i = 0; i < objGrid.getCellCount("Head"); i++) {
		sHeadText 	= objGrid.getCellProperty("Head", i, "text");
		if (pForm.gfnIsNotNull(sHeadText)) {
			if (sHeadText.substr(0,1) == pForm.FILTER_MARKER) {
				objGrid.setCellProperty("head", i, "text", sHeadText.substr(1));
			}
		}
	}
	
	objGrid.filterInfos = {};
	//필터 취소시 필터 마크 제거
	if(this.gfnIsNotNull(objGrid.sortInfos)) {
		var len = Object.keys(objGrid.sortInfos).length;
		if(len > 0) {
			for(var key in objGrid.sortInfos) {				
				objGrid.sortInfos[key].text = objGrid.sortInfos[key].text.replace('ᛉ','')
			}
		}
	}
};

/**
 * @class 공통Filter를 사용할때 필터 함수
 * @param {Object} obj - 대상그리드
 * @param {String} sFilterStr - 필터문자열
 * @param {Boolean} bComFilterClear - 공통Filter 초기화할지 여부
 * @return N/A
 * @example
 * this.gfnFilter(obj, sFilterStr, bComFilterClear);	
 */
pForm.gfnFilter = function(obj, sFilterStr, bComFilterClear)
{
	var objGrd;		// 대상 그리드
	var objDs;		// 대상 데이터셋
	var sFilter = sFilterStr;
	
	if( obj instanceof nexacro.Grid ){		//obj 가 콤보일경우
		objGrd = obj;
		objDs = obj.getBindDataset();
	} else if( obj instanceof Dataset){		//obj 가 데이터셋일경우
		objGrd = null;
		objDs = obj;
	}
	
	if(this.gfnIsNull(objDs))		return false;
	if(this.gfnIsNull(bComFilterClear))		bComFilterClear = true;
	if(this.gfnIsNull(objGrd) && bComFilterClear == false)	bComFilterClear = true;
	
	objDs["orgFilterstr"] = sFilter;
	
	// 공통Filter유지
	if (bComFilterClear == false) {			// 그리드 공통 필터 유지
		sFilter = this.gfnGetFilterstr(objGrd,sFilterStr);
	} else {								// 그리드 공통 필터 초기화
		this._gfnGridCellFilterFree(objGrd);
	}
	
	objDs.filter(sFilter);
	
};

/**
 * @class gfnFilter()함수로 설정한 filter 문자열 반환
 * @param {Object} obj - 대상그리드
 * @return {String} filter 문자열
 */
pForm.gfnGetOrgFilterstr = function (obj)
{
	var objGrd;		// 대상 그리드
	var objDs;		// 대상 데이터셋
	
	var sOrgFilterStr = "";
	
	if( obj instanceof nexacro.Grid ){		//obj 가 콤보일경우
		objGrd = obj;
		objDs = obj.getBindDataset();
	} else if( obj instanceof Dataset){		//obj 가 데이터셋일경우
		objGrd = null;
		objDs = obj;
	}
	
	sOrgFilterStr = objDs["orgFilterstr"];
	
	return sOrgFilterStr;
};

/**
 * @class 그리드에 설정된 filter값을 기준으로 filter문자열 반환
 * @param {Object} objGrid - 대상그리드
 * @param {String} sAppandFilterstr - 추가할 Filter문자열
 * @return {String} filter 문자열
 */
pForm.gfnGetFilterstr = function (objGrid, sAppandFilterstr)
{
	if(this.gfnIsNull(objGrid)) 		return;
	
	var sFilterFull = "";
	var sFilter;
	var arrFilter = new Array();
	
	if(this.gfnIsNotNull(sAppandFilterstr)) {
		arrFilter.push("(" + sAppandFilterstr + ")");
	}
	
	var oFilterInfos = objGrid.filterInfos;
	
	for(var colId in oFilterInfos) {
		sFilter = oFilterInfos[colId].filter;
		
		if(this.gfnIsNotNull(sFilter)) {
			arrFilter.push(sFilter);
		}
	}
	
	if (arrFilter.length > 0) {
		sFilterFull = arrFilter.join(" && ");
	}
	
	return sFilterFull;
};

/**
 * 대상 그리드에서 주어진 컬럼에 해당하는 필터 정보를 반환한다.
 * @param {Grid} grid - 대상 Grid Component
 * @param {string} columnName - 컬럼명
 * @param {Boolean} bInfo - 필터정보 객체 반환여부
 * @return {string} filterstr
 * @memberOf nxlib.grid
 */
pForm._gfnGetFilterInfo = function(grid, columnName, bInfo)
{
	if (this.gfnIsNull(bInfo))		bInfo = false;
	
    var filterInfos = grid.filterInfos;
	var objColInfo = filterInfos[columnName];
	var ret;
	var sFilter = "";
	
	if (this.gfnIsNotNull(objColInfo)) {
		sFilter = objColInfo.filter;
	}
	
	if (bInfo) {
		ret = objColInfo;
	} else {
		ret = sFilter;
	}

    return ret;
}

/**
 * 대상 그리드에 주어진 컬럼에 해당하는 필터 정보를 지정한다.
 * @param {Grid} grid - 대상 Grid Component
 * @param {string} columnName - 컬럼명
 * @param {string} datas - 필터값
 * @param {string} sType - 필터타입(1 : 필터선택, 2 : 필터조건) 
 * @param {Object} oInfo - 필터정보(필터조건일때 사용)
 * @return N/A
 */
pForm._gfnSetFilterInfo = function(grid, columnName, datas, sType, oInfo)
{
    var filterInfos = grid.filterInfos;

	if(this.gfnIsNull(datas)) {
		delete filterInfos[columnName];
	} else {
		var objFilterInfo = {
			filter			: datas
			, filtertype	: sType
			, filterinfo	: oInfo
		};
		filterInfos[columnName] = objFilterInfo;
	}
}


/**
 * @class 그리드 우클릭 POPUPMENU 내부함수<br>
          찾기(find)
 * @param {Object} objGrid - 대상그리드	
 * @param {Number} nCell - 셀필터 셀 인덱스
 * @param {Number} nRowIndex - Row 인덱스
 * @return N/A
 * @example
 * this._gfnGridCellFind(this.grdMain);	
 */
pForm._gfnGridCellFind = function(objGrid,nCellIndex,nRowIndex)
{
	var orgselecttype = objGrid.selecttype;

	var oArg = {
		pvGrid: objGrid
	  , pvStrartRow: nRowIndex
	  , pvSelectCell: nCellIndex
	  , pvSelectType: orgselecttype
	};
	var oOption		= {title:this.gfnGetWord("DAT_SRCH"), width:"320", height:"270", popuptype:"modeless", topmost : true};
	var sPopupCallBack = "gfnFindCallback";
	this.gfnPopup("comGridFilterPop", "pop::comGridFindPop.xfdl", oArg, sPopupCallBack, oOption);	
};

/**
 * @class 그리드 우클릭 POPUPMENU 내부함수<br>
          컬럼 숨기기/보이기(colhide)
 * @param {Object} objGrid - 대상그리드	
 * @return N/A
 * @example
 * this._gfnGridColHideShow(this.grdMain);	
 */
pForm._gfnGridColHideShow = function(objGrid)
{
	var oArg = {pvGrid: objGrid};
	var oOption		= {title:"컬럼 보이기/숨기기", width:"300", height:"405", popuptype:"modal", topmost : true};
	var sPopupCallBack = "gfnColumnHidCallback";
	this.gfnPopup("comGridColumnHidePop", "pop::comGridColumnHidePop.xfdl", oArg, sPopupCallBack, oOption);	
};

/**
 * 대상 그리드에 숨겨진 모든 칼럼을 보여준다.
 * @param  {Grid} grid 대상 Grid Component
 */
pForm._gfnGridColHideShowFree = function(objGrid)
{
	var bAdmin  = this.gfnIsMdulAdmin();			// 권한 있는지 체크
	var objDs   = this.gfnGetApplication().gdsGridPersonal;
	var mdulCd  = this.gfnGetArgument("mdulCd");
	var mnuId   = this.gfnGetArgument("menuId");
	var grdId   = this._getUniqueId(objGrid);
	var shprCd  = this.gfnGetUserInfo("DFT_SHPPRCO_CD");
	var sFormat = "";
	
	for(var i = 0; i < objDs.rowcount; i++) {
		var sMdulCd = objDs.getColumn(i, "MDUL_CD");
		var sMnuId  = objDs.getColumn(i, "MNU_ID");
		var sGridId = objDs.getColumn(i, "GRID_ID");
		var sShprCd = objDs.getColumn(i, "SHPPRCO_CD");
		
		if(sMdulCd == mdulCd && sMnuId == mnuId && sGridId == grdId) {
			if(bAdmin) {
				if(sShprCd == shprCd) {
					sFormat = objDs.getColumn(i, "GRID_SHPR_CONTT");
					break;
				} else {
					sFormat = objDs.getColumn(i, "GRID_INIT_CONTT");
					break;
				}
			} else {
				if(this.gfnIsNull(objDs.getColumn(i, "GRID_PSN_CONTT"))) {
					sFormat = objDs.getColumn(i, "GRID_INIT_CONTT");
					break;
				} else {
					sFormat = objDs.getColumn(i, "GRID_PSN_CONTT");
					break;
				}
			}
		} else {
			sFormat = objGrid.orgformats;
		}
	}
	
	objGrid.set_formats("<Formats>" + sFormat + "</Formats>");
	
	// 다국어 처리
	this.gfnChangeLang(objGrid);
	
	/*원래 Source*/
	/*objGrid.set_enableevent(false);
	objGrid.set_enableredraw(false);
	for( var i=0; i<objGrid.getFormatColCount(); i++)
	{
		nOrgSize = this._gfnGetGridOrgColsize(objGrid,i,bAdmin);
		
		if (nOrgSize > 0) {
			objGrid.setFormatColProperty(i, "size", nOrgSize);
			objGrid.setCellProperty("head", i, "expandchar","");
		}
	}
	objGrid.set_enableredraw(true);
	objGrid.set_enableevent(true);*/
};

/**
 * 컬럼 숨기기 전 원본 컬럼 사이즈 반환
 * @param {Object} objGrid - 대상그리드	
 * @param {Number} nCol - Col 인덱스
 * @param {Boolean} bAdmin - 업무관리자 여부(true:원본 사이즈, false : 화주포멧 사이즈)
 * @return {Number} 원본 컬럼 사이즈
 */
pForm._gfnGetGridOrgColsize = function(objGrid,nCol,bAdmin)
{
	if (this.gfnIsNull(bAdmin))		bAdmin = false;
	
	var sExpandChar = this.gfnNvl(objGrid.getCellProperty("head", nCol, "expandchar"), "").toString();
	var arrOrgSize, nOrgSize;
	
	if (this.gfnIsNull(sExpandChar)) {
		if (objGrid.autofittype != "col") {
			nOrgSize = objGrid.getRealColSize(nCol);
		} else {
			nOrgSize = objGrid.getFormatColSize(nCol);
		}
	} else {
		arrOrgSize 	= sExpandChar.split("||");
		nOrgSize 	= nexacro.toNumber(arrOrgSize[0],0);
		
		if (nOrgSize == -1 && bAdmin) {
			nOrgSize =  nexacro.toNumber(arrOrgSize[1],0);
		}
	}
	
	return nOrgSize;
};

/**
 * @class 그리드 우클릭 POPUPMENU 내부함수<br>
          그리드 개인화
 * @param {Object} objGrid - 대상그리드	
 * @return N/A
 * @example
 * this._gfnGridPersonalize(this.grdMain);	
 */
pForm._gfnGridPersonalize = function(objGrid)
{
	// 그리드 포멧 저장 하시겠습니까? -> 변경된 그리드형식내역을 저장 하시겠습니까?
	this.gfnConfirm("MSG_CFM_PROC_CHGSAVE_SINGLE", "GRID_FMT", "confirm_personal_" + objGrid.name, function (msg, flag)
	{
		if (flag == true) {
			this._gfnGridPersonalizeExcute(objGrid,"psn");
		}
	});
};

/**
 * @class 그리드 우클릭 POPUPMENU 내부함수<br>
          화주포멧
 * @param {Object} objGrid - 대상그리드	
 * @return N/A
 * @example
 * this._gfnGridPersonalize(this.grdMain);	
 */
pForm._gfnGridPersonalizeShppr = function(objGrid)
{
	var sDftShpprcoCd = this.gfnGetUserInfo("DFT_SHPPRCO_CD");
	if (this.gfnIsNull(sDftShpprcoCd)) {
		// {0}을(를) 선택해 주십시요.
		this.gfnAlert("MSG_ALT_DATA_BEFORESELECT",this.gfnGetWord("DFT_SHPPRCO_CD"));
		return;
	}
	
	// 그리드 포멧 저장 하시겠습니까?\n 화주포멧을 변경하신 경우, 해당 그리드의 모든 유저포멧이 삭제됩니다.
	this.gfnConfirm("MSG_SHIP_GRID_SAVE_FORMAT", "", "confirm_shppr_" + objGrid.name, function (msg, flag)
	{
		if (flag == true) {
			this._gfnGridPersonalizeExcute(objGrid,"shpr");
		}
	});
};

/**
 * @class 그리드 우클릭 POPUPMENU 내부함수<br>
          그리드 개인화 초기화
 * @param {Object} objGrid - 대상그리드	
 * @return N/A
 * @example
 * this._gfnGridPersonalizeInit(this.grdMain);	
 */
pForm._gfnGridPersonalizeInit = function(objGrid)
{
	var bAdmin = this.gfnIsMdulAdmin();		// 관리자여부
	var sType = bAdmin ? "shpr" : "psn";	// shpr : 화주, psn : 개인
	var sMsgId = bAdmin ? "MSG_SHIP_DEFAULT_GRID_FORMAT" : "MSG_DEFAULT_GRID_FORMAT";
	
	if (sType == "shpr") {
		var sDftShpprcoCd = this.gfnGetUserInfo("DFT_SHPPRCO_CD");
		if (this.gfnIsNull(sDftShpprcoCd)) {
			// {0}을(를) 선택해 주십시요.
			this.gfnAlert("MSG_ALT_DATA_BEFORESELECT",this.gfnGetWord("DFT_SHPPRCO_CD"));
			return;
		}
	}
	
	// 포멧을 초기화 하시겠습니까?
	this.gfnConfirm(sMsgId, "", "confirm_personalizeInit_" + objGrid.name, function (msg, flag)
	{
		if (flag == true) {
			this._gfnGridPersonalizeInitExcute(objGrid,sType);
		}
	});
};

/**
 * @class 그리드 우클릭 POPUPMENU 내부함수<br>
          그리드 개인화내용 저장을 위해 유니크한 아이디를 구성한다.
 * @param {Object} objGrid - 대상그리드	
 * @return N/A
 * @example
 * this._gfnGridPersonalize(this.grdMain);	
 */
pForm._getUniqueId = function (objGrid)
{
	var sFormId;
	var oForm = objGrid.parent; //대상FORM조회
	while (true) {
		if (oForm instanceof nexacro.ChildFrame) {
			break;
		} else {
			oForm = oForm.parent;
		}
	}
	
	var sMenuId = this.gfnGetArgument("menuId");
	var sPopupId = this.gfnGetArgument("popupId");
	var sPopupUrl = this.gfnGetArgument("popupUrl");
	
	sFormId = oForm.name;
	
	if (sFormId.indexOf("FRAMEWORK_") > -1) {
		// 메뉴ID + 화면 form명
		sFormId = sMenuId + "_" + oForm.form.fvDivWork.form.name;
	} else if (this.gfnIsNotNull(sPopupId)) {
		if (this.gfnIsNotNull(sPopupUrl)) {
			sFormId = sPopupId + "_" + oForm.form.fvDivWork.form.name;
		}
	}
	
	var otf = objGrid.parent.parent;
	if (otf instanceof nexacro.Tabpage) {
		//탭안에 그리드가 있을경우
		sFormId += "_" + otf.parent.name +"_"+ otf.name;
	} else if (otf instanceof nexacro.Div && otf.name != "divWork") {
		//div안에 그리드가 있을경우
		sFormId += "_" + otf.name;
	}
	sFormId += "_" + objGrid.name;
	return sFormId;
};

/**
 * @class 그리드 헤드 텍스트 초기화
 * @param {Object} objGrid - 대상그리드	
 * @return N/A
 */
pForm._gfnClearHeadMark = function(objGrid)
{
	// 헤더 클리어
	var sHeadText = "";
	
	for (var i = 0; i < objGrid.getCellCount("Head"); i++) {
		sHeadText = pForm._gfnGetClearHeadMark(objGrid,i);
		
		objGrid.setCellProperty("head", i, "text", sHeadText);
	}
};

/**
 * @class 헤드 text값에서 필터, sort 마커를 제외한 값 반환
 * @param {Object} objGrid - 대상그리드	
 * @param {Number} nHeadCell - Head Cell Index
 * @return {String} 초기화된 text값
 */
pForm._gfnGetClearHeadMark = function(objGrid, nHeadCell)
{
	var sHeadText = "";
	var sMarker = "";
	
	sHeadText 	= objGrid.getCellProperty("Head", nHeadCell, "text");
		
	if (pForm.gfnIsNotNull(sHeadText)) {
	
		// Filter Text 제거
		sMarker = sHeadText.substr(0,1);
		if (sMarker == pForm.FILTER_MARKER) {
			sHeadText = sHeadText.substr(1);
		}
		
		// Sort Text 제거
		sMarker = this.gfnRight(sHeadText, 1);
		if (sMarker == pForm.MARKER[0] || sMarker == pForm.MARKER[1]) {
			sHeadText = sHeadText.substring(0, sHeadText.length -1);
		}
	}
	
	return sHeadText;
};
/**
 * @class 그리드 개인화실행.
 * @param {Object} objGrid - 대상그리드	
 * @param {String} sType - 개인화타입(shpr : 화주, psn : 개인)
 * @return N/A
 */
pForm._gfnGridPersonalizeExcute = function (objGrid, sType)
{
	var sGridId		= this._getUniqueId(objGrid);
	var sFormat		= objGrid.getCurFormatString(false);
	var sOrgFormats	= objGrid.orgformats;
	var oBindDs		= objGrid.getBindDataset();
	
	if(this.gfnIsNull(sOrgFormats)) {
		this.gfnAlert("MSG_VLD_DATA_NOTEXIST", this.gfnGetWord("BAS_GRID_FMT")); // 기본그리드형식이(가) 존재하지 않습니다.
		//this.gfnAlert("MSG_VLD_DATA_NOTEXIST", [this.gfnGetWord("BAS_GRID_FMT"), this.gfnGetMessage("MSG_ALT_DATA_BEFORESAVE", this.gfnGetWord("BAS_GRID_FMT"))]); // 기본그리드형식이(가) 존재하지 않습니다. 기본그리드형식을 저장해주세요.
		return;
	}
	
	//--------------------------------------------------------------------------
	// 그리드 포멧값 구하기
	//--------------------------------------------------------------------------
	// 포멧 저장용 그리드 생성
	var name = "_temp_" + sGridId;
	var objTempGrid = new Grid(name, "absolute", 0, 0, 0, 0);
	this.addChild(name, objTempGrid);
	objTempGrid.set_visible(false);
	objTempGrid.show();
	
	//var strFormatContents = objGrid.getCurFormatString();
	objTempGrid.set_formats("<Formats>" + sFormat + "</Formats>");
	
	var nSize, nOrgSize, sHeadText;
	var nColCnt = objTempGrid.getFormatColCount();
	
	objGrid.set_enableredraw(true);
	for (var i = 0; i < objTempGrid.getFormatColCount("Head"); i++) {
		sHeadText = pForm._gfnGetClearHeadMark(objTempGrid,i);
		
		objTempGrid.setCellProperty("head", i, "text", sHeadText);
		
		if (i < nColCnt && sType == "shpr") {
			nOrgSize 	= this._gfnGetGridOrgColsize(objTempGrid,i);
			nSize		= objTempGrid.getRealColSize(i);
			
			if (nSize <= 1 && nOrgSize != 0) {
				nOrgSize 	= this._gfnGetGridOrgColsize(objTempGrid,i,true);
				objTempGrid.setCellProperty("head", i, "expandchar","-1" + "||" + nOrgSize);
				objGrid.setCellProperty("head", i, "expandchar","-1" + "||" + nOrgSize);
			}
		}
	}
	objGrid.set_enableredraw(true);
	
	sFormat = objTempGrid.getCurFormatString(false);
	
	this.removeChild(name); 
	objTempGrid.destroy(); 
	objTempGrid = null;

	
	//--------------------------------------------------------------------------
	// 그리드 View갯수 구하기
	//--------------------------------------------------------------------------
	var nPagingCnt = null;
	var sPagingType = this.gfnNvl(objGrid["pagingType"],"none");
	if (sPagingType != "none") {
		var objPagingForm = objGrid["pagingform"];
		if (this.gfnIsNotNull(objPagingForm)) {
			var objPageInfo = objPagingForm.fnGetPagingInfo();
			if (this.gfnIsNotNull(objPageInfo)) {
				nPagingCnt = objPageInfo["pagingLimit"];
			}
		};
	}
	
	//--------------------------------------------------------------------------
	// 포멧저장
	//--------------------------------------------------------------------------
	var objApp = pForm.gfnGetApplication();
	var objGds = objApp.gdsGridPersonal;
	
	var sFormatColId	= "GRID_PSN_CONTT";
	var sCntColId		= "GRID_PSN_CNT";
	
	if (sType == "shpr") {
		sFormatColId 	= "GRID_SHPR_CONTT";
		sCntColId 		= "GRID_SHPR_CNT";
	}
	
	var nFindRow = objGds.findRow("GRID_ID", sGridId);
	if (nFindRow == -1) {
		var nRow = objGds.addRow();
		var sMdulCd = this.gfnGetArgument("mdulCd");
		objGds.setColumn(nRow, "MDUL_CD", sMdulCd);
		objGds.setColumn(nRow, "GRID_ID", sGridId);
		objGds.setColumn(nRow, sFormatColId, sFormat);
		objGds.setColumn(nRow, "GRID_INIT_CONTT", sOrgFormats);
		objGds.setColumn(nRow, sCntColId, nPagingCnt);
	} else {
		objGds.setColumn(nFindRow, sFormatColId, sFormat);
		objGds.setColumn(nFindRow, "GRID_INIT_CONTT", sOrgFormats);
		objGds.setColumn(nFindRow, sCntColId, nPagingCnt);
		
		if (sType == "shpr") {
			objGds.setColumn(nFindRow, "GRID_PSN_CONTT", "");
		}
	}

	// 개인화 저장
	this._gfnTranPersonalize(sType);
};

/**
 * @class 그리드 개인화 초기화 실행.
 * @param {Object} objGrid - 대상그리드	
 * @param {String} sType - 개인화타입(shpr : 화주, psn : 개인)
 * @return N/A
 */
pForm._gfnGridPersonalizeInitExcute = function(objGrid,sType)
{
	var sGridId	= this._getUniqueId(objGrid);
	
	var objApp = pForm.gfnGetApplication();
	var objGds = objApp.gdsGridPersonal;
	
	var nFindRow = objGds.findRow("GRID_ID", sGridId);
	var sGridSn = objGds.getColumn(nFindRow,"BAS_GRID_SN");
	
	// 그리드 초기화
	this._gfnGridInitFormat(objGrid, sType);
	
	// 데이터셋 초기화
	var sFormatColId	= "GRID_PSN_CONTT";
	var sCntColId		= "GRID_PSN_CNT";
	
	if (sType == "shpr") {
		sFormatColId 	= "GRID_SHPR_CONTT";
		sCntColId 		= "GRID_SHPR_CNT";
	}
	
	var nFindRow = objGds.findRow("GRID_ID", sGridId);
	if (nFindRow >= 0) {
		objGds.setColumn(nFindRow, sFormatColId, "");
		objGds.setColumn(nFindRow, sCntColId, "");
		
		if (sType == "shpr") {
			objGds.setColumn(nFindRow, "GRID_PSN_CONTT", "");
		}
	}
	
	if (this.gfnIsNull(sGridSn))		return;
	
	// DB저장
	this._gfnTranPersonalizeInit(sType);
};

/**
 * @class 그리드 우클릭 POPUPMENU 내부함수<br>
          그리드 초기화
 */	
pForm._gfnGridInitFormat = function(objGrid, sType)
{
	var sOrgFormat	= objGrid.orgcurformat;	//objGrid.getFormatString();
	var sShprFormat = objGrid.shprformats;
	
	var sFormat = sOrgFormat;
	
	// 화주포멧이 있고 일반유저인 경우 화주포멧으로 설정
	if(pForm.gfnIsNotNull(sShprFormat) && sType == "psn") {
		sFormat = sShprFormat;
	}
	
	objGrid.set_enableevent(false);
	objGrid.set_enableredraw(false);	
	
	objGrid.set_formats("<Formats>" + sFormat + "</Formats>");
	
	//this._gfnGridCellFree(grid);
	//this.gfnClearSortMark(grid);
	//this._gfnGridAddProp(objGrid);
	
	objGrid.set_enableevent(true);
	objGrid.set_enableredraw(true);	
	
	var nCnt = this.COM_PAGING_CNT;
	var nCntShpr = objGrid["shprcnt"];
	
	// 화주포멧이 있고 일반유저인 경우 화주포멧으로 설정
	if(pForm.gfnIsNotNull(nCntShpr) && sType == "psn") {
		nCnt = nCntShpr;
	}
	
	objGrid.pagingcnt = nCnt;
	
	var sPagingType = this.gfnNvl(objGrid["pagingType"],"none");
	if (sPagingType != "none") {
		var objPagingForm = objGrid["pagingform"];
		if (this.gfnIsNotNull(objPagingForm)) {
			objPagingForm.fnSetPageCnt(nCnt);
		};
	}
	
	// 다국어 처리
	this.gfnChangeLang(objGrid);
};

/**
 * 개인화 저장
 */
pForm._gfnTranPersonalize= function (sType)
{
	var sSearchId = "";
	var sMenuId= this.gfnGetArgument("menuId");
	
	if(pForm.gfnIsNull(sMenuId))		return;
	
	if (sType == "shpr") {
		sSearchId = "/common/saveShipperGridInfo.do";
	} else {
		sSearchId = "/common/savePersonalGridInfo.do";
	}
	
	var sSvcId		= "gfnTranPersonalize";
	var sSvcUrl 	= this.gfnGetPreUrl() + sSearchId;
	var sInData 	= "IN_GRID_PERSONAL_LIST=gdsGridPersonal:U";
	var sOutData 	= "gdsGridPersonal=OUT_GRID_PERSONAL_LIST";
	var sParam 		= "";

	this.gfnTransaction(sSvcId, sSvcUrl, sInData, sOutData, sParam, "gfnGridPersonalizeCallback");
};

/**
 * 개인화 초기화
 */
pForm._gfnTranPersonalizeInit= function (sType)
{
	var sSearchId = "";
	var sMenuId= this.gfnGetArgument("menuId");
	
	if(pForm.gfnIsNull(sMenuId))		return;
	
	if (sType == "shpr") {
		sSearchId = "/common/saveShipperGridInit.do";
	} else {
		sSearchId = "/common/savePersonalGridInit.do";
	}
	
	var sSvcId = "gfnTranPersonalizeInit" + sType;
	var sSvcUrl = this.gfnGetPreUrl() + sSearchId;
	var sInData = "IN_GRID_PERSONAL_LIST=gdsGridPersonal:U";
	var sOutData = "gdsGridPersonal=OUT_GRID_PERSONAL_LIST";
	var sParam = "";

	this.gfnTransaction(sSvcId, sSvcUrl, sInData, sOutData, sParam, "gfnGridPersonalizeCallback");
};

/**
 * 그리드 개인화 삭제
 */
pForm._gfnTranPersonalizeReset = function(sGridId, objGrid)
{
	var sSearchId = "/common/saveGridReset.do";
	var sMenuId   = this.gfnGetArgument("menuId");
	
	if(pForm.gfnIsNull(sMenuId))		return;
	
	var objApp   = this.gfnGetApplication();
	var objGds   = objApp.gdsGridPersonal;
	var nFindRow = objGds.findRow("GRID_ID", sGridId);
	if(nFindRow > -1) {
		//objGds.setColumn(nFindRow, "GRID_SHPR_CONTT", "");
		objGds.setColumn(nFindRow, "GRID_INIT_CONTT", objGrid.getCurFormatString());
		objGrid.orgformats = objGrid.getCurFormatString(false);
	}
	
	var sSvcId   = "gfnTranPersonalizeReset";
	var sSvcUrl  = this.gfnGetPreUrl() + sSearchId;
	var sInData  = "IN_GRID_PERSONAL_LIST=gdsGridPersonal:U";
	var sOutData = "gdsGridPersonal=OUT_GRID_PERSONAL_LIST";
	var sParam   = "RESET_GRID_ID=" + nexacro.wrapQuote(this.gfnIsNullEmpty(sGridId));

	this.gfnTransaction(sSvcId, sSvcUrl, sInData, sOutData, sParam, "gfnGridPersonalizeCallback");
};

/**
 * @description Transaction CallBack 함수(선택)
*/
pForm.gfnGridPersonalizeCallback = function(svcID,errorCode,errorMsg)
{
};

//////////////////////////////////////////////////////////////////////////POPUPMENU CALLBACK///////////////////////////////////////////////////////////
/**
 * @class 그리드 우클릭 POPUPMENU 내부함수<br>
          그리드 찾기/바꾸기 팝업 콜백
 * @param {String} sid - popupid	
 * @param {String} rtn - return value	 
 * @return N/A
 * @example
 * this.gfnReplaceCallback("TEST", "");	
 */
pForm.gfnFindCallback = function (sid, rtn)
{
	//TODO
};

/**
 * @class 그리드 우클릭 POPUPMENU 내부함수<br>
          그리드 필터 팝업 콜백
 * @param {String} sid - popupid	
 * @param {String} rtn - return value	 
 * @return N/A
 * @example
 * this.gfnGridFilterCallback("TEST", "");	
 */
pForm.gfnGridFilterCallback = function (sid, rtn)
{
	//TODO
};

/**
 * @class 그리드 우클릭 POPUPMENU 내부함수<br>
          그리드 컬럼숨기기/보이기
 * @param {String} sid - popupid	
 * @param {String} rtn - return value	 
 * @return N/A
 * @example
 * this.gfnColumnHidCallback("TEST", "");	
 */
pForm.gfnColumnHidCallback = function (sid, rtn)
{
	//TODO
};

//////////////////////////////////////////////////////////////////////////POPUPMENU FUNCTION///////////////////////////////////////////////////////////
/**
 * @class   주어진 문자열을 그리드에서 찾는다.
 * @param {Object} grid - 대상그리드	
 * @param {String} findText - 찾을 문자열	
 * @param {Object} option - 찾기옵션	
 * @return {Object} 찾은 열과행
 * @example
 * this.gfnFindGridText(this.fv_grid, txt, option);
 */
pForm.gfnFindGridText = function (grid, findText, option)
{
	grid.lastFindText = findText;
	grid.lastFindOption = option;

	// 찾을 옵션
	var direction = option.direction;
	var position = option.position;
	var scope = option.scope;
	var condition = option.condition;
	var strict = option.strict;

	var dataset = grid.getBindDataset();
	var startCell = ( position == "current" ? grid.currentcell : grid.lastFindCell );
	var startRow = ( position == "current" ? grid.currentrow : grid.lastFindRow );
	
	// 바꾸기에서 호출시 (option.cell 은 바꾸기에서만 지정)
	if ( scope == "col" && !this.gfnIsNull(option.cell) )
	{
		startCell = option.cell;
	}
	
	var findRow = findCell = -1;
	var rowCnt = dataset.rowcount;
	var bodyCellCnt = grid.getCellCount("body");
			
	// 대소문자 구분
	if ( !strict )
	{
		findText = findText.toUpperCase();			
	}
		
	if ( direction == "prev" )
	{
		startRow -= 1;	
		if ( startRow < 0 )
		{
			startRow = rowCnt-1;
		}
	}
	else
	{
		startRow += 1;
		if ( startRow >= rowCnt )
		{
			startRow = 0;
		}
	}
	
	var loopCnt = rowCnt;
	while ( loopCnt > 0 )
	{
		// 문자열 비교
		if ( this._gfnCompareFindText(grid, startRow, startCell, findText, condition, strict) )
		{
			findRow = startRow;
			findCell = startCell;
			break;
		}
		
		// 방향 (이전, 다음)
		if ( direction == "prev" )
		{
			startRow -= 1;
			if ( startRow < 0 )
			{
				startRow = rowCnt-1;
			}				
		}
		else
		{
			startRow += 1;
			if ( startRow > (rowCnt-1) )
			{
				startRow = 0;
			}
		}
		
		loopCnt--;
	}
	// 마지막 찾은 위치 지정
	// 팝업에서 찾을 방향을 "처음부터" 로 변경 시 초기화
	if ( findRow > -1 && findCell > -1 )
	{
		grid.lastFindRow = findRow;
		grid.lastFindCell = findCell;
	}
	
	return [findRow, findCell];
};

 /**
 * @class   주어진 행, 셀 인덱스에 해당하는 그리드 데이터와 <br>
 * 문자열을 비교하여 찾아진 결과를 반환
 * @param {Object} grid - 대상 Grid Component
 * @param {Number} row - 찾을 행 인덱스
 * @param {Number} cell - 찾을 셀 인덱스
 * @param {String} findText - 찾을 문자열
 * @param {String} condition - 찾을 조건(equal/inclusion)
 * @param {Boolean} strict - 대소문자 구분 (true/false)
 * @return {Boolean} - 찾기 성공.
 * @example
 * this._gfnCompareFindText(grid, startRow, startCell, findText, condition, strict) 
 */
pForm._gfnCompareFindText = function(grid, row, cell, findText, condition, strict)
{
	var cellText = grid.getCellText(row, cell);
	if( this.gfnIsNull(cellText))return;
	var displayType = grid.getCellProperty("body", cell, "displaytype");
		
	// displayType 이 normal일 경우
	// dataType 을 체크하여 displayType 을 변경
	if ( this.gfnIsNull(displayType) || displayType == "normal" )
	{
		var dataType = this.gfnGetBindColumnType(grid, cell);
		switch(dataType)
		{
			case 'INT' :
			case 'FLOAT' :
			case 'BIGDECIMAL' :
				displayType = "number";
				break;
			case 'DATE' :
			case 'DATETIME' :
			case 'TIME' :
				displayType = "date";
				break;
			default :
				displayType = "string";
		}
	}
	
	// currency 의 경우 원(￦) 표시와 역슬레시(\) 다르므로 제거 후 비교
	if ( displayType == "currency" )
	{
		var code = cellText.charCodeAt(0);
		if ( code == 65510 || code == 92 )
		{
			cellText = cellText.substr(1);
		}
		
		code = findText.charCodeAt(0);
		if ( code == 65510 || code == 92 )
		{
			findText = findText.substr(1);
		}
	}

	// 대소문자 구분
	if ( !strict )
	{
		cellText = cellText.toUpperCase();
	}
	// 일치/포함
	if ( condition == "equal" )
	{
		if ( findText == cellText )
		{
			return true;
		}
	}
	else 
	{
		if ( cellText.indexOf(findText) > -1 )
		{			
			return true;
		}
	}

	return false;
};

 /**
 * @class   데이터의 타입반환
 * @param {Object} grid - 대상 Grid Component
 * @param {Number} cell - 찾을 셀 
 * @return {String} 데이터 타입
 * @example
 *  this.gfnGetBindColumnType(grid, cell);
 */
pForm.gfnGetBindColumnType = function(grid, cell)
{
	var dataType = null;
	var dataset = this.gfnLookup(grid.parent, grid.binddataset);
	var bindColid = grid.getCellProperty("body", cell, "text");
		bindColid = bindColid.replace("bind:", "");
	
	if (this.gfnIsNotNull(bindColid)) {
		var colInfo = dataset.getColumnInfo(bindColid);
		if (this.gfnIsNotNull(colInfo)) {
			dataType = colInfo.type;
		}
	}
	
	return dataType;
};

//////////////////////////////////////////////////////////////////////////CELL COPY AND PASTE//////////////////////////////////////////////////////////////////////////
/**
 * @class  그리드키다운 이벤트 [cellcopypaste]
 * @param {Object} objGrid - 대상그리드
 * @param {Evnet}  e	   - 키다운이벤트
 * @return  N/A
 * @example
 * objGrid.gfnGrid_onkeydown("onheadclick", 	 this.gfnGridOnheadclick, 	 this);
 */
 
 /*
	[v_0.1] 최초 있던 파일
 */
 
// pForm.gfnGrid_onkeydown =function(objGrid, e){
// 	var keycode = e.keycode;
// 	var sBrowser = system.navigatorname;
// 	if (e.ctrlkey) {
// 		if (keycode == 67) {
// 			if (objGrid.cellcopy == true) {
// 				if (objGrid.selectstartrow.length > 1)	{
// 					// 다중선택 범위에서는 사용할 수 없는 명령입니다.
// 					this.gfnAlert("MSG_ALT_FUNC_NOTUSED");
// 					return;
// 				}
// 				
// 				// 현재 셀에 선택된 Text가 있는 경우 기본 복사하기 진행
// 				var sSelectText = objGrid.getEditSelectedText();
// 				if (this.gfnIsNotNull(sSelectText))		return;
// 				
// 				//copy
// 				if (sBrowser == "nexacro" || sBrowser == "IE") {
// 					trace ("복사 넥사 이에");
// 					this._gfnGridCopyEventForRuntime(objGrid, e);
// 				} else {
// 					trace ("그 외");
// 					this._gfnGridCopyEventForChrome(objGrid, e);
// 				}
// 			}
// 		} else if(keycode == 86) {
// 			// 기존에 있던 if 문 주석처리
// 			//if (objGrid.cellpaste == true) {
// 			
// 				// 붙여넣기 할 그리드의 데이터셋에 데이터가 없을때
// 				// 일단 한개의 row 를 추가
// 				var ds = objGrid.getBindDataset();
// 				if (objGrid.rowcount < 1) {
// 					ds.addRow();
// 				}
// 				trace ("붙이기");
// 			
// 				//paste
// 				this._gfnGridPasteEvent(objGrid, e);
// 
// 			//}
// 		}
// 	}
// };

 /*
	[v_0.2] 수정한 파일
	런타임 / 익스플로러에서 가능, 크롬에서 불가능
 */
// pForm.gfnGrid_onkeydown =function(objGrid, e){
// 	var keycode = e.keycode;
// 	var sBrowser = system.navigatorname;
// 	var v_clip = "";
// 	if (e.ctrlkey) {
// 		if (keycode == 67) {
// 			if (objGrid.cellcopy == true) {
// 				if (objGrid.selectstartrow.length > 1)	{
// 					// 다중선택 범위에서는 사용할 수 없는 명령입니다.
// 					this.gfnAlert("MSG_ALT_FUNC_NOTUSED");
// 					return;
// 				}
// 				
// 				// 현재 셀에 선택된 Text가 있는 경우 기본 복사하기 진행
// 				var sSelectText = objGrid.getEditSelectedText();
// 				if (this.gfnIsNotNull(sSelectText))		return;
// 				
// 				//copy
// 				if (sBrowser == "nexacro" || sBrowser == "IE") {
// 					trace ("복사 넥사 이에");
// 					this._gfnGridCopyEventForRuntime(objGrid, e);
// 				} else {
// 					trace ("그 외");
// 					this._gfnGridCopyEventForChrome(objGrid, e);
// 				}
// 				
// 				
// 				trace("v_clip " + v_clip);
// 			}
// 		} else if(keycode == 86) {
// 			// 기존에 있던 if 문 주석처리
// 			//if (objGrid.cellpaste == true) {
// 			
// 				// 붙여넣기 할 그리드의 데이터셋에 데이터가 없을때
// 				// 일단 한개의 row 를 추가
// 				var ds = objGrid.getBindDataset();
// 				if (objGrid.rowcount < 1) {
// 					ds.addRow();
// 				}
// 				trace ("붙이기");
// 			
// 				//paste
// 				this._gfnGridPasteEvent(objGrid, e);
// 
// 			//}
// 		}
// 	}
// };

 /*
	[v_0.3] 수정중
	크롬에서도 가능하게 수정중
 */
pForm.gfnGrid_onkeydown =function(objGrid, e){
	var keycode = e.keycode;
	var sBrowser = system.navigatorname;
	var v_clip = "";
	if (e.ctrlkey) {
		if (keycode == 67) {
		
			//============================================================================================
			trace ("nexacro.toNumber(objGrid.selectstartrow) = " + nexacro.toNumber(objGrid.selectstartrow));
			
			for (var i= nexacro.toNumber(objGrid.selectstartrow);i<= nexacro.toNumber(objGrid.selectendrow);i++) {
				trace ("크롬일때만 들어오나");
				for (var j=nexacro.toNumber(objGrid.selectstartcol);j<=nexacro.toNumber(objGrid.selectendcol);j++) {

					if (j < objGrid.selectendcol) {
						// strSeperate 이게 문제네
						v_clip += objGrid.getCellValue(i,j) + strSeperate;
					} else {
						v_clip += objGrid.getCellValue(i,j);
					}
				}
				if (i < objGrid.selectendrow) {
					v_clip += "\r\n";
				}
			}
			v_clip += "\r\n";
			system.clearClipboard();
			system.setClipboard("CF_TEXT",v_clip);
			//============================================================================================
		
			if (objGrid.cellcopy == true) {
				if (objGrid.selectstartrow.length > 1)	{
					// 다중선택 범위에서는 사용할 수 없는 명령입니다.
					this.gfnAlert("MSG_ALT_FUNC_NOTUSED");
					return;
				}
				
				// 현재 셀에 선택된 Text가 있는 경우 기본 복사하기 진행
				var sSelectText = objGrid.getEditSelectedText();
				
				trace ("sSelectText = " + objGrid.getEditSelectedText());
				
				
				if (this.gfnIsNotNull(sSelectText))		return;
				
				//copy
				if (sBrowser == "nexacro" || sBrowser == "IE") {
					trace ("복사 넥사 이에");
					this._gfnGridCopyEventForRuntime(objGrid, e);
				} else {
					trace ("그 외");
					//this._gfnGridCopyEventForChrome(objGrid, e);
					copyThis(v_clip);//크롬에서 복사 처리를 위해 index.html에 정의한 함수 호출.
				}
				
				
				trace("v_clip " + v_clip);
			}
		} else if(keycode == 86) {
		
			// 붙여넣기 할 그리드의 데이터셋에 데이터가 없을때
			// 일단 한개의 row 를 추가
			var ds = objGrid.getBindDataset();
			if (objGrid.rowcount < 1) {
				ds.addRow();
			}
			if (sBrowser == "nexacro" || sBrowser == "IE") {
				trace ("그냥 붙이기");
				// 런타임, 익스플로러용 붙이기 함수
				this._gfnGridPasteEvent(objGrid, e);
			} else {
				trace ("크롬붙이기");
				// 크롬용 붙이기 함수
				this.gfnPasteChrome();
			}
		}
	}
};

pForm.gfnPasteChrome = function() {
	//Chrome브라우저 일 경우 popupdiv를 띄워준다.
	if(system.navigatorname == "Chrome"){
		this.PopupDiv00.trackPopup(400,200);
	}else{
				
		var bAddrow = true;
		if (!this.utlf_IsNull(this.gfn_grdCopy_Paste.arguments[2])) {
			bAddrow = this.gfn_grdCopy_Paste.arguments[2];
		}
		//Grid Binddataset
		var strGrdDsNm = obj.binddataset;
		//cell count
		var nGrdCellCnt = obj.getCellCount("body");
		//cell position
		var nGrdCellPos = obj.getCellPos();		
		
		//trace("nGrdCellPos  " + nGrdCellPos);	
		//row position
		var nRowPos = eval("this." + strGrdDsNm).rowposition;
	
		trace("nRowPos  " + nRowPos);
		
		//arrText2 index
		var k = 0;
		//Dataset rowcount
		var nDsRowCnt = eval("this." + strGrdDsNm).getRowCount();		

		trace("nDsRowCnt  " + nDsRowCnt);
			
		//var t_clip = system.getClipboard("CF_UNICODETEXT");
		var t_clip = system.getClipboard("CF_TEXT");
		
		var strText = new String(t_clip);
		var arrText = new Array();
		var arrText2 = new Array();
		arrText = strText.split("\r\n");
		
		trace("t_clip " + t_clip);
		trace("strText " + strText);
		trace("arrText " + arrText);
		trace("arrText2 " + arrText2);
		
		
		if (nDsRowCnt < (arrText.length + nRowPos -1)) {
			if (bAddrow) {
				
			} else {
				return false;
			}			
		}			
		//복사한 Row만큼
		var oDs =  eval("this." + strGrdDsNm);
		for (var i=0;i<arrText.length;i++) {
			
			if (this.utlf_IsNull(arrText[i])) {
				return;
			}
			arrText2 = arrText[i].split("	");

			trace("arrText2:" + arrText2);
			
			//기존 dataset갯수보다 많은 경우
			if ( nDsRowCnt <= nRowPos) {
				var nAddrow = oDs.addRow();
			}
			
			var nLoopCnt = (nGrdCellPos + arrText2.length);
			if (nLoopCnt > nGrdCellCnt) {
				nLoopCnt = nGrdCellCnt;
			}
			
			//Dataset setcolumn				
			trace("nGrdCellPos  " + nGrdCellPos);				
			trace("nLoopCnt  " + nLoopCnt);
			
			k = 0;
			for (var j=nGrdCellPos;j<nLoopCnt;j++) {
				var colid = obj.getCellProperty("body", j, "text").substr(5);
			
				oDs.setColumn(nRowPos, colid, arrText2[k]);
				
				k++;
			}				
			nRowPos++;
			eval("this." + strGrdDsNm).rowposition = nRowPos;
		}
		return true;
	}
}

//Chrome 브라우저용 메소드
pForm.fn_paste = function(obj,str)
{
	trace ("크롬붙이기");
	var bAddrow = true;

	//Grid Binddataset
	var strGrdDsNm = obj.binddataset;
	//cell count
	var nGrdCellCnt = obj.getCellCount("body");
	//cell position
	var nGrdCellPos = obj.getCellPos();		
	
	//trace("nGrdCellPos  " + nGrdCellPos);	
	//row position
	var nRowPos = eval("this." + strGrdDsNm).rowposition;

	trace("nRowPos  " + nRowPos);
	
	//arrText2 index
	var k = 0;
	//Dataset rowcount
	var nDsRowCnt = eval("this." + strGrdDsNm).getRowCount();		

	trace("nDsRowCnt  " + nDsRowCnt);
		
	//var t_clip = system.getClipboard("CF_UNICODETEXT");
	//var t_clip = system.getClipboard("CF_TEXT");
	//클립보드 사용이 불가 하기 때문에 textarea에서 넘겨받은 값을 이용.
	var t_clip = str;
	
	var strText = new String(t_clip);
	var arrText = new Array();
	var arrText2 = new Array();
	arrText = strText.split("\n");//넥사크로에서는 줄바꿈을 \n 으로 사용.
	
	trace("t_clip " + t_clip);
	trace("strText " + strText);
	trace("arrText " + arrText);
	trace("arrText2 " + arrText2);
	
	
	if (nDsRowCnt < (arrText.length + nRowPos -1)) {
		if (bAddrow) {
			
		} else {
			return false;
		}			
	}			
	//복사한 Row만큼
	var oDs =  eval("this." + strGrdDsNm);
	for (var i=0;i<arrText.length;i++) {
		
		if (this.gfnIsNull(arrText[i])) {
			return;
		}
		arrText2 = arrText[i].split("	");

		trace("arrText2:" + arrText2);
		
		//기존 dataset갯수보다 많은 경우
		if ( nDsRowCnt <= nRowPos) {
			var nAddrow = oDs.addRow();
		}
		
		var nLoopCnt = (nGrdCellPos + arrText2.length);
		if (nLoopCnt > nGrdCellCnt) {
			nLoopCnt = nGrdCellCnt;
		}
		
		//Dataset setcolumn				
		trace("nGrdCellPos  " + nGrdCellPos);				
		trace("nLoopCnt  " + nLoopCnt);
		
		k = 0;
		for (var j=nGrdCellPos;j<nLoopCnt;j++) {
			var colid = obj.getCellProperty("body", j, "text").substr(5);
		
			oDs.setColumn(nRowPos, colid, arrText2[k]);
			
			k++;
		}				
		nRowPos++;
		eval("this." + strGrdDsNm).rowposition = nRowPos;
	}
	return true;
}

/**
 * @class copy event(nexacro, ie)
 * @param {Object} obj- 대상그리드
 * @param {Event}  e - key down event
 * @return N/A
 * @example
 * this._gfnGridCopyEventForRuntime(obj, e);	
*/
pForm._gfnGridCopyEventForRuntime = function (obj, e)
{
	var startrow = nexacro.toNumber(obj.selectstartrow);
	if (startrow == -9) {
		return;
	}

	var endrow = nexacro.toNumber(obj.selectendrow);
	if (endrow == -9) {
		return;
	}
	
	var startcol = 0;
	var endcol = 0;
	
	if (obj.selecttype == "row" || obj.selecttype == "multirow") {
		startcol = 0;
		endcol = obj.getCellCount("body") - 1;
	} else {
		startcol = nexacro.toNumber(obj.selectstartcol);
		endcol = nexacro.toNumber(obj.selectendcol);
	}
	var colSeperator = "\t";
	var copyData = "";
	var checkIndex = {};
	
	for (var i = startrow; i <= endrow; i++) {
		for (var j = startcol; j <= endcol; j++) {
			//var value = obj.getCellValue(i, j);
			var value = this.gfnNvl(obj.getCellText(i, j),"");
			//if (this.gfnIsNotNull(value)) {
				if (j < endcol) {
					//copyData += obj.getCellValue(i, j) + colSeperator;
					copyData += value + colSeperator;
				} else {
					//copyData += obj.getCellValue(i, j);
					copyData += value;
				}
			//}
		}
		if (i < obj.selectendrow) {
			copyData += "\r\n";
		}
	}

	copyData += "\r\n";
	system.clearClipboard();
	system.setClipboard("CF_TEXT", copyData);
	
	// var areaInfo = {"startrow": startrow, "startcol": startcol, "endrow": endrow, "endcol": endcol};
};

/**
 * @class paste데이터생성
 * @param {String} browser - 브라우저
 * @return paste데이터 
 * @example
 * this._gfnGirdGetPasteData("nexacro");	
*/
pForm._gfnGirdGetPasteData = function (browser)
{
	var copyData = "";
	if (browser == "nexacro" || browser == "IE") {
		copyData = system.getClipboard("CF_TEXT");
		copyData = new String(copyData);
	} else {
		var ta = this.tragetGrid["ta"];

		if (!ta) {
			return;
		}

		copyData = ta.value;
		document.body.removeChild(ta);
		
		this.tragetGrid["ta"] = undefined;
	}
	return copyData;
	
};

/**
 * @class paste event
 * @param {Object} obj- 대상그리드
 * @param {Event}  e - key down event
 * @return N/A
 * @example
 * this._gfnGridPasteEvent(obj, e);	
*/

/*
	[v_0.1] 최초로 있던 파일. 이거 안먹혔음
*/

// pForm._gfnGridPasteEvent = function (obj, e)
// {
// 	var browser = system.navigatorname;
// 	var copyData = this._gfnGirdGetPasteData(browser);
// 	
// 	if (this.gfnIsNull(copyData)) {
// 		return;
// 	}
// 	
// 	var colSeperator = "\t";
// 	var rowData = "";
// 	if (browser == "nexacro" || browser =="IE") {
// 		rowData = copyData.split("\r\n");
// 		if (rowDataCount < 1) {
// 			e.stopPropagation();
// 			return;
// 		}
// 	} else {
// 		rowData = copyData.split(/[\n\f\r]/); 
// 	}
// 	var rowDataCount = rowData.length - 1;
// 
// 	obj.set_enableevent(false);
// 	obj.set_enableredraw(false); 
// 
// 	var datasetName = obj.binddataset;
// 	var ds = obj.getBindDataset();
// 
// 	ds.set_enableevent(false); 
// 
// 	var grdCellCount = obj.getCellCount("body");
// 	var rowCount = ds.getRowCount();
// 	
// 	var startrow = nexacro.toNumber(obj.selectstartrow);
// 	if (startrow == -9) {
// 		return;
// 	}
// 
// 	var endrow = nexacro.toNumber(obj.selectendrow);
// 	if (endrow == -9) {
// 		return;
// 	}
// 	
// 	var startcol = 0;
// 	var endcol = 0;
// 	
// 	if (obj.selecttype == "row" || obj.selecttype == "multirow") {
// 		startcol = 0;
// 		endcol = obj.getCellCount("body") - 1;
// 	} else {
// 		startcol = nexacro.toNumber(obj.selectstartcol);
// 		endcol = nexacro.toNumber(obj.selectendcol);
// 	}
// 
// 	var currRow = startrow;
// 	var cellIndex = startcol;
// 	var maxColumnCount = 0;
// 	var checkIndex = {};	
// 
// 	for (var i = 0; i < rowDataCount; i++) {
// 		if (rowCount <= currRow) {
// 			ds.addRow();
// 		}
// 
// 		var columnData = rowData[i].split(colSeperator);
// 		var columnLoopCount = cellIndex + columnData.length;
// 
// 		if (columnLoopCount > grdCellCount) {
// 			columnLoopCount = grdCellCount;
// 		}
// 
// 		if (maxColumnCount < columnLoopCount) {
// 			maxColumnCount = columnLoopCount;
// 		}
// 
// 		var k = 0;
// 		var edittype = "none";
// 		for (var j = cellIndex; j < columnLoopCount; j++) {
// 			var colTemp = obj.getCellProperty("body", j, "text");
// 			var colid;
// 			
// 			edittype = this.gfnNvl(obj.getCellProperty("body", j, "edittype"),"none");
// 			
// 			if (edittype == "none" || edittype == "button" || edittype == "readonly" || edittype == "tree") {
// 				k++;
// 				continue;
// 			}
// 			
// 			if (this.gfnIsNull(colTemp)) {
// 				colid = obj.getCellProperty("body", j, "text");
// 			} else {
// 				colid = obj.getCellProperty("body", j, "text").substr(5);
// 			}
// 			
// 			var tempValue = columnData[k];
// 			if (this.gfnIsNotNull(tempValue)) {
// 				ds.setColumn(currRow, colid, tempValue);
// 			}
// 			k++;
// 		}
// 		currRow++;
// 	}
// 
// 	ds.rowposition = currRow;	
// 
// 	endrow = endrow + rowDataCount - 1;
// 	endcol = maxColumnCount - 1;
// 	
// 	system.clearClipboard();
// 
// 	obj.set_enableredraw(true);
// 	obj.set_enableevent(true);
// 	ds.set_enableevent(true); 
// 
// 	obj.selectArea(startrow, startcol, endrow, endcol);
// 
// 	// var areaInfo = {"startrow": startrow, "startcol": startcol, "endrow": endrow, "endcol": endcol};
// 	e.stopPropagation();
// };

/*
	[v_0.2] 최초로 있던 파일을 이걸로 수정
	런타임, 익스플로러에서 가능하지만 크롬에서는 불가능
*/
// pForm._gfnGridPasteEvent = function(obj, e)
// {
// 	
// 	var browser = system.navigatorname;
// 	var copyData = this._gfnGirdGetPasteData(browser);
// 
// 	if (this.gfnIsNull(copyData)) return;
// 
// 	var colSeperator = "\t";
// 	var rowData ="";
// 	if (browser == "nexacro" || browser =="IE")
// 	{
// 		rowData = copyData.split("\r\n");
// 		if (rowDataCount < 1)
// 		{
// 			e.stopPropagation();
// 			return;
// 		}
// 	}
// 	else
// 	{
// 		rowData = copyData.split(/[\n\f\r]/);
// 	}
// 	
// 	var rowDataCount = rowData.length - 1;
// 
// 	obj.set_enableevent(false);
// 	obj.set_enableredraw(false);
// 
// 	var datasetName = obj.binddataset;
// 	var ds = obj.getBindDataset();
// 
// 	ds.set_enableevent(false);
// 
// 	var grdCellCount = obj.getCellCount("body");
// 	var rowCount = ds.getRowCount();
// 
// 	var startrow = nexacro.toNumber(obj.selectstartrow);
// 	if (startrow == -9) return;
// 
// 	var endrow   = nexacro.toNumber(obj.selectendrow);
// 	if (endrow == -9) return;
// 
// 	var startcol = 0;
// 	var endcol = 0;
// 
// 	if (obj.selecttype == "row" || obj.selecttype == "multirow")
// 	{
// 		startcol = 0;
// 		endcol = obj.getCellCount("body")-1;
// 	}
// 	else
// 	{
// 		startcol = nexacro.toNumber(obj.selectstartcol);
// 		endcol   = nexacro.toNumber(obj.selectendcol);
// 	}
// 
// 	var currRow = startrow;
// 	var cellIndex = startcol;
// 	var maxColumnCount = 0;
// 	var checkIndex = {};
// 	
// 	for (var i = 0; i < rowDataCount; i++)
// 	{
// 		//if (rowCount <= currRow) 
// 		if (rowCount <= currRow) 
// 		{
// 			ds.addRow();
// 		}
// 
// 		var columnData = rowData[i].split(colSeperator);
// 		var columnLoopCount = cellIndex + columnData.length;
// 
// 		if (columnLoopCount > grdCellCount)
// 		{
// 			columnLoopCount = grdCellCount;
// 		}
// 
// 		if (maxColumnCount < columnLoopCount)
// 		{
// 			maxColumnCount = columnLoopCount;
// 		}
// 
// 		var k = 0;
// 		for (var j = cellIndex; j<columnLoopCount; j++)
// 		{
// 			var colTemp = obj.getCellProperty("body", j, "text");
// 			var colid;
// 			if (this.gfnIsNull(colTemp))
// 			{
// 				colid = obj.getCellProperty("body", j, "text");
// 			}
// 			else
// 			{
// 				colid = obj.getCellProperty("body", j, "text").substr(5);
// 			}
// 
// 			var tempValue = columnData[k];
// 			if (!this.gfnIsNull(tempValue))
// 			{
// 				ds.setColumn(currRow, colid, tempValue);
// 			}
// 			k++;
// 		}
// 		currRow++;
// 	}
// 
// 	ds.rowposition = currRow;
// 
// 	endrow = endrow + rowDataCount - 1;
// 	endcol = maxColumnCount - 1;
// 
// 	system.clearClipboard();
// 
// 	obj.set_enableredraw(true);
// 	obj.set_enableevent(true);
// 	ds.set_enableevent(true);
// 
// 	obj.selectArea(startrow, startcol, endrow, endcol);
// 
// 	var areaInfo = {"startrow": startrow, "startcol": startcol, "endrow": endrow, "endcol": endcol};
// 	e.stopPropagation();
// };

/*
	[v_0.3] 다시 수정중 : 이 함수는 런타임이랑 익스플로러만 먹히는 함수
	크롬용은 gfnPasteChrome();
*/
pForm._gfnGridPasteEvent = function(obj, e)
{
	
	var browser = system.navigatorname;
	var copyData = this._gfnGirdGetPasteData(browser);

	if (this.gfnIsNull(copyData)) return;

	var colSeperator = "\t";
	var rowData ="";
	if (browser == "nexacro" || browser =="IE")
	{
		rowData = copyData.split("\r\n");
		if (rowDataCount < 1)
		{
			e.stopPropagation();
			return;
		}
	}
	else
	{
		rowData = copyData.split(/[\n\f\r]/);
	}
	
	var rowDataCount = rowData.length - 1;

	obj.set_enableevent(false);
	obj.set_enableredraw(false);

	var datasetName = obj.binddataset;
	var ds = obj.getBindDataset();

	ds.set_enableevent(false);

	var grdCellCount = obj.getCellCount("body");
	var rowCount = ds.getRowCount();

	var startrow = nexacro.toNumber(obj.selectstartrow);
	if (startrow == -9) return;

	var endrow   = nexacro.toNumber(obj.selectendrow);
	if (endrow == -9) return;

	var startcol = 0;
	var endcol = 0;

	if (obj.selecttype == "row" || obj.selecttype == "multirow")
	{
		startcol = 0;
		endcol = obj.getCellCount("body")-1;
	}
	else
	{
		startcol = nexacro.toNumber(obj.selectstartcol);
		endcol   = nexacro.toNumber(obj.selectendcol);
	}

	var currRow = startrow;
	var cellIndex = startcol;
	var maxColumnCount = 0;
	var checkIndex = {};
	
	for (var i = 0; i < rowDataCount; i++)
	{
		//if (rowCount <= currRow) 
		if (rowCount <= currRow) 
		{
			ds.addRow();
		}

		var columnData = rowData[i].split(colSeperator);
		var columnLoopCount = cellIndex + columnData.length;

		if (columnLoopCount > grdCellCount)
		{
			columnLoopCount = grdCellCount;
		}

		if (maxColumnCount < columnLoopCount)
		{
			maxColumnCount = columnLoopCount;
		}

		var k = 0;
		for (var j = cellIndex; j<columnLoopCount; j++)
		{
			var colTemp = obj.getCellProperty("body", j, "text");
			var colid;
			if (this.gfnIsNull(colTemp))
			{
				colid = obj.getCellProperty("body", j, "text");
			}
			else
			{
				colid = obj.getCellProperty("body", j, "text").substr(5);
			}

			var tempValue = columnData[k];
			if (!this.gfnIsNull(tempValue))
			{
				ds.setColumn(currRow, colid, tempValue);
			}
			k++;
		}
		currRow++;
	}

	ds.rowposition = currRow;

	endrow = endrow + rowDataCount - 1;
	endcol = maxColumnCount - 1;

	system.clearClipboard();

	obj.set_enableredraw(true);
	obj.set_enableevent(true);
	ds.set_enableevent(true);

	obj.selectArea(startrow, startcol, endrow, endcol);

	var areaInfo = {"startrow": startrow, "startcol": startcol, "endrow": endrow, "endcol": endcol};
	e.stopPropagation();
};

/**
 * @class copy event(chrome)
 * @param {Object} obj- 대상그리드
 * @param {Event}  e - key down event
 * @return N/A
 * @example
 * this._gfnGridCopyEventForChrome(obj, e);	
*/
pForm._gfnGridCopyEventForChrome = function (obj, e)
{
	var startrow = nexacro.toNumber(obj.selectstartrow);
	if (startrow == -9) {
		return;
	}

	var endrow = nexacro.toNumber(obj.selectendrow);
	if (endrow == -9) {
		return;
	}
	
	var startcol = 0;
	var endcol = 0;
	
	if (obj.selecttype == "row" || obj.selecttype == "multirow") {
		startcol = 0;
		endcol = obj.getCellCount("body") - 1;
	} else {
		startcol = nexacro.toNumber(obj.selectstartcol);
		endcol = nexacro.toNumber(obj.selectendcol);
	}

	var colSeperator = "\t";
	var copyData = "";
	
	for (var i = startrow; i <= endrow; i++) {
		for (var j = startcol; j <= endcol; j++) {
			//var value = obj.getCellValue(i, j);
			var value = this.gfnNvl(obj.getCellText(i, j),"");
			//if (this.gfnIsNotNull(value)) {
				if (j < endcol) {
					//copyData += obj.getCellValue(i, j) + colSeperator;
					copyData += value + colSeperator;
				} else {
					//copyData += obj.getCellValue(i, j);
					copyData += value;
				}
			//}
		}
		if (i < obj.selectendrow) {
				copyData += "\r\n";
		}
	}

	copyData += "\r\n";
	
	var ta = this._createTextarea(copyData);
	this.tragetGrid = obj;
	this.tragetGrid["ta"] = ta;
	// var areaInfo = {"startrow": startrow, "startcol": startcol, "endrow": endrow, "endcol": endcol};
	e.stopPropagation();
};

/**
 * @class cell copy and paste (크롬용 텍스트에어리어생성)
 * @param {String} innerText- value
 * @return{Object} 텍스트에어리어 오브젝트
 * @example
 * this._createTextarea("꼬부기");	
*/
pForm._createTextarea = function(innerText)
{
	var ta = document.createElement('textarea');
	ta.id = "textAreabyCopyAndPaste";
	ta.style.position = 'absolute';
	ta.style.left = '-1000px';
	ta.style.top = document.body.scrollTop + 'px';
	ta.value = innerText;
	
	document.body.appendChild(ta);
	ta.select();

	return ta;
};

/**
 * @class 해당 객체에 이벤트가 없는 경우 이벤트를 추가
 * @param {Object} obj - 이벤트를 추가할 객체
 * @param {String} sEventID - 이벤트ID
 * @param {Object} objFunc - 이벤트 함수
 * @param {Number} nInsert - 이벤트 추가 index
 * @return N/A
*/
pForm._gfnEventAdd = function(obj,sEventID,objFunc,nInsert)
{
	try {
		var nIndex = obj.findEventHandler(sEventID, objFunc, this);
		if (nIndex < 0) {
			if (nInsert != null) {
				obj.insertEventHandler(sEventID, nInsert, objFunc, this);
			} else {
				obj.addEventHandler(sEventID, objFunc, this);
			}
		}
	} catch(e){}
};

/**
 * @class 해당 객체에 이벤트가 있는 경우 이벤트를 제거
 * @param {Object} obj - 이벤트를 제거할 객체
 * @param {String} sEventID - 이벤트ID
 * @param {Object} objFunc - 이벤트 함수
 * @return N/A
*/
pForm._gfnEventRemove = function(obj,sEventID,objFunc)
{
	try {
		var nIndex = obj.findEventHandler(sEventID, objFunc, this);
		if (nIndex >= 0) {
			obj.removeEventHandler(sEventID, objFunc, this);
		}
	} catch(e){}
};

// [주의] Area일때 Drag이벤트 방지용 처리용 onlbuttondown 이벤트 - comGridFooter에서 이벤트 추가/삭제함
pForm._gfn_grdarea_onlbuttondown = function(obj,e)
{
	if (obj.selecttype == "multiarea") {
		var objDs = obj.getBindDataset();
		
		if (this.gfnIsNotNull(objDs)) {
			if (objDs["_dragorgrow"] == null) {
				objDs["_dragorgrow"]	= objDs.rowposition;
				objDs["_dragorgcell"]	= obj.getCellPos();
				
				//20.04.04 sepia onrowposchanged 이벤트 제거 및 임시변수에 저장
				if (this.gfnIsNotNull(objDs.onrowposchanged)) {
					this._rowposchangedEvent[objDs.name] = objDs.onrowposchanged;
					objDs.onrowposchanged = null;
				}
				//objDs.set_enableevent(false);		//콤보박스 이벤트 및 마지막 row 이벤트를 기록못해서 주석처리
			}
		}
	}
};

// [주의] Area일때 Drag이벤트 방지용 처리 onlbuttonup 이벤트 - comGridFooter에서 이벤트 추가/삭제함
pForm._gfn_grdarea_onlbuttonup = function(obj,e)
{
	if (obj.selecttype == "multiarea") {
		var objDs = obj.getBindDataset();
		
		if (this.gfnIsNotNull(objDs)) {
			if (this.gfnIsNotNull(objDs["_dragorgrow"])) {
				objDs.set_rowposition(objDs["_dragorgrow"]);
				
				//20.04.04 sepia onrowposchanged 이벤트 원복
				if (this.gfnIsNull(objDs.onrowposchanged) && this.gfnIsNotNull(this._rowposchangedEvent[objDs.name])) {
					objDs.onrowposchanged = this._rowposchangedEvent[objDs.name]; 
					this._rowposchangedEvent[objDs.name] = null;
				}
				
				//objDs.set_enableevent(true);			//콤보박스 이벤트 및 마지막 row 이벤트를 기록못해서 주석처리
				if(e.row < 0) {
					objDs.set_rowposition(objDs.rowposition);	// 드레그 마지막 row이벤트 발생용 -> Area인 경우 e.row가 -9가 되는 현상 때문에 objDs.rowposiont으로 변경
				} else {
					objDs.set_rowposition(e.row);
				}
				
				// 동일한 셀을 클릭한 경우 에디터 활성화
				if (e.row == objDs["_dragorgrow"] && e.cell == objDs["_dragorgcell"]) {
					obj.showEditor(true);
				}
				
				// 초기화
				objDs["_dragorgrow"] 	= null;
				objDs["_dragorgcell"] 	= null;
			}
		}
	}
};

/**
 * @class 상태 컬럼 추가
 * @param 	{Object} obj - 대상 데이터셋 객체
 * @return N/A
 */
pForm._gfnAddStatusCol = function (obj)
{
	// 상태컬럼 없는 경우 추가
	var nColIdx = obj.getColIndex(this.COM_STATUS_ID);
	if (nColIdx == -1) {
		obj.addColumn(this.COM_STATUS_ID, "STRING", 1);
	}
}

/**
 * @class 데이터셋 행추가
 * @param 	{Object} objDs - 대상 데이터셋 객체
 * @param	{Number} nRow - 추가할 행 Index(없는 경우 제일 아래로 추가)
 * @return	{Number} 추가된 행 Index  
 */
pForm.gfnAddRow = function (objDs, nRow)
{
	var nARow;
	
	if (this.gfnIsNull(nRow)) {		// nRow가 없는 경우 addRow()
		nARow = objDs.addRow();
	} else {						// nRow가 있는 경우 insertRow()
		nARow = objDs.insertRow(nRow);
	}
	
	// 상태컬럼 없는 경우 추가
	this._gfnAddStatusCol(objDs);
	
	objDs.setColumn(nARow, this.COM_STATUS_ID, pForm.COM_STATUS_INSERT);		// 상태값설정
	
	return nARow;
};

/**
 * @class 데이터셋 행삭제
 * @param 	{Object} objDs - 대상 데이터셋 객체
 * @param	{Number} nRow - 삭제할 행 Index(없는 경우 현재Row 삭제처리)
 * @return	{Number} 삭제된 행 Index  
 */
pForm.gfnDeleteRow = function (objDs, nRow)
{
	if (this.gfnIsNull(nRow))		nRow = objDs.rowposition;
	
	// 상태컬럼 없는 경우 추가
	this._gfnAddStatusCol(objDs);
	
	if (objDs.getRowType(nRow) == Dataset.ROWTYPE_INSERT) {
		objDs.deleteRow(nRow);
	} else {
		objDs.setColumn(nRow, this.COM_STATUS_ID, pForm.COM_STATUS_DELETE);			// 상태값설정
	}
	
	// Delete Row 후 0이 되었을 경우 Head 체크박스 초기화
	var objGrid = objDs.bindgrid;
	var nCnt = objDs.rowcount;
	if(nCnt <= 0) this.gfnInitGrid(objGrid);
	
	return nRow;
};

/**
 * @class 데이터셋 행초기화
 * @param 	{Object} objDs - 대상 데이터셋 객체
 * @param	{Number} nRow - 초기화할 행 Index(없는 경우 현재Row 초기화처리)
 * @return	N/A
 */
pForm.gfnResetRow = function (objDs, nRow)
{
	if (this.gfnIsNull(nRow))		nRow = objDs.rowposition;
	
	if (objDs.getRowType(nRow) == Dataset.ROWTYPE_INSERT) {					// 신규인 경우
		
	} else if (objDs.getRowType(nRow) == Dataset.ROWTYPE_UPDATE) {			// 수정인 경우 초기화
		// 컬럼값 초기화
		for (var i = 0, s = objDs.getColCount(); i < s; i++) {
			objDs.setColumn(nRow, i, objDs.getOrgColumn(nRow, i));
		}
	}
	
	return nRow;
};

/**
 * @class 	체크된 데이터 행삭제
 * @param 	{Object} objDs - 대상 데이터셋 객체
 * @return	N/A
 */
pForm.gfnDeleteRowAll = function (objDs)
{
	// 선택된 자료가 없습니다.
	if (objDs.getCaseCount(this.COM_CHECK_ID + "==1") == 0) {
		this.gfnAlert("MSG_ALT_DATA_NOSELECT");
		return;
	}
	
	objDs.set_enableevent(false);
	
	for(var i=objDs.rowcount-1; i>=0; i--) {
		if (objDs.getColumn(i,this.COM_CHECK_ID) == 1) {
			this.gfnDeleteRow(objDs,i);
		}
	}
	
	objDs.set_enableevent(true);
	
	// Delete Row 후 0이 되었을 경우 Head 체크박스 초기화
	var objGrid = objDs.bindgrid;
	var nCnt = objDs.rowcount;
	if(nCnt <= 0) this.gfnInitGrid(objGrid);
};

/**
 * @class 	체크된 데이터 리셋
 * @param 	{Object} objDs - 대상 데이터셋 객체
 * @return	N/A
 */
pForm.gfnResetRowAll = function (objDs)
{
	// 선택된 자료가 없습니다.
	if (objDs.getCaseCount(this.COM_CHECK_ID + "==1") == 0) {
		this.gfnAlert("MSG_ALT_DATA_NOSELECT");
		return;
	}
	
	objDs.set_enableevent(false);
	
	for(var i=objDs.rowcount-1; i>=0; i--) {
		if (objDs.getColumn(i,this.COM_CHECK_ID) == 1) {
			this.gfnResetRow(objDs,i);
		}
	}
	
	objDs.set_enableevent(true);
};

/**
 * @class 그리드 셀에 포커스
 * @param 	{Object} obj - 대상 그리드
 * @param	{String} or {Number} sColId - 포커스 처리할 컬럼ID나 컬럼index
 * @return	N/A
 */
pForm.gfnGridSetFocus = function(obj,sColId)
{
	var nCell;
	if (this.gfnIsString(sColId)) {
		nCell = obj.getBindCellIndex("Body", sColId);
	} else {
		nCell = sColId;
	}
	
	obj.setCellPos(nCell);
	obj.showEditor(true);
	obj.setFocus();
};

/**
 * @class 데이터셋에 STATUS설정
 * @param 	{Object} obj - 대상 데이터셋 or 데이터셋 배열
 * @return	N/A
 */
pForm.gfnSetDsStatus = function(obj)
{
	var objDs;
	if (obj instanceof nexacro.Dataset ) {
		this._gfnAddStatusCol(obj);		// 상태컬럼 없는 경우 추가
		this._gfnEventAdd(obj,"oncolumnchanged",this._gfn_status_oncolumnchanged,0);
	} else {
		
		for(var i=0; i<obj.length;i++) {
			objDs = obj[i];
			
			this._gfnAddStatusCol(objDs);		// 상태컬럼 없는 경우 추가
			this._gfnEventAdd(objDs,"oncolumnchanged",this._gfn_status_oncolumnchanged,0);
		}
	}
};

// 그리드 상태표시용 값 셋팅
pForm._gfn_status_oncolumnchanged = function(obj,e)
{
	var nErr = 0;
	if (e.columnid != this.COM_CHECK_ID && e.columnid != this.COM_STATUS_ID) {
		var nRow = e.row;
		
		// 상태컬럼 없는 경우 추가
		this._gfnAddStatusCol(obj);
		
		if (obj.getRowType(nRow) == Dataset.ROWTYPE_INSERT) {
			obj.setColumn(nRow, this.COM_STATUS_ID, pForm.COM_STATUS_INSERT);
		} else {
			if (obj.getColumn(nRow, this.COM_STATUS_ID) != pForm.COM_STATUS_DELETE) {
				if(this.gfnIsNull(obj.getColumn(nRow, this.COM_STATUS_ID))) {
					obj.setColumn(nRow, this.COM_STATUS_ID, pForm.COM_STATUS_UPDATE);
				} else {
					if (this.gfnIsNullEmpty(e.newvalue) == this.gfnIsNullEmpty(obj.getOrgColumn(nRow, e.columnid))) {
						//obj.setColumn(nRow, this.COM_STATUS_ID, null);
						
						for(var i = 0; i < obj.rowcount; i++) {
							for(var j = 0; j < obj.colcount; j++) {
								var sColId = obj.getColID(j)
								if(obj.getColumn(i, j) != obj.getOrgColumn(i, j) && sColId != this.COM_STATUS_ID && sColId != this.COM_CHECK_ID) {
									nErr++;
								}
							}
						}
						
						if(nErr <= 0) {
							obj.setColumn(nRow, this.COM_STATUS_ID, null);
						}
					}
				}
			}
		}
	}
	
	//공통 체크박스 클릭시 rowtype이 변경되었으면, status 상태값을 확인하여 rowtype값을 변경 // 원복
	/*if (e.columnid == this.COM_CHECK_ID && obj.getRowType(e.row) == Dataset.ROWTYPE_UPDATE) {		
		if(this.gfnIsNull(obj.getColumn(e.row, this.COM_STATUS_ID)) && this.gfnIsNotNull(obj.colinfos[this.COM_STATUS_ID])) {
			obj.set_enableevent(false);
			obj.set_updatecontrol(false);
			obj.setRowType(e.row, Dataset.ROWTYPE_NORMAL);
			obj.set_updatecontrol(true);
			obj.set_enableevent(true);
		} 
	}*/
	
	// 그리드 Data Checkbox를 선택을 했을 경우 - 전체선택을 하면 Head Checkbox도 체크 / 전체선택에서 하나라도 풀리면 Head Checkbox도 체크해제
	if (e.columnid == this.COM_CHECK_ID) {
		var nRow       = e.row;
		var objGrid    = obj.bindgrid;
		var nTotCnt    = obj.rowcount;
		var nAllChkCnt = obj.getCaseCount("CHK=='1'");
		var nNonChkCnt = obj.getCaseCount("CHK=='0'");
		//var nHeadCell  = objGrid.currentcol;
		// 2020.04.08 - GardenPark
		var nHeadCell = objGrid.getBindCellIndex("body", this.COM_CHECK_ID); // setCellPos 함수 때문에 Head가 0으로 변하는 현상때문에 CHK HeadCell 가져오는 방식 변경
		
		if(nTotCnt == nAllChkCnt) {
			objGrid.setCellProperty("head", nHeadCell, "text", "1");
		} else if(nTotCnt > nAllChkCnt && nNonChkCnt > 0) {
			objGrid.setCellProperty("head", nHeadCell, "text", "0");
		}
	}
};

/************************************************************************************************
*  Grid vscroll 를 통한 Scroll 처리
************************************************************************************************/
/**
 * @class    Grid의 스크롤이 End 로 이동시 조회 처리(onvscroll 이벤트)
 */
pForm.gfnGridAppend = function(obj, e)
{
    if (e.pos == obj.vscrollbar.max)
    {		
        // 스크롤 이벤트의 중복을 막기 위해서 이벤트 제거
		this._gfnEventRemove(obj,"onvscroll", this.gfnGridAppend);
		
		// 페이징
		var objPagingForm = obj.pagingform;
		
		if (this.gfnIsNotNull(objPagingForm)) {
			var objPageInfo = objPagingForm.fnGetPagingInfo();
			var nPage = nexacro.toNumber(objPageInfo.page,0) + 1;
			var nTotCount = nexacro.toNumber(objPageInfo.totalCount,0);
			
			objPagingForm.fnSetPage(nPage);
		}
    }
};

/**
 * @class  그리드 선택변경시 Summary 표시 이벤트
 * @param {Object} objGrid - 대상그리드
 * @param {Evnet}  e	   - Grid 의 선택 영역이 변경 된 후 발생하는 이벤트
 * @return  N/A
 */
pForm._gfn_summary_onselectchanged = function(obj,e)
{
	if (this.gfnIsNull(obj.pagingform))		return;
	
	var arrColS = e.selectstartcol;
	var arrRowS = e.selectstartrow;
	var arrColE = e.selectendcol;
	var arrRowE = e.selectendrow;
	
	obj.pagingform.fnSetSummary(arrColS,arrRowS,arrColE,arrRowE);
};

/**
 * @class 그리드 공통팝업 호출 칼럼 셋팅
 * @param {String} sValue         - 수정된 그리드 칼럼 ID
 * @param {String} sPopupId       - 팝업ID - 공통팝업 호출시 ID는 com으로 시작, 사용자 정의 팝업 호출시 모듈명으로 시작 ex) amsXXX, omsCCC
 * @param {String} sGrpId         - 그룹ID(공통코드(comComnCdPop) 팝업인 경우) / 다국어 종류(다국어(comMlangCdPop) 팝업인 경우)
 * @param {String} sServiceId     - callback에서 사용할 ID(미사용시 팝업ID가 기본값)
 * @param {String} sSearchCond    - Code 외에 검색할 조건(test1=11,test2=22)
 * @param {String} sCdNmType      - 팝업에서 코드 / 코드명으로 검색할 것인지 옵션(CD / NM)
 * @param {String} sSearchQueryId - Customer Select Query ID - NameSpace를 포함한 Query Full ID     -> 사용자 정의 팝업 사용시 필수
 * @param {Object} oOptions       - Popup Option - {sUrl : "", title: "", width : 500, height : 600} -> 사용자 정의 팝업 사용시 필수
 * @param {String} sPlamChcYn	  - 멀티팝업 사용여부
 * @param {String} sReTitl	  	  - 공통팝업 커스텀 팝업 타이틀
 * @param {String} sReSrchCond	  - 공통팝업 커스텀 팝업 조회조건명
 * @param {String} sReGridNm	  - 공통팝업 커스텀 팝업 그리드명
 * @return  N/A
 * @example
 * this.gfnSetGridPop("testValue", "comMlangCdPop", "", "test1", "", "CD", "bpo.xxx.xxx.xxx.selectXXX", oOptions);
 */
pForm.sPopupId       = "";
pForm.sValue         = "";
pForm.sColIds        = "";
pForm.sCallback      = "";
pForm.sGrpId         = "";
pForm.sServiceId     = "";
pForm.sSearchCond    = "";
pForm.sCdNmType      = "";
pForm.sSearchQueryId = "";
pForm.gfnSetGridPop = function(sValue, sPopupId, sGrpId, sServiceId, sSearchCond, sCdNmType, sSearchQueryId, oOptions, sPlamChcYn, sReTitl, sReSrchCond, sReGridNm)
{
	this.sValue         = this.gfnIsNullEmpty(sValue);
	this.sPopupId       = sPopupId;
	this.sCallback      = "fnCommPopCallback";
	this.sGrpId         = sGrpId;
	this.sServiceId     = sServiceId;
	this.sSearchCond    = sSearchCond;
	this.sCdNmType      = sCdNmType;
	this.sSearchQueryId = sSearchQueryId;
	this.oOptions       = oOptions;
	this.sPlamChcYn		= "N";
	if(this.gfnIsNotNull(sPlamChcYn)) {
		this.sPlamChcYn = "Y";
	}
	this.sReTitl		= sReTitl;
	this.sReSrchCond	= sReSrchCond;
	this.sReGridNm		= sReGridNm;
	
	//한글 여부 체크
	if(this.gfnIsHangul(this.sValue)) {
		this.sCdNmType = "NM";
	}
	
	if(this.gfnIsNull(this.sValue)) {
		//Grid Cell에 값이 없는 경우
		var oParam = "";
		
		if(this.sPopupId == "comComnCdPop") {
			//공통코드 팝업인 경우
			if(this.gfnIsNotNull(this.sGrpId)) {
				oParam = { COMN_CD_GRP_CD : this.sGrpId };
			}
		} else if(this.sPopupId == "comMlangCdPop") {
			if(this.gfnIsNotNull(this.sGrpId)) {
				//01: 버튼, 02 : 메뉴, 03 : 메시지
				oParam = { COMN_CD : this.sValue , MSG_TPCD : this.sGrpId };
				
				//팝업을 Name으로 검색할 때
				if(this.gfnIsNotNull(this.sCdNmType)) {
					if(this.sCdNmType == "NM") {
						oParam = { COMN_CD_NM : this.sValue , MSG_TPCD : this.sGrpId };
					}
				}
			} else {
				oParam = { COMN_CD : this.sValue };
				
				//팝업을 Name으로 검색할 때
				if(this.gfnIsNotNull(this.sCdNmType)) {
					if(this.sCdNmType == "NM") {
						oParam = { COMN_CD_NM : this.sValue };
					}
				}
			}
		} else {
			//공통코드 팝업이 아닌 경우
			if(this.gfnIsNull(this.sSearchCond)) {
				oParam = { COMN_CD : this.sValue };
				
				//팝업을 Name으로 검색할 때
				if(this.gfnIsNotNull(this.sCdNmType)) {
					if(this.sCdNmType == "NM") {
						oParam = { COMN_CD_NM : this.sValue };
					}
				}
			} else {
				oParam = { COMN_CD : this.sValue, COMN_ETC : this.sSearchCond };
				
				//팝업을 Name으로 검색할 때
				if(this.gfnIsNotNull(this.sCdNmType)) {
					if(this.sCdNmType == "NM") {
						oParam = { COMN_CD_NM : this.sValue, COMN_ETC : this.sSearchCond };
					}
				}
			}
		}
		
		if(this.sPopupId.indexOf("com") == 0) {
			//공통 팝업 커스텀 (팝업명, 조회조건명, 그리드명)
			if(this.gfnIsNotNull(sReTitl)) {
				oParam.RE_TITLE = sReTitl; 
			}
			if(this.gfnIsNotNull(sReSrchCond)) {
				oParam.RE_SRCH_COND = sReSrchCond; 
			}
			if(this.gfnIsNotNull(sReGridNm)) {
				oParam.RE_GRID_NM = sReGridNm; 
			}
			
			this.gfnPopupCall(this.sPopupId, oParam, "_fnCommPopCallback", "", "", "", "", this.sPlamChcYn);
		} else {
			this.gfnPopup(this.sPopupId, this.oOptions.sUrl, oParam, "_fnCommPopCallback", this.oOptions);
		}
	} else {
		var nameSpace = "";
		var sQuery    = "";
		var sColId    = "";
		var objDs     = this.gfnGetApplication().gdsCommCode;
		var objTempDs = this.gfnGetApplication().gdsTemp;
		var sSvcUrl   = "";
		var sInData	  = "";
		var sOutDs	  = "";
		var sSvcYn    = "N";
		var sQueryCond= "";
		
		if(this.gfnIsNotNull(this.sPopupId))
		{
			if(this.sPopupId.indexOf("com") == 0) {
				//공통 팝업인 경우
				if(this.sPopupId == "comMlangCdPop" || this.sPopupId == "comBpoUsrPop" || this.sPopupId == "comDeptPop") {
					nameSpace = "com.bpo.com.svc.service.CommonService.";
				} else {
					nameSpace = "com.bpo.com.svc.service.MdmService.";
				}
				
				sQuery     = objDs.lookup("CHR_TYP_ATTR_1_VAL", this.sPopupId, "CHR_TYP_ATTR_2_VAL");
				nameSpace  = nameSpace + sQuery;
				sQueryCond = objDs.lookup("CHR_TYP_ATTR_1_VAL", this.sPopupId, "CHR_TYP_ATTR_4_VAL");
				
				// 주소 팝업인 경우 - Service 호출 준비
				if(this.sPopupId == "comAddrPop") {
					sSvcUrl = this.gfnGetPreUrl() + "/common/selectAddressList.do";
					sInData = "";
					sOutDs  = "gdsTemp=OUT_ADDR_LIST";
					sSvcYn  = "Y";
				}
			} else {
				//모듈별 팝업인 경우
				if(this.gfnIsNotNull(sSearchQueryId)) {
					nameSpace = sSearchQueryId;
				}
			}
			
			if(this.sCdNmType == "NM") {
				sColId    = "COMN_CD_NM";
			} else {
				sColId    = "COMN_CD";
			}
		}
		
		// 데이터 초기화
		objTempDs.clear();
		objTempDs.addColumn("COMN_CD", "string", 100);
		objTempDs.addColumn("COMN_CD_NM", "string", 255);

		var oParam = {
			searchId : nameSpace
		  //, pool     : this.MODULE.cmm
		  , preurl 	 : this.gfnGetPreUrl()
		};
		
		var strArg = "";
		if(this.sPopupId == "comComnCdPop") {
			if(this.gfnIsNotNull(this.sGrpId)) {
				strArg = sColId + "=" + nexacro.wrapQuote(this.gfnIsNullEmpty(this.sValue)) + " COMN_CD_GRP_CD=" + nexacro.wrapQuote(this.gfnIsNullEmpty(this.sGrpId));
			} else {
				strArg = sColId + "=" + nexacro.wrapQuote(this.gfnIsNullEmpty(this.sValue));
			}
		} else if(this.sPopupId == "comMlangCdPop") {
			if(this.gfnIsNotNull(this.sGrpId)) {
				strArg = sColId + "=" + nexacro.wrapQuote(this.gfnIsNullEmpty(this.sValue)) + " MSG_TPCD=" + nexacro.wrapQuote(this.gfnIsNullEmpty(this.sGrpId));
			} else {
				strArg = sColId + "=" + nexacro.wrapQuote(this.gfnIsNullEmpty(this.sValue));
			}
		} else {
			//strArg = sColId + "=" + nexacro.wrapQuote(this.gfnIsNullEmpty(this.sValue));
			if(this.gfnIsNull(this.sSearchCond)) {
				strArg = sColId + "=" + nexacro.wrapQuote(this.gfnIsNullEmpty(this.sValue));
			} else {
				strArg = sColId + "=" + nexacro.wrapQuote(this.gfnIsNullEmpty(this.sValue));
				if(this.gfnIsNotNull(this.sSearchCond)) {
					var str      = this.sSearchCond;
					var nRow     = str.indexOf(",");
					var arrStr   = "";
					var arrParam = "";
					
					if(nRow >= 0) {
						arrStr = str.split(",");
						for(var i = 0; i < arrStr.length; i++) {
							arrParam = arrStr[i].split("=");
							strArg += " " + arrParam[0] + "=" + nexacro.wrapQuote(this.gfnIsNullEmpty(arrParam[1]));
						}
					} else {
						arrParam = str.split("=");
						strArg += " " + arrParam[0] + "=" + nexacro.wrapQuote(this.gfnIsNullEmpty(arrParam[1]));
					}
				}
				
				if(this.gfnIsNotNull(sQueryCond)) {
					var str      = sQueryCond;
					var nRow     = str.indexOf(",");
					var arrStr   = "";
					var arrParam = "";
					
					if(nRow >= 0) {
						arrStr = str.split(",");
						for(var i = 0; i < arrStr.length; i++) {
							arrParam = arrStr[i].split("=");
							strArg += " " + arrParam[0] + "=" + nexacro.wrapQuote(this.gfnIsNullEmpty(arrParam[1]));
						}
					} else {
						arrParam = str.split("=");
						strArg += " " + arrParam[0] + "=" + nexacro.wrapQuote(this.gfnIsNullEmpty(arrParam[1]));
					}
				}
			}
		}
		
		if(sSvcYn == "Y") {
			// 주소 팝업인 경우 - Service 호출 -> 데이터가 없으면 MessageException을 날리기 때문에 Arg를 빈값으로 보내기
			strArg += " GRID_POP_SEARCH=" + nexacro.wrapQuote(this.gfnIsNullEmpty("Y"));
			this.gfnTransaction("cntSearch", sSvcUrl, sInData, sOutDs, strArg, "_fnCommPopTranCallback", true);
		} else {
			this.gfnTranCommSearch("cntSearch", oParam, objTempDs, strArg, "_fnCommPopTranCallback", true);
		}
	}
};

// 공통 팝업 기본 콜백
pForm._fnCommPopCallback = function(strId, strVal)
{
	if (this.gfnIsNotNull(strVal)) {
		var mlangCd       = nexacro.getApplication().gdsUserInfo.getColumn(0, "LANG_TPCD");
		var objParentForm = this;
		var sName         = "";
		var objRet        = "";
		var objRetTemp    = JSON.parse(strVal);
		
		if(strId == "comMlangCdPop") {
			if(mlangCd == "en_US") {
				sName = objRetTemp.field3;
			} else {
				sName = objRetTemp.field2;
			}
			
			var objTemp = { COMN_CD : objRetTemp.field1, COMN_CD_NM : sName };
			objRet = objTemp;
			
		} else {
			//var objTemp = { COMN_CD : objRetTemp.COMN_CD, COMN_CD_NM : objRetTemp.COMN_CD_NM };
			//objRet = objTemp;
			//팝업의 모든 값을 바로 내려 주게 변경
			objRet = JSON.parse(strVal);
		}
		
		if(objParentForm.lookupFunc(this.sCallback)) {
			objParentForm.lookupFunc(this.sCallback).call(this.gfnIsNull(this.sServiceId) ? this.sPopupId : this.sServiceId, objRet);
		}
	}
};

// 공통 팝업 Transaction 콜백
pForm._fnCommPopTranCallback = function(svcId, errCd, errMsg)
{
	var mlangCd = nexacro.getApplication().gdsUserInfo.getColumn(0,"LANG_TPCD");
	
	if (svcId == "cntSearch") {
		var objParentForm = this;
		var objTempDs     = this.gfnGetApplication().gdsTemp;
		var nRowCnt       = objTempDs.getRowCount();
		var sCode         = "";
		var sName         = "";
		var objRet        = "";
		
		if(nRowCnt == 1) {
			if(this.sPopupId == "comMlangCdPop") {
				sCode = objTempDs.getColumn(0, "FIELD1");
				
				if(mlangCd == "EN") sName = objTempDs.getColumn(0, "FIELD3");
				else if(mlangCd == "CN") sName = objTempDs.getColumn(0, "FIELD4");
				else sName = objTempDs.getColumn(0, "FIELD2");
				
				objTempDs.addColumn("COMN_CD", "string");
				objTempDs.addColumn("COMN_CD_NM", "string");
				objTempDs.setColumn(0, "COMN_CD", sCode);
				objTempDs.setColumn(0, "COMN_CD_NM", sName);
			} else {
				sCode = objTempDs.getColumn(0, "COMN_CD");
				sName = objTempDs.getColumn(0, "COMN_CD_NM");
			}
			
			//조회된 모든 값을 바로 내려 주게 변경
			objRet += "{";
			var nColCnt = objTempDs.getColCount();
			for(var i = 0; i < nColCnt; i++) {
				var sColId = objTempDs.getColumnInfo(i).id;
				var sColNm = this.gfnIsNull(objTempDs.getColumn(0, sColId)) ? "" : objTempDs.getColumn(0, sColId);
				
				if(i == nColCnt - 1) {
					objRet += "\"" + sColId + "\"" + " : " + "\"" +sColNm + "\"";
				} else {
					objRet += "\"" + sColId + "\"" + " : " + "\"" +sColNm + "\"" + ", ";
				}
			}
			
			objRet += "}";
			objRet = JSON.parse(objRet);
			//objRet = { COMN_CD : sCode, COMN_CD_NM : sName };
			
			if(objParentForm.lookupFunc(this.sCallback)) {
				objParentForm.lookupFunc(this.sCallback).call(this.gfnIsNull(this.sServiceId) ? this.sPopupId : this.sServiceId, objRet);
			}
		} else {
			var oParam = "";
			
			if(this.sPopupId == "comComnCdPop") {
				//공통코드 팝업인 경우
				if(this.gfnIsNotNull(this.sGrpId)) {
					oParam = { COMN_CD : this.sValue, COMN_CD_GRP_CD : this.sGrpId };
					
					//팝업을 Name으로 검색할 때
					if(this.gfnIsNotNull(this.sCdNmType)) {
						if(this.sCdNmType == "NM") {
							oParam = { COMN_CD_NM : this.sValue, COMN_CD_GRP_CD : this.sGrpId };
						}
					}
				}
			} else if(this.sPopupId == "comMlangCdPop") {
				if(this.gfnIsNotNull(this.sGrpId)) {
					//01: 버튼, 02 : 메뉴, 03 : 메시지
					oParam = { COMN_CD : this.sValue , MSG_TPCD : this.sGrpId };
					
					//팝업을 Name으로 검색할 때
					if(this.gfnIsNotNull(this.sCdNmType)) {
						if(this.sCdNmType == "NM") {
							oParam = { COMN_CD_NM : this.sValue , MSG_TPCD : this.sGrpId };
						}
					}
				} else {
					oParam = { COMN_CD : this.sValue };
					
					//팝업을 Name으로 검색할 때
					if(this.gfnIsNotNull(this.sCdNmType)) {
						if(this.sCdNmType == "NM") {
							oParam = { COMN_CD_NM : this.sValue  };
						}
					}
				}
			} else {
				//공통코드 팝업이 아닌 경우
				if(this.gfnIsNull(this.sSearchCond)) {
					oParam = { COMN_CD : this.sValue };
					
					//팝업을 Name으로 검색할 때
					if(this.gfnIsNotNull(this.sCdNmType)) {
						if(this.sCdNmType == "NM") {
							oParam = { COMN_CD_NM : this.sValue  };
						}
					}
				} else {
					oParam = { COMN_CD : this.sValue, COMN_ETC : this.sSearchCond };
					
					//팝업을 Name으로 검색할 때
					if(this.gfnIsNotNull(this.sCdNmType)) {
						if(this.sCdNmType == "NM") {
							oParam = { COMN_CD_NM : this.sValue, COMN_ETC : this.sSearchCond };
						}
					}
				}
			}
			
			if(this.sPopupId.indexOf("com") == 0) {
				if(this.gfnIsNotNull(this.sReTitl)) {
					oParam.RE_TITLE = this.sReTitl; 
				}
				if(this.gfnIsNotNull(this.sReSrchCond)) {
					oParam.RE_SRCH_COND = this.sReSrchCond; 
				}
				if(this.gfnIsNotNull(this.sReGridNm)) {
					oParam.RE_GRID_NM = this.sReGridNm; 
				}
				this.gfnPopupCall(this.sPopupId, oParam, "_fnCommPopCallback", "", "", "", "", this.sPlamChcYn);
			} else {
				this.gfnPopup(this.sPopupId, this.oOptions.sUrl, oParam, "_fnCommPopCallback", this.oOptions);
			}
		}
	}
};

/**
 * @class 그리드 멀티 콤보 셋팅 - Dataset Column Type이 String인 경우에만 작동
 * @param {Object} objForm    - Form Object
 * @param {String} sPopDivId  - Multi Combo ID
 * @param {Object} objDataset - Multi Combo에 사용할 Dataset
 * @param {String} sOptions   - Multi Combo에 적용할 Options - D(Default), A(Full Check/Uncheck All)
 * @return  N/A
 * @example
 * this.gfnSetGridMultiCombo(this, "pdivTest", obj);
 */
pForm.sCdDelimiter  = ",";
pForm.objPopupDiv   = "";
pForm.objPopupDivDs = "";
pForm.gfnSetGridMultiCombo = function(objForm, sPopDivId, objDataset, sOptions)
{
	var sType = "";
	if(this.gfnIsNull(sOptions)) {
		sType = "D";
	} else {
		sType = sOptions
	}
	
	//PopupDiv 생성
	var objPopupDiv = new PopupDiv();
	objPopupDiv.init(sPopDivId, 78, 112, 160, 132, null, null);
	objForm.addChild(sPopDivId, objPopupDiv);
	objPopupDiv.show();
	if(sType == "A") {
		objPopupDiv.addEventHandler("oncloseup", this._pdivMultiCombo_oncloseup, objForm);
	}
	
	//PopupDiv 안의 Grid 생성
	var objPopDivGrid = new Grid();
	objPopDivGrid.init("grd" + sPopDivId, 0, 0, null, null, 0, 31);
	objPopupDiv.addChild("grd" + sPopDivId, objPopDivGrid);
	objPopDivGrid.show();
	objPopDivGrid.set_autofittype("col");
	objPopDivGrid.set_cssclass("grd_WF_customSearchList");
	
	//Button 생성
	if(sType == "D") {
		//기본 버튼 생성
		var objConfirmBtn = new Button();
		objConfirmBtn.init("btnOk" + sPopDivId, 3, null, 74, 25, null, 3);
		objConfirmBtn.set_cssclass("btn_WF_popup_primary");
		objConfirmBtn.set_text(this.gfnGetWord("CHK"));
		objPopupDiv.addChild("btnOk" + sPopDivId, objConfirmBtn);
		objConfirmBtn.show();
		objConfirmBtn.addEventHandler("onclick", this._btnOk_onclick, objForm);
		
		var objCancelBtn = new Button();
		objCancelBtn.init("btnCancel" + sPopDivId, 81, null, 74, 25, null, 3);
		objCancelBtn.set_cssclass("btn_WF_popup_secondary");
		objCancelBtn.set_text(this.gfnGetWord("CNCL"));
		objPopupDiv.addChild("btnCancel" + sPopDivId, objCancelBtn);
		objCancelBtn.show();
		objCancelBtn.addEventHandler("onclick", this._btnCancel_onclick, objForm);
	} else if(sType == "A") {
		//All Check / Unchekd All 버튼 생성
		var objAllCheckBtn = new Button();
		objAllCheckBtn.init("btnCheck" + sPopDivId, 3, null, 74, 25, null, 3);
		objAllCheckBtn.set_cssclass("btn_WF_popup_primary");
		objAllCheckBtn.set_text(this.gfnGetWord("AL_CHC"));
		objPopupDiv.addChild("btnCheck" + sPopDivId, objAllCheckBtn);
		objAllCheckBtn.show();
		objAllCheckBtn.addEventHandler("onclick", this._btnCheck_onclick, objForm);
		
		var objUncheckAllBtn = new Button();
		objUncheckAllBtn.init("btnUnCheck" + sPopDivId, 81, null, 74, 25, null, 3);
		objUncheckAllBtn.set_cssclass("btn_WF_popup_secondary");
		objUncheckAllBtn.set_text(this.gfnGetWord("AL_RLZ"));
		objPopupDiv.addChild("btnUncheck" + sPopDivId, objUncheckAllBtn);
		objUncheckAllBtn.show();
		objUncheckAllBtn.addEventHandler("onclick", this._btnUncheck_onclick, objForm);
	}
	
	//Grid Dataset 생성
	var objPopDivGridDs = new Dataset("ds" + sPopDivId);
	objForm.addChild("ds" + sPopDivId, objPopDivGridDs);
	objPopDivGridDs.copyData(objDataset);
	
	//Grid Column 생성 및 Dataset Binding
	var sFormats = '<Formats>'
                 + '	<Format id="default">'
                 + '		<Columns>'
                 + '  			<Column size="40"/>'
                 + '  			<Column size="100"/>'
                 + '		</Columns>'
                 + '		<Rows>'
                 + '			<Row size="24"/>'
                 + '		</Rows>'
                 + '		<Band id="body">'
                 + '			<Cell displaytype="checkboxcontrol" edittype="checkbox" text="bind:CHK"/>'
                 + '			<Cell col="1" text="bind:COMN_CD_NM"/>'
                 + '		</Band>'
                 + '	</Format>'
                 + '</Formats>';
	objPopDivGrid.set_binddataset("ds" + sPopDivId);
	objPopDivGrid.set_formats(sFormats);
	
	this.objPopupDiv   = objPopupDiv;
	this.objPopupDivDs = objPopDivGridDs;
};

/**
 * @class 그리드 멀티 콤보 호출 - Dataset Column Type이 String인 경우에만 작동
 * @param {Object} objForm   - Form Object
 * @param {String} sPopDivId - Multi Combo ID
 * @param {Object} objGrid   - Grid Object
 * @param {String} sColId    - Multi Combo로 사용할 Grid Column ID(Code)
 * @param {String} sColNm    - Multi Combo로 사용할 Grid Column ID(Name) : Optional
 * @param {String} e         - GridMouseEventInfo
 * @return  N/A
 * @example
 * this.gfnSetGridMultiCombo(this, obj, "Column2", "", e);
 */
pForm.objParentGrid = "";
pForm.sInputColId   = "";
pForm.sInputColNm   = "";
pForm.sPopDivId     = "";
pForm.gfnCallGridMultiCombo = function(objForm, sPopDivId, objGrid, sColId, sColNm, e)
{
	this.objParentGrid = objGrid;
	this.sInputColId   = this.gfnIsNullEmpty(sColId);
	this.sInputColNm   = this.gfnIsNullEmpty(sColNm);
	this.objPopupDiv   = eval("this." + sPopDivId);
	this.sPopDivId     = sPopDivId;
	var objDs = objGrid.getBindDataset();
	var nRow  = objDs.rowposition;
	var sVal  = objDs.getColumn(nRow, sColId);
	
	var objRect = objGrid.getCellRect(e.row, e.cell);
	this.objPopupDiv.trackPopupByComponent(objGrid, objRect.left, objRect.bottom, this.objPopupDiv.getOffsetWidth(), this.objPopupDiv.getOffsetHeight(), "", false);
	
	//Multi Combo 값 셋팅 하는 부분
	if(this.gfnIsNotNull(sVal)) {
		var arrVal = sVal.split(this.sCdDelimiter);
		
		//데이터 초기화
		for(var i = 0; i < this.objPopupDivDs.rowcount; i++) {
			this.objPopupDivDs.setColumn(i, "CHK", 0);
		}
		//데이터 셋팅
		for(var i = 0; i < arrVal.length; i++) {
			var nChkRow = this.objPopupDivDs.findRow("COMN_CD", arrVal[i]);
			this.objPopupDivDs.setColumn(nChkRow, "CHK", 1);
		}
	} else {
		//데이터 초기화
		for(var i = 0; i < this.objPopupDivDs.rowcount; i++) {
			this.objPopupDivDs.setColumn(i, "CHK", 0);
		}
	}
};

/**
 * @class 멀티 콤보 닫기 이벤트
 * @param {Object} obj - PopupDiv Object
 * @param {Object} e   - EventInfo Object
 * @return  N/A
 */
pForm._pdivMultiCombo_oncloseup = function(obj,e)
{
	this._btnOk_onclick();
};

/**
 * @class 멀티 콤보 확인 버튼 클릭 이벤트
 * @param {Object} obj - Button Object
 * @param {Object} e   - ClickEvent Object
 * @return  N/A
 */
pForm._btnOk_onclick = function(obj,e)
{
	eval("this." + this.sPopDivId).closePopup();
	
	var arrRet   = new Array();
	var arrRetNm = new Array();
	var objParentGridDs = this.objParentGrid.getBindDataset();
	var objPopDivGrid   = eval("this.objPopupDiv.form.grd" + this.sPopDivId);
	var objPopDivGridDs = objPopDivGrid.getBindDataset();
	
	for(var i=0; i<objPopDivGridDs.rowcount; i++) {
		 if( objPopDivGridDs.getColumn(i, "CHK") == true ) {
			arrRet.push(objPopDivGridDs.getColumn(i, "COMN_CD"));
			//Name이 있는 경우
			if(this.gfnIsNotNull(this.sInputColNm)) {
				arrRetNm.push(objPopDivGridDs.getColumn(i, "COMN_CD_NM"));
			}
		 }
	}
	
	var rtn = arrRet.join(this.sCdDelimiter);
	objParentGridDs.setColumn(objParentGridDs.rowposition, this.sInputColId, rtn);
	//Name이 있는 경우
	if(this.gfnIsNotNull(this.sInputColNm)) {
		var rtnNm = arrRetNm.join(this.sCdDelimiter);
		objParentGridDs.setColumn(objParentGridDs.rowposition, this.sInputColNm, rtnNm);
	}
};

/**
 * @class 멀티 콤보 취소 버튼 클릭 이벤트
 * @param {Object} obj - Button Object
 * @param {Object} e   - ClickEvent Object
 * @return  N/A
 */
pForm._btnCancel_onclick = function(obj,e)
{
	this.objPopupDiv.closePopup();
};

/**
 * @class 멀티 콤보 전체선택 버튼 클릭 이벤트
 * @param {Object} obj - Button Object
 * @param {Object} e   - ClickEvent Object
 * @return  N/A
 */
pForm._btnCheck_onclick = function(obj,e)
{
	var objParentGridDs = this.objParentGrid.getBindDataset();
	var objPopDivGrid   = eval("this.objPopupDiv.form.grd" + this.sPopDivId);
	var objPopDivGridDs = objPopDivGrid.getBindDataset();
	
	for (var i = 0; i < objPopDivGridDs.rowcount; i++)
	{
		objPopDivGridDs.setColumn(i, this.COM_CHECK_ID, "1");			
	}
};

/**
 * @class 멀티 콤보 전체해제 버튼 클릭 이벤트
 * @param {Object} obj - Button Object
 * @param {Object} e   - ClickEvent Object
 * @return  N/A
 */
pForm._btnUncheck_onclick = function(obj,e)
{
	var objParentGridDs = this.objParentGrid.getBindDataset();
	var objPopDivGrid   = eval("this.objPopupDiv.form.grd" + this.sPopDivId);
	var objPopDivGridDs = objPopDivGrid.getBindDataset();
	
	for (var i = 0; i < objPopDivGridDs.rowcount; i++)
	{
		objPopDivGridDs.setColumn(i, this.COM_CHECK_ID, "0");			
	}
};

/**
 * @class 그리드 필수 칼럼 호출
 * @param {Object} obj - Grid Object
 * @return  Array(칼럼ID / 다국어ID)
 */
pForm.gfnGetGridEssentialCols = function(objGrid)
{
	var arrCols  = new Array();
	var arrLangs = new Array();
	var nHeadCnt = objGrid.getCellCount("head");
	var nBodyCnt = objGrid.getCellCount("body");
	
	for(var i = 0; i < nHeadCnt; i++) {
		var sSubsumtext = objGrid.getCellProperty("head", i, "subsumtext");
		var sCssclass   = objGrid.getCellProperty("head", i, "cssclass");
		var sColor      = objGrid.getCellProperty("head", i, "color");
		var sMdtryYn    = "N";
		var sBindCol    = "";
		var arrBindCols = "";
		var sColId      = "";
		
		// Head가 한줄로 Body와 같은 경우
		if(nHeadCnt == nBodyCnt && this.gfnIsNotNull(sSubsumtext)) {
			sBindCol    = objGrid.getCellProperty("body", i, "text");
			arrBindCols = sBindCol.split(":");
			sColId      = arrBindCols[1];
		}
		// Head가 복잡한 경우 - calendarweekformat 이용
		if(nHeadCnt != nBodyCnt && this.gfnIsNotNull(sSubsumtext)) {
			sBindCol = objGrid.getCellProperty("head", i, "calendarweekformat");
			if(this.gfnIsNotNull(sBindCol)) {
				arrBindCols = sBindCol.split(":");
				sColId      = arrBindCols[1];
			} else {
				sColId = "";
			}
		}
		
		if(sCssclass == "essential" || sColor == "#f56800") {
			sMdtryYn = "Y";
		} else {
			sMdtryYn = "N";
		}
		
		if(this.gfnIsNotNull(sColId) && sMdtryYn == "Y") {
			arrCols.push(sColId);
			arrLangs.push(sSubsumtext);
		}
	}
	
	var objRtn = {MDRTY_COLS : arrCols, MDRTY_LANGS : arrLangs};
	return objRtn;
};