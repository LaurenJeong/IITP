﻿/**
*  BPO 플랫폼
*  @FileName 	Message.js 
*  @Creator 	PJY
*  @CreateDate 	2019.06.24
*  @Desction    
************** 소스 수정 이력 ***********************************************
*  date          		Modifier                Description
*******************************************************************************
*  2019.06.24     		PJY		       	      	최초 생성
*******************************************************************************
*/

var pForm = nexacro.Form.prototype;

/**
 * @class 메세지팝업오픈
 * @param {String} sMsgId - 메세지ID	
 * @param {Array} arrArg - 메세지에 치환될 부분은 "{0~N}"이 되고 치환값은 배열로 넘김 
 * @param {String} sPopId - 팝업ID(하나의 callback함수에서 중복된 메시지 처리를 할 경우 PopId구분을 위해 unique한 ID 반드시 사용)
 * @param {String} sCallback - 팝업콜백 (confirm성 메시지를 사용시 반드시 필요)
 * @param {Object} oOption - 메시지 옵션(현재 gfnConfirm2Btn(),gfnConfirm3Btn()에서 버튼명 설정시 사용)
 * @param {String} sType - 메시지 타입(CFM : confirm(확인/취소), CFM2 : confirm(예/아니요), CFM3 : 예/아니요/취소, 그외 : alert)
 * @return N/A
 * @example
 */
pForm.gfnAlert = function (sMsgId, arrArg, sPopId, sCallback, oOption, sType)
{
	if(this.gfnIsNull(sMsgId))			return;
	
	var sRet;
	var sMsg;
	var sMsgType;
	var sMsgUrl		= "";
	var sId      	= "";
	
	sMsg = this.gfnGetMessage(sMsgId,arrArg);
	var nCnt = this.gfnGetApplication().gdsUserInfo.rowcount;
	if(nCnt == 0 && (sMsg == "ERR_MSG" || sMsg == "MSG_ALT_FREETEXT")) {
		sMsg = arrArg;
		if(sMsg.indexOf("\\n") > -1) {
			sMsg = sMsg.replace(/\\n/g, "\r\n");
		}
	}else if(sMsg == "MSG_ALT_DATA_NOAUTH") {
		sMsg = "권한이 없습니다.";
	}else if(sMsg == "MSG_ERR_PROC_EXCEPTION") {
		sMsg = "서버 오류입니다.";
	}else if(nCnt == 1 && this.gfnIsNotNull(sMsg) && sMsg.indexOf("\\n") > -1) {
		sMsg = sMsg.replace(/\\n/g, "\r\n");
	}
	
	if( this.gfnIsNull(sMsg) ) 			sMsg = "확인";
	if( this.gfnIsNotNull(sType) ) 		sMsgType = sType;
	if( this.gfnIsNull(sCallback) ) 	sCallback = "fnMsgCallback";
	
	if(sMsgType == "CFM")				// confirm(확인/취소)일 경우
	{
		sMsgUrl 	= "com::comConfirm.xfdl";
		sId     	= sMsgId;
		
		if(this.gfnIsNull(sCallback)) this.gfnLog("callback함수를 지정하지 않았습니다","warn");
	}
	else if(sMsgType == "CFM2")			// confirm(예/아니요)일 경우
	{
		sMsgUrl 	= "com::comConfirmBtn2.xfdl";
		sId     	= sMsgId;
		
		if(this.gfnIsNull(sCallback)) this.gfnLog("callback함수를 지정하지 않았습니다","warn");
	}
	else if(sMsgType == "CFM3")			// confirm(예/아니요/취소)일 경우
	{
		sMsgUrl 	= "com::comConfirmBtn3.xfdl";
		sId     	= sMsgId;
		
		if(this.gfnIsNull(sCallback)) this.gfnLog("callback함수를 지정하지 않았습니다","warn");
	}
	else//alert일 경우
	{
		sMsgUrl 	= "com::comAlert.xfdl";
		sId     	= sMsgId;
	}
	
	//팝업 ID 없을 시 default 설정
	if(this.gfnIsNotNull(sPopId)) sId = sPopId;
	
	var oArg     = {argMsg : sMsg, argType : sMsgType, argOption : oOption, argArrArg : arrArg};
	var sPopupType = this.gfnGetArgument("popupType");
	
	var nWidth = 400;
	var nHeight = 160;
	
	if (this.gfnIsNotNull(sPopupType)) {
		if (this.getOffsetWidth() < nWidth)			nWidth = this.getOffsetWidth();
		if (this.getOffsetHeight() < nHeight)		nHeight = this.getOffsetHeight();
	}
	
	var oPopOption		= {titlebar: "false", width:nWidth, height:nHeight};
	
	this.gfnOpenPopup(sId, sMsgUrl, oArg, sCallback, oPopOption);
};

/**
 * 공통 Confirm 메시지 팝업 호출
 */
pForm.gfnConfirm = function (sMsgId, arrArg, sPopId, sCallback, oOption)
{
	this.gfnAlert(sMsgId, arrArg, sPopId, sCallback, oOption,"CFM");
};

/**
 * 공통 Confirm 메시지 팝업 호출
 */
pForm.gfnConfirm2Btn = function (sMsgId, arrArg, sPopId, sCallback, oOption)
{
	this.gfnAlert(sMsgId, arrArg, sPopId, sCallback, oOption,"CFM2");
};

/**
 * 공통 Confirm 메시지 팝업 호출
 */
pForm.gfnConfirm3Btn = function (sMsgId, arrArg, sPopId, sCallback, oOption)
{
	this.gfnAlert(sMsgId, arrArg, sPopId, sCallback, oOption,"CFM3");
};

/**
 * @class 메세지 치환
 * @param {String} msg - 메세지	
 * @param {Array} values - 메세지에 치환될 부분은 "{0~N}"이 되고 치환값은 배열로 넘김 
 * @return {String} 파라미터값이 치환된 메시지
 */
pForm.gfnConvertMessage = function(msg, values) 
{
    return msg.replace(/\{(\d+)\}/g, function() {
		var value = values[arguments[1]];
		if (value == null)	value = "";
        return value;
    });
};

/**
 * @class 메세지 치환 후 완성된 메시지 리턴
 * @param {String} sMsgId - 메세지ID	
 * @param {Array}  arrArg - 메세지에 치환될 부분은 "{0~N}"이 되고 치환값은 배열로 넘김 
 * @return {String} 파라미터값이 치환된 메시지
 */
pForm.gfnGetMessage = function(sMsgId, arrArg) 
{
    var objMsgDs = nexacro.getApplication().gdsMsg;
	var nRow = objMsgDs.findRow("MLANG_ID", sMsgId);
	var sMsg;
	var arrMsgArr = arrArg;
	
	if(nRow < 0)
	{
		sMsg = sMsgId;
	}
	else
	{
		sMsg = objMsgDs.getColumn(nRow, "MLANG_NM");
	}
	
	if (this.gfnIsArray(arrArg) == false) {
		if(this.gfnIsNotNull(arrArg)) {
			arrMsgArr = [arrArg];
		}
	}
	
	if(this.gfnIsNull(arrMsgArr)) {
		arrMsgArr =  new Array();
	}

	// 줄바꿈 변경
	sMsg = sMsg.replace(/\\n/g, String.fromCharCode(10) + String.fromCharCode(13));
	sMsg = this.gfnConvertMessage(sMsg, arrMsgArr);
	
	return sMsg;
};

/**
 * Message 찾기(Array 반환)
 * @param    : {String} sMsgCd - MLANG_ID 값
 * @return    : {Array}
 */
pForm.gfnGetMsgToArray = function (sMsgId)
{
	var nRow = nexacro.getApplication().gdsMsg.findRow("MLANG_ID", sMsgId);
	if (nRow >= 0) 
	{
		return this.gfnGetRowDataToArray(nexacro.getApplication().gdsMsg, nRow);
	}
	else 
	{
		return "";
	}
};

/**
 * 저장시 변경된 데이터 정보 메시지 반환
 * @param	{Object} objDs - 데이터셋
 * @param	{String} sTitle - 타이틀
 * @param	{Boolean} bStatus - STATUS컬럼값으로 체크할지 여부(기본값 : true). false인 경우 getRowType()으로 체크함.
 * @param	{Boolean} bFilterCheck - 필터된 데이터 체크여부(기본값 : false)
 * @return  {String} 메시지
 */
pForm.gfnGetUpdateMsg = function (objDs, sTitle, bStatus, bFilterCheck,bSkipCheck)
{
	if (this.gfnIsNull(bStatus))			bStatus = true;
	if (this.gfnIsNull(bFilterCheck))		bFilterCheck = false;
	if (this.gfnIsNull(bSkipCheck))			bSkipCheck = true;
	
	// 저장하시겠습니까?\n- 상세내역 : 입력(1건), 수정(1건), 삭제(1건)
	
	var arrCnt = pForm._gfnGetUpdateCnt(objDs, bStatus, bFilterCheck, bSkipCheck);
	
	// 입력({0}건), 수정({1}건), 삭제({2}건)
	var sMsg = this.gfnGetMessage("MSG_ALT_DATA_SAVECNT", arrCnt);
	
	// TODO : 타이틀표시 변경
	if (this.gfnIsNotNull(sTitle)) {
		sMsg = sTitle + " : " + sMsg;
	}
	
	// 엔터, -표시 추가
	sMsg = "\n- " + sMsg;
	
	return sMsg;
};

/**
 * 저장시 변경된 데이터 정보를 Array로 반환
 * @param	{Object} objDs - 데이터셋
 * @param	{Boolean} bStatus - STATUS컬럼값으로 체크할지 여부(기본값 : true). false인 경우 getRowType()으로 체크함.
 * @param	{Boolean} bFilterCheck - 필터된 데이터 체크여부(기본값 : false)
 * @return  {Array} [입력건수,수정건수,삭제건수]
 */
pForm._gfnGetUpdateCnt = function (objDs, bStatus, bFilterCheck,bSkipCheck)
{
	if (this.gfnIsNull(bStatus))			bStatus = true;
	if (this.gfnIsNull(bFilterCheck))		bFilterCheck = false;
	if (this.gfnIsNull(bSkipCheck))			bSkipCheck = true;
	
	var nICnt = 0;
	var nUCnt = 0;
	var nDCnt = 0;
	var sStatus = "";
	
	var nRowCnt = objDs.getRowCount();
	if (bFilterCheck)	nRowCnt = objDs.getRowCountNF();
	
	if (bStatus) {				// STATUS컬럼값으로 체크
		for (var i = 0 ; i < nRowCnt ; i++) {
			if (bFilterCheck) {
				sStatus = objDs.getColumnNF(i, pForm.COM_STATUS_ID);
			} else {
				sStatus = objDs.getColumn(i, pForm.COM_STATUS_ID);
			}
		
			if (sStatus == pForm.COM_STATUS_INSERT) {
				nICnt++;
			} else if (sStatus == pForm.COM_STATUS_UPDATE) {
				nUCnt++;
			} else if (sStatus == pForm.COM_STATUS_DELETE) {
				nDCnt++;
			} else {
				// STATUS값으로 체크하는 경우 CHECK값 변경 체크시
				if (bSkipCheck == false) {
					if (bFilterCheck) {
						if (objDs.getColumnNF(i, this.COM_CHECK_ID) != objDs.getOrgColumnNF(i, this.COM_CHECK_ID)) {
							nUCnt++;
						}
					} else {
						if (objDs.getColumn(i, this.COM_CHECK_ID) != objDs.getOrgColumn(i, this.COM_CHECK_ID)) {
							nUCnt++;
						}
					}
				}
			}
		}
	} else {					// getRowType()으로 체크

		// insert, update 갯수
		for (var i = 0 ; i < nRowCnt ; i++) {
			
			if (bFilterCheck) {
				sStatus = objDs.getRowTypeNF(i);
			} else {
				sStatus = objDs.getRowType(i);
			}
			
			if (sStatus == Dataset.ROWTYPE_INSERT) {
				nICnt++;
			} else if (sStatus == Dataset.ROWTYPE_UPDATE) {
				if (bSkipCheck == false) {
					nUCnt++;
				} else {
					if (bFilterCheck) {
						sStatus = objDs.getColumnNF(i, pForm.COM_STATUS_ID);
					} else {
						sStatus = objDs.getColumn(i, pForm.COM_STATUS_ID);
					}
					
					if (sStatus == pForm.COM_STATUS_UPDATE) {
						nUCnt++;
					}
				}
			}
		}
		
		// delete갯수
		nDCnt =  objDs.getDeletedRowCount();
	}
	
	return [nICnt,nUCnt,nDCnt];
};
