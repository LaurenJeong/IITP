/**
*  BPO 플랫폼
*  @FileName 	File.js 
*  @Creator 	Garden Park
*  @CreateDate 	2019.06.24
*  @Desction    
************** 소스 수정 이력 ***********************************************
*  date          		Modifier                Description
*******************************************************************************
*  2019.06.24     		Garden Park		       	최초 생성
*******************************************************************************
*/

var pForm = nexacro.Form.prototype;

/**
 * @class File Path 문자열(예 : C:\a\b\filename.ext)에서 File명(예 : filename)을 추출 <br>
 * @param {String} sPath - File Path 문자열 (예 : "C:\a\b\filename.ext")
 * @param {String} bExt - extend를 return되는 File명에 포함시킬지 여부 ( 옵션 : Default=false )
 * @return {String} 
 * 성공 : <br>
 * bExt가 true인 경우 ==> sPath에서 File명(예 : "filename.ext") <br>
 * bExt가 false인 경우 ==> sPath에서 File명(예 : "filename") <br>
 * 실패 : "" <br>
 */
pForm.gfnGetFileName = function (sPath, bExt)
{
	var start_pos,end_pos,tmp_pos,filename;

	if (this.gfnIsNull(sPath)) 
	{
		return "";
	}
	if (this.gfnIsNull(bExt)) 
	{
		bExt = false;
	}

	start_pos = Math.max(this.gfnPosReverse(sPath, "\\"), this.gfnPosReverse(sPath, "/"));
	tmp_pos = this.gfnPosReverse(sPath, "::");
	if (tmp_pos > 0) 
	{
		tmp_pos++;
	}
	start_pos = Math.max(start_pos, tmp_pos);
	if (bExt == false) 
	{
		end_pos = this.gfnPosReverse(sPath, ".");
		if (end_pos < 0) 
		{
			end_pos = sPath.length;
		}
		filename = sPath.substr(start_pos + 1, end_pos - start_pos - 1);
	}
	else 
	{
		filename = sPath.substr(start_pos + 1);
	}

	return filename;
};

/**
 * @description size를 byte로 변환처리한다.
*/ 
/**
 * @class  size를 byte로 변환처리한다.
 * @param  {string} fileSize - 파일사이즈 및 용량(300MB)
 * @return {integer} 파일 byte사이즈
*/
pForm.gfnSizeToByte = function(fileSize) 
{
	var unit = fileSize.match(/[^\d]+/g),
		size = fileSize.match(/\d+/);

	unit = unit ? unit[0].toLowerCase() : "";
	size = size ? size[0] : fileSize;
	
	if (unit == "mb") {
		return size * 1024 * 1024;
	}
	else if (unit == "gb") {
		return size * 1024 * 1024 * 1024;
	}
	else if (unit == "tb") {
		return size * 1024 * 1024 * 1024 * 1024;
	}
	else if (unit == "") {
		return size;
	}
	else {
		return fileSize;
	}
};

/**
 * @class 현재 Form 상의 FileDownloadTransfer 컴포넌트를 이용하여 파일을 다운로드한다. <br>
 * @param {Object} objFileDownTransfer - 파일다운로드 트렌스퍼 컴포넌트
 * @param {String} sFileId   - 다운로드 할 파일 ID
 * @param {String} sfileName - 다운로드 할 파일명(Nexacro)
 * @return N/A
 */
pForm.gfnFileDownloadTransfer = function(objFileDownTransfer, sFileId, sFileName)
{
	var sRequestMapping = "/file/fileDownload.do";
	var sUrl = this.gfnGetServerUrl() + this.gfnGetPreUrl(this.SVC.cmm) + sRequestMapping;
	var sMenuId = this.gfnGetArgument("menuId");
	
	if (this.gfnIsNull(sUrl)) return;
	
	objFileDownTransfer.set_downloadfilename(sFileName);
	objFileDownTransfer.setPostData("FL_NM", "");
	objFileDownTransfer.setPostData("FL_ID", sFileId);
	objFileDownTransfer.setPostData("CMM_MNU_ID",  sMenuId);
	objFileDownTransfer.setPostData("CMM_MDUL_CD", this.gfnIsNullEmpty(this.gfnGetArgument("mdulCd")));
	
	objFileDownTransfer.set_url(sUrl);
	
	objFileDownTransfer.download();
};