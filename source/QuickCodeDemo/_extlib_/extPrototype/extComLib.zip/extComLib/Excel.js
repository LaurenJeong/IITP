/**
*  BPO 플랫폼
*  @FileName 	Excel.js 
*  @Creator 	PJY
*  @CreateDate 	2019.09.09
*  @Desction    엑셀관련 함수
************** 소스 수정 이력 ***********************************************
*  date          		Modifier                Description
*******************************************************************************
*  2019.09.09     		PJY       	      		최초 생성
*******************************************************************************
*/

var pForm = nexacro.Form.prototype;

// xeni URL
pForm.COM_EXCEL_URL = "svc::cmm/XExportImport.do";

/**
 * @class gfnGetSheetName : Sheet명 반환(지원안하는 특수문자 제거)
* @param	{String} sSheetName	- Sheet명
* @param	{String} sNullNm	- 빈값일때 sheet명
* @return	{String} Sheet명
*/
pForm.gfnGetSheetName = function(sSheetName, sNullNm)
{
	if (this.gfnIsNull(sNullNm))	sNullNm = "Sheet1";

	var regExp = /[?*:\/\[\]]/g;
	var sRetuenNm;

	if (this.gfnIsNull(sSheetName))	sSheetName = sNullNm;

	sRetuenNm = sSheetName.replace(regExp,""); //시트명에 특수문자 제거
	sRetuenNm = this.gfnIsNull(sRetuenNm) ?sNullNm : sRetuenNm;

	//sheetName 30이상일경우 기본시트명
	if( String(sRetuenNm).length > 30 ){
		sRetuenNm =  sNullNm;
	}

	return sRetuenNm;
};

/**
 * @class excel export <br>
 * @param {Object} objGrid - Grid Object
 * @param {String} [sSheetName]	- sheet name
 * @param {String} [sFileName]	- file name
 * @return N/A
 * @example
 * this.gfnExcelExport(this.gridExport, "SheetName","");
 */
pForm.gfnExcelExport = function(objGrid,  sSheetName, sFileName, oOption)
{
	// 옵션 기본값 설정
	if(this.gfnIsNull(oOption))
	{
		oOption = {
			exportType	: ""
		};
	}

	if(this.gfnIsNull(oOption.exportType))		oOption.exportType = "EXCEL2007";

	var sExportType = oOption.exportType;

	//this.setWaitCursor(true);
	var objGridExcel;

	var regExp = /[?*:\/\[\]]/g;  				// (엑셀에서 지원하지않는 모든 문자)

	sFileName = this.gfnIsNull(sFileName) ? "ExcelExport_" + this.gfnGetArgument("menuNm") + "_" + this.gfnGetDate("time") : sFileName;		// fileName nullcheck
	sFileName = sFileName.replace(regExp, "");	// 파일명에 특수문자 제거

	var sType	= objGrid.toString().toUpperCase();

	this.objExport = null
	this.objExport = new ExcelExportObject();
	this.objExport.set_exporturl(this.COM_EXCEL_URL);

	if(sType == "[OBJECT GRID]")
	{
		sSheetName = this.gfnGetSheetName(sSheetName);
		objGridExcel = this._gfnCreateExportGrid(objGrid);

		this.objExport.addExportItem(nexacro.ExportItemTypes.GRID, objGridExcel, sSheetName + "!A1","allband","allrecord","nosuppress","allstyle","image","","width");

		this.objExport.objgrid = objGridExcel;
	}
	else
	{
		sExportType = "EXCEL2007";			// Sheet여러개일때는 xlsx로 Export

		var arrGridExcel = new Array();

		for(var i=0; i<objGrid.length; i++)
		{
			strSheetNm = sSheetName[i];
			strSheetNm = this.gfnIsNull(strSheetNm) ? "Sheet" + (i+1) : strSheetNm;
			strSheetNm = this.gfnGetSheetName(strSheetNm);

			objGridExcel = this._gfnCreateExportGrid(objGrid[i]);

			arrGridExcel.push(objGridExcel);

			this.objExport.addExportItem(nexacro.ExportItemTypes.GRID, objGridExcel, strSheetNm + "!A1","allband","allrecord","nosuppress","allstyle","image","","width");
		}
		this.objExport.objgrid = arrGridExcel;
	}

	this.objExport.set_exporttype(eval("nexacro.ExportTypes." + oOption.exportType));	//내보내기 할 엑셀 형식 지정
	this.objExport.set_exportfilename(sFileName);
 	//this.objExport.set_exportuitype("none");
 	//this.objExport.set_exportmessageprocess("");
	this.objExport.set_exportuitype("exportprogress");
 	this.objExport.set_exporteventtype("itemrecord");
	this.objExport.set_exportmessageprocess("%d[%d/%d]");
	this.objExport.set_exportactivemode('active');

	this.objExport.addEventHandler("onsuccess", this.gfnExportOnsuccess, this);
	this.objExport.addEventHandler("onerror", this.gfnExportOnerror, this);
	
	var param = "MDUL_CD=" + this.gfnGetArgument("mdulCd") + " " + "MNU_ID=" + this.gfnGetArgument("menuId");
	var result = this.objExport.exportData(param);
};

pForm._gfnCreateExportGrid = function(objGrid)
{
	var sGridId		= this._getUniqueId(objGrid);
	var sFormat		= objGrid.getCurFormatString(false);

	var sGridName	= "_excel_" + sGridId;
	var objTempGrid;

	if (!this[sGridName])
	{
		// 포멧 저장용 그리드 생성
		objTempGrid = new Grid(sGridName, 0, 0, 0, 0);
		this.addChild(sGridName, objTempGrid);
		objTempGrid.set_visible(false);
		objTempGrid.show();
	} else {
		objTempGrid = this[sGridName];
	}

	//var strFormatContents = objGrid.getCurFormatString();
	objTempGrid.set_formats("<Formats>" + sFormat + "</Formats>");
	objTempGrid.set_formatid(objGrid.formatid);
    objTempGrid.set_binddataset(objGrid.binddataset);
    //objTempGrid.set_autofittype(objGrid.autofittype);

	var bAdmin = this.gfnIsMdulAdmin();		// 관리자여부

	var nCol, nColspan, nHideCnt;

	// 일반사용자인 경우에만 숨기는 셀 처리.
	if (bAdmin == false) {
		var nSize, nOrgSize, nHideCnt;

		for (var i=0 ; i < objTempGrid.getCellCount("body"); i++) {
			nCol 		= parseInt(objTempGrid.getCellProperty("body",i, "col"));
			nColspan	= parseInt(objTempGrid.getCellProperty("body",i, "colspan"));

			nHideCnt = 0;

			// 머지된 셀의 경우 모두 숨겨진 경우에 안보이게 처리함.
			for (var j = nCol; j < (nCol + nColspan); j++) {
				nOrgSize 	= this._gfnGetGridOrgColsize(objTempGrid,j);

				if (nOrgSize == -1) {
					nHideCnt++;
				}
			}

			if (nHideCnt == nColspan) {
				objTempGrid.setCellProperty("body", i, "displaytype","none");
			}
		}
	}

	objTempGrid.set_summarytype(objGrid.summarytype);
	return objTempGrid;
};

/**
 * @class excel export on sucess <br>
 * @param {Object} obj
 * @param {Event} e
 * @return N/A
 * @example
 */
pForm.gfnExportOnsuccess = function(obj, e)
{
	//this.setWaitCursor(false);
};

/**
 * @class  excel export on error <br>
 * @param {Object} obj
 * @param {Event} e
 * @return N/A
 * @example
 */
pForm.gfnExportOnerror = function(obj,  e)
{
	this.gfnAlert("MSG_ERR_EXCEL_EXPORT");//엑셀 출력 오류입니다.
	//this.setWaitCursor(false);
};

/**
 * @class  FileDialog에서 사용할 확장자별 파일유형 반환
 * @param {String} sImportType - 타입(EXCEL,EXCEL2007,HANCELL2014,CSV)
 * @return {String} 적용될 파일형식
 */
pForm.gfnGetFileFilter = function(sImportType)
{
	var strFilefilter = "";

	switch(sImportType)
	{
	    case "EXCEL":
			strFilefilter = "Worksheet 97 - 2003 Files (*.xls)|*.xls|";
			break;
	    case "EXCEL2007":
	    	strFilefilter = "Worksheet Files (*.xlsx)|*.xlsx|";
			break;
	    case "HANCELL2014":
	    	strFilefilter = "Hancell Files (*.cell)|*.cell|";
			break;
	    case "CSV":
	    	strFilefilter = "CSV (*.csv)|*.csv|";
			break;
	    default : break;
	}

	strFilefilter += "All (*.xls;*.xlsx;*.cell;*.csv)|*.xls;*.xlsx;*.cell;*.csv|";

	return strFilefilter;
};

/**
 * @class  excel import( 데이터 헤더포함 ) <br>
 * @param {String} objDs - dataset
 * @param {String} [sSheet]	- sheet name(default:Sheet1)
 * @param {String} sHead - Head 영역지정
 * @param {String} [sBody] - body 영역지정(default A2)
 * @param {String} [sCallback]	- callback 함수
 * @param {String} [sImportId] - import id(callback호출시 필수)
 * @param {Object} [objForm] - form object(callback호출시 필수)
 * @return N/A
 * @example
 * this.gfnExcelImportAll("dsList","SheetName","A1:G1","A2","fnImportCallback","import",this);
 */
pForm.gfnExcelImportAll = function(objDs,sSheet,sHead,sBody,sCallback,sImportId,objForm,sImportType)
{
	//this.setWaitCursor(true);

	if (this.gfnIsNull(sSheet))		sSheet = "sheet1";
	if (this.gfnIsNull(sBody))			sBody = "A2";
	if (this.gfnIsNull(sHead)) 		return false;
	if (this.gfnIsNull(sImportType))	sImportType = "EXCEL2007";

	var sFilefilter = this.gfnGetFileFilter(sImportType);

	var objImport ;

	objImport = new nexacro.ExcelImportObject(objDs+"_ExcelImport",this);
	objImport.set_importurl(this.COM_EXCEL_URL);
	objImport.set_importtype(eval("nexacro.ExportTypes." + sImportType));
	objImport.set_filefilter(sFilefilter);

	if (this.gfnIsNotNull(sCallback)) {
		objImport.callback = sCallback;
		objImport.importid = sImportId;
		objImport.form = objForm;
	}

	objImport.addEventHandler("onsuccess", this.gfnImportAllOnsuccess, this);
	objImport.addEventHandler("onerror", this.gfnImportAllOnerror, this);
	var sParam1 = "[Command=getsheetdata;Output=outds;Head=" + sSheet + "!" + sHead + ";Body=" + sSheet + "!" + sBody + "]";
	var sParam2 = "[" + objDs + "=outds]";

	objImport.importData("", sParam1, sParam2);
	objImport = null;
};

/**
 * @class excel import on success <br>
 * @param {Object} obj
 * @param {Event} e
 * @return N/A
 * @example
 */
pForm.gfnImportAllOnsuccess = function(obj,  e)
{
	//this.setWaitCursor(false);
	var sCallback = obj.callback;
	var sImportId = obj.importid;

	//화면의 callback 함수 호출
	if (this.gfnIsNotNull(sCallback)) {
		if (this[sCallback]) {
			this.lookupFunc(sCallback).call(sImportId);
		}
	}
};

/**
 * @class  excel import( 데이터 헤더제외 ) <br>
 * @param {String} sDataset - dataset
 * @param {String} [sSheet]	- sheet name
 * @param {String} [sBody] - body 영역지정
 * @param {String} [sCallback] - callback 함수
 * @param {String} [sImportId] - import id(callback호출시 필수)
 * @param {Object} [objForm] - form object(callback호출시 필수)
 * @return N/A
 * @example
 * this.gfnExcelImport("dsList","SheetName","A2","fnImportCallback","import",this);
 */
pForm.gfnExcelImport = function(sDataset, sSheet, sBody, sCallback, sImportId, objForm, sImportType)
{
	//this.setWaitCursor(true);

	if (this.gfnIsNull(sSheet))		sSheet = "sheet1";
	if (this.gfnIsNull(sBody))			sBody = "A2";
	if (this.gfnIsNull(sImportType))	sImportType = "EXCEL2007";

	var sFilefilter = this.gfnGetFileFilter(sImportType);

	var objImport;
	objImport = new nexacro.ExcelImportObject(sDataset + "_ExcelImport", this);
	objImport.set_importurl(this.COM_EXCEL_URL);
	objImport.set_importtype(eval("nexacro.ExportTypes." + sImportType));
	objImport.set_filefilter(sFilefilter);

	objImport.outds = sDataset;

	if (this.gfnIsNotNull(sCallback)) {
		objImport.callback = sCallback;
		objImport.importid = sImportId;
		objImport.form = objForm;
	}

	//out dataset 생성(차후 onsucess 함수에서 헤더생성하기 위한)
	var sOutDsName = sDataset + "_outds";
	if (this.isValidObject(sOutDsName)) {
		this.removeChild(sOutDsName);
	}
	var objOutDs = new Dataset();
	objOutDs.name = sOutDsName;
	this.addChild(objOutDs.name, objOutDs);

	objImport.addEventHandler("onsuccess", this.gfnImportOnsuccess, this);
	objImport.addEventHandler("onerror", this.gfnImportAllOnerror, this);
	var sParam = "[command=getsheetdata;output=outDs;body=" + sSheet + "!" + sBody +";]";
 	var sParam2 = "[" + sOutDsName + "=outDs]";

	objImport.importData("", sParam, sParam2);
	objImport = null;

	//this.setWaitCursor(false);
};

/**
 * @class excel import on success <br>
 * @param {Object} obj
 * @param {Event} e
 * @return N/A
 * @example
 */
pForm.gfnImportOnsuccess = function(obj,  e)
{
	//this.setWaitCursor(false);

	var objOutDs = this.objects[obj.outds + "_outds"];
	var objOrgDs = this.objects[obj.outds];
	var sCallback = obj.callback;
	var sImportId = obj.importid;
	var objForm = obj.form;
	var sColumnId;

	//기존 데이터셋의 내용으로 헤더복사
	for (var i = 0, s = objOrgDs.getColCount(); i < s; i++) {
		sColumnId = "Column" + i;
		if (sColumnId != objOrgDs.getColID(i)) {
			objOutDs.updateColID(sColumnId, objOrgDs.getColID(i))
		}
	}

	objOrgDs.clearData();
	objOrgDs.copyData(objOutDs);

	//화면의 callback 함수 호출
	if (this.gfnIsNotNull(sCallback)) {
		if (this[sCallback]) {
			this.lookupFunc(sCallback).call(sImportId);
		}
	}
};

/**
 * @class  excel import on error <br>
 * @param {Object} obj
 * @param {Event} e
 * @return N/A
 * @example
 */
pForm.gfnImportAllOnerror = function(obj,  e)
{
	//this.setWaitCursor(false);
	this.alert(e.errormsg);
};

// 그리드에 연결된 정보로 데이터셋 컬럼 생성
pForm.gfnMakeColInfoFromGrid = function(objGrid, objToDs)
{
	var sColID = "";
	var sBand = "body";

	objToDs.clear();		// 데이터셋초기화

	// 그리드 정보로 dataset 컬럼 생성
	for(var i=0; i < objGrid.getCellCount(sBand); i++)
	{
		sColID = this.gfnGetGridBindName(objGrid, i);

		if (sColID != "")
		{
			objToDs.addColumn(sColID, "string" );
		}
		else
		{
			objToDs.addColumn("COL_" + i, "string" );
		}
	}
};

/**
 * @class  Excel Download Setting
 * @param {Grid Object} gridObj
 * @param {Form Object} thisObj
 * @param {Object} oValue
 * @param {String} sQueryId
 * @param {object} objDiv - 조회 Div
 * @param {Object} oPsnInfo - 개인정보처리 내역 정보
 * @return N/A
 * @example
 */
pForm.gfnExcel = function(gridObj,thisObj,oValue,sQueryId, objDiv, oPsnInfo)
{
	var urlValue = "file/excelDownload.do";

	/*var dataset = gridObj.getBindDataset();
	if(dataset.rowcount == 0){
		//Excel Data 조회가 되지 않았다는 경고창
		return;
	}*/

	if(this.gfnIsNull(gridObj)){
		return;
	}

	if(this.gfnIsNull(thisObj)){
		return;
	}

	//쿼리 아이디 없으면 오류
	if(this.gfnIsNull(sQueryId)){
		this.alert("REQ_QRY_ID");//쿼리 아이디는 필수 입니다.
		return;
	}

	if(this.gfnIsNull(oValue)){
		oValue = {EXCEL_FILENAME  : thisObj.id
		        , CMM_MNU_ID      : this.gfnGetArgument("menuId")
				, CMM_MDUL_CD     : this.gfnIsNullEmpty(this.gfnGetArgument("mdulCd"))
				, DFT_CENT_ID     : this.gfnGetUserInfo("DFT_CENT_ID")
				, SEARCH_QUERY_ID : sQueryId }
	}else {
		oValue.SEARCH_QUERY_ID = sQueryId;
		oValue.CMM_MNU_ID = this.gfnGetArgument("menuId")
		oValue.CMM_MDUL_CD = this.gfnIsNullEmpty(this.gfnGetArgument("mdulCd"))
		
		if(this.gfnIsNull(oValue.EXCEL_FILENAME)){
			oValue.EXCEL_FILENAME = thisObj.id;
		}
		if(this.gfnIsNull(oValue.DFT_CENT_ID)){
			oValue.DFT_CENT_ID = this.gfnGetUserInfo("DFT_CENT_ID")
		}
	}

	//전체 조회 Download
	this.gfnExcelDownload(urlValue, gridObj, thisObj, oValue, objDiv, oPsnInfo);
};

/**
 * @class  Excel form Download (그리드 헤더정보를 엑셀로 다운로드)
 * @param {Grid Object} gridObj
 * @param {Form Object} thisObj 
 * @return N/A
 * @example
 */
pForm.gfnExcelDownloadFormFromGrid = function(gridObj, thisObj) 
{
	var urlValue = "file/excelDownloadFromGrid.do";
	var oValue = {
		EXCEL_FILENAME : thisObj.id,
		flag : ""
	};
	
	this.gfnExcelDownload(urlValue, gridObj, thisObj, oValue);
}

/**
 * @class  Excel Download
 * @param {String}      sUrl
 * @param {Grid Object} oGridObj
 * @param {Form Object} oView
 * @param {String}      sParamValue
 * @param {Div Object}  objDiv
 * @param {Object} oPsnInfo - 개인정보처리 내역 정보
 * @return N/A
 * @example
 */
pForm.gfnExcelDownload = function(sUrl, oGridObj, oView, oParamValue, objDiv, oPsnInfo)
{

	if(system.navigatorname == "nexacro"){
		this.gfnAlert("MSG_ALT_PROC_WEBEXECUTE");
		return;
	}

	var objForm = document.createElement("form"); // form 엘리멘트 생성

	// Url Setting
	var objEnv = nexacro.getEnvironment();
	var sBaseUrl = this.gfnGetServerUrl();//objEnv.services.get_item("svc").url;
	var sActionUrl = sBaseUrl + this.gfnGetPreUrl() + "/" + sUrl;
	var objInput1 = document.createElement("input");

	// CommandMap Base Struncture
	var oValue = {
		PARAM      : oParamValue ,
		MAP        : {},
		LIST       : {
			EXCEL_FORMAT : []			
		},
		COMMON     : {
			USER_INFO : {}
		},
		SEARCHLIST : []
	};

	// file name setting
	var sFileName = this.gfnSetFileName(oGridObj);
	oValue.PARAM.EXCEL_FILENAME = sFileName;

	// wms default center code setting
	/*trace("this.gfnGetApplication().gvAppId : " + this.gfnGetApplication().gvAppId);
	if (this.gfnGetApplication().gvAppId == "WMS" ) {
		oValue.PARAM.DFT_CENT_ID =  this.gfnGetUserInfo("DFT_CENT_ID");
	}*/

	// CommandMap Setting ;
	/*var gdsCommonCount = application.gds_common.getColCount();
	for (var i=0 ; gdsCommonCount > i ; i++) {
		var obj_RowValue = application.gds_common.getColumn(0,i);
		var obj_RowInfoId = application.gds_common.getColumnInfo(i).id;
		oValue.COMMON[obj_RowInfoId] = obj_RowValue;
	}*/

	// Common.UserInfo
	/*var gdsUserInfoCount = application.gds_userInfo.getColCount();
	for (var i=0 ; gdsUserInfoCount > i ; i++) {
		var obj_RowValue = application.gds_userInfo.getColumn(0,i);
		var obj_RowInfoId = application.gds_userInfo.getColumnInfo(i).id;
		if (obj_RowValue === undefined ) {
			obj_RowValue = "";
		}
		oValue.COMMON.USER_INFO[obj_RowInfoId] = obj_RowValue;
	}*/

	// 그리드 개인화 변형된 Grid Object
	var objGridExcel = this._gfnCreateExportGrid(oGridObj);
	// Grid Format
	var gridCellCount = objGridExcel.getCellCount("head");
	var dataColumnCnt = objGridExcel.getCellCount("body");

	for (var i = 0 ; gridCellCount > i ; i++) {
		var str_RowText = objGridExcel.getCellProperty("head", i , "text");
		if(str_RowText == "No." || str_RowText == "NO") continue;
		var str_RowDataField = str_RowText == "No." ? "NO" : objGridExcel.getCellProperty("body", i , "text");
		var str_subSumText   = objGridExcel.getCellProperty("head", i, "subsumtext");
		if(this.gfnIsNull(str_RowDataField)){continue;}
		//var str_TxtLang = str_RowText == "No." ? "No." : this.gfnIsNull(this.gfnGetWord(str_RowDataField.replace("bind:", ""))) ? str_RowText : this.gfnGetWord(str_RowDataField.replace("bind:", ""));
		var str_TxtLang = str_RowText == "No." ? "No." : this.gfnIsNull(this.gfnGetWord(str_subSumText)) ? str_RowText : this.gfnGetWord(str_subSumText);
		var FILED_NAME3  = null;
		var nOrgSize 	 = this._gfnGetGridOrgColsize(objGridExcel,i);
		var sDisplayType = objGridExcel.getCellProperty("body", i , "displaytype");

		if(oParamValue.flag == "mergeheader") {
			// WMS 모듈, 헤더가 multirow인 경우, oParamValue의 flag value가 mergeheader인 경우
			var row = objGridExcel.getCellProperty("head", i, "row");
			if(str_RowDataField != "bind:CHK") {
				if(sDisplayType == "none") continue;//displaytype이 none이면 엑셀 다운로드 칼럼에서 제외 - 그리드 개인화 영향
				oValue.LIST.EXCEL_FORMAT.push({
					"DATA_FILED"  : (this.gfnIsNull(str_RowDataField)) ? "" : str_RowDataField.replace("bind:",""),
					"FIELD_NAME1" : str_TxtLang,
					"COL"         : objGridExcel.getCellProperty("head", i, "col"), 	// colIdx
					"ROW"         : objGridExcel.getCellProperty("head", i, "row"),		// rowIdx
					"COL_CNT"     : objGridExcel.getCellProperty("head", i, "colspan"), // colspan
					"ROW_CNT"     : objGridExcel.getCellProperty("head", i, "rowspan"),	// rowspan
				});
			}
		} else {
		  if(str_RowDataField != "bind:CHK") {
			if(sDisplayType == "none") continue;//displaytype이 none이면 엑셀 다운로드 칼럼에서 제외 - 그리드 개인화 영향
			oValue.LIST.EXCEL_FORMAT.push({
				"DATA_FILED"  : (this.gfnIsNull(str_RowDataField)) ? "" : str_RowDataField.replace("bind:",""),
				"FILED_NAME1" : str_TxtLang,
				"FILED_NAME2" : null ,
				"FILED_NAME3" : FILED_NAME3,
			});
		 }
		}
	}

	// Search Condition
	if(this.gfnIsNotNull(objDiv) && this.gfnIsNotNull(this.dsSearchList)) {
		objDiv.form.fnSearchListSetting();

		var searchCellCount = this.dsSearchList.getColCount();
		var searchRowCount  = this.dsSearchList.getRowCount();

		for (var i=0 ; searchRowCount > i ; i++) {
			var obj_Row = {};
			for (var j=0 ; searchCellCount > j ; j++ ) {
				var obj_RowValue = this.dsSearchList.getColumn(i,j);
				var obj_RowInfoId = this.dsSearchList.getColumnInfo(j).id;
				obj_Row[obj_RowInfoId] = obj_RowValue;
			}
			oValue.SEARCHLIST.push(obj_Row);
		}
	}

	//개인정보처리에 필요한 정보
	if(this.gfnIsNotNull(oPsnInfo)) {
		oValue.LIST.PSN_INF_PROC = [];
		oValue.LIST.PSN_INF_PROC.push(oPsnInfo);
	}
	
	var str_JsonData = JSON.stringify(oValue);

	// form Setting
	objForm.setAttribute("method","post");
	objForm.setAttribute("action", sActionUrl);
	document.body.appendChild(objForm);

	objInput1.setAttribute("type","hidden");
	objInput1.setAttribute("name","xlsParam");
	objInput1.setAttribute("value",encodeURIComponent(str_JsonData));

	objForm.appendChild(objInput1);

	objForm.submit();
}

/**
 * @class  File Name Setting
 * @param  {Grid Object} oGridObj
 * @return {String} sFileName
 * @example
 */
pForm.gfnSetFileName = function(oGridObj)
{
	var sFileName = this.getOwnerFrame().titletext;
	if(this.gfnIsNotNull(oGridObj)) {
		// Tab 그리드가 여러개일 경우 파일명에 Tab Title 추가
		if(oGridObj.parent.parent.parent instanceof nexacro.Tab) {
			sFileName += "(" + oGridObj.parent.parent.text + ")";
		}
	}
	
	var sDateTime = this.gfnGetDate("time");
	if(!this.gfnIsNull(sFileName)){
		sFileName = "[" + sFileName + "]_[" + sDateTime.substr(0, 8) + "]_[" + sDateTime.substr(8, 6) + "]";
	}else{
		sFileName = this.gfnGetDate();
	}

	return sFileName;
}

/**
 * @class Excel Download Form
 * @param {Object} objFileDownTransfer
 * @param {Object} oRet
 * @example
 */
pForm.gfnExcelDownloadForm = function(objFileDownTransfer, oRet)
{
	var sOrgFileName = this.gfnSetFileName();
	var sRequestMapping = "/file/excelDownloadForm.do";
	var sUrl = this.gfnGetServerUrl() + this.gfnGetPreUrl(this.SVC.cmm) + sRequestMapping;

	objFileDownTransfer.set_downloadfilename(sOrgFileName);
	objFileDownTransfer.setPostData("EXCEL_FILENAME", encodeURIComponent(sOrgFileName));
	objFileDownTransfer.setPostData("XLS_FOM_ID", oRet.XLS_FOM_ID);
	objFileDownTransfer.setPostData("SHPPRCO_CD", oRet.SHPPRCO_CD);
	
	objFileDownTransfer.set_url(sUrl);

	objFileDownTransfer.download();
}