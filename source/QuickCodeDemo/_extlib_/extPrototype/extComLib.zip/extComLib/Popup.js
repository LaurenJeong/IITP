/**
*  BPO 플랫폼
*  @FileName 	Popup.js 
*  @Creator 	PJY
*  @CreateDate 	2019.06.24
*  @Desction    팝업 관련 함수
************** 소스 수정 이력 ***********************************************
*  date          		Modifier                Description
*******************************************************************************
*  2019.06.24     		PJY		       	      	최초 생성
*  2019.07.30			sepia					공통 팝업 호출 함수 추가
*******************************************************************************
*/
var pForm = nexacro.Form.prototype;

pForm.gvPopCommHeight = 60;		// 공통 표준 추가높이(여백)
pForm.gvPopCommWidth  = 20;		// 공통 표준 추가넓이(여백)
pForm.gvAprvPopOpen   = "N";	// 결재가능 여부

/**
 * @class 결재 상신요청 전용 팝업 오픈 함수(다른 곳에서 사용하지 말 것)
 * @param {String} sPopupId	- 팝업ID
 * @param {String} [oParam] - 전달값
 * @param {String} [sPopupCallback] - 팝업콜백
 * @return N/A
 */
pForm.gfnAprvReqPop = function(sPopupId, oParam, sPopupCallback)
{
	if(this.gfnIsNull(sPopupId) || this.gfnIsNull(oParam)) {
		return;
	}
	
	var sUrl, oOption, sTitle;
	if(sPopupId == "comRequestPop") {
		sUrl    = "pop::COMZZZ070.xfdl";
		oOption = {title:this.gfnGetWord("CFM_REQ"), width:500, height:500};
	} else if(sPopupId == "comApprovePop") {
		sUrl    = "pop::COMZZZ072.xfdl";
		if(oParam["APRV_TYPE"] == "A") {
			sTitle = this.gfnGetWord("CFM");
		} else {
			sTitle = this.gfnGetWord("RTRN");
		}
		oOption = {title:sTitle, width:500, height:500};
	}
	
	this._fnSearchAprvReq(sPopupId, oParam);
	
	if(this.gvAprvPopOpen == "Y") {
		this.gfnPopup(sPopupId, sUrl, oParam, sPopupCallback, oOption);
	} else {
		// 실패를 했을 경우 : N으로 리턴
		return this.gvAprvPopOpen;
	}
};

/**
 * @class 결재 상신요청 전용 조회 함수(다른 곳에서 사용하지 말 것)
 * @param {String} [sPopupId] - Popup ID
 * @param {String} [Param]    - 전달값
 * @return N/A
 */
pForm._fnSearchAprvReq = function(sPopupId, param)
{
	var objDs  = this.gfnGetApplication().gdsTemp;
	var oParam, sSvcId;
	
	if(sPopupId == "comRequestPop") {
		sSvcId = "selectUserAprvStatus";
		oParam = {
			searchId : "com.bpo.com.svc.service.CommonService.selectUserAprvStatus"
		};
	} else if(sPopupId == "comApprovePop") {
		sSvcId = "selectApproveStatus";
		oParam = {
			searchId : "com.bpo.com.svc.service.CommonService.selectApproveStatus"
		};
	}
	
	var sArg  = "";
	    sArg += " MDUL_CD="    + nexacro.wrapQuote(this.gfnIsNullEmpty(param.MDUL_CD));
		sArg += " MNU_ID="     + nexacro.wrapQuote(this.gfnIsNullEmpty(param.MNU_ID));
	if(sPopupId == "comApprovePop") {
		sArg += " CFM_REQ_ID=" + nexacro.wrapQuote(this.gfnIsNullEmpty(param.CFM_REQ_ID));
	}
	
	objDs.clearData();
	
	this.gfnTranCommSearch(sSvcId, oParam, objDs, sArg, "_fnCallback", false);
};

/**
 * @class 결재 상신요청 전용 조회 콜백 함수(다른 곳에서 사용하지 말 것)
 * @param {String} svcID	 - 서비스ID
 * @param {String} errorCode - 에러코드
 * @param {String} errorMsg  - 에러메세지
 * @return N/A
 */
pForm._fnCallback = function(svcID, errorCode, errorMsg)
{
	// 에러 시 화면 처리 내역
	if(errorCode != 0){
		return;
	}
	
	switch(svcID)
	{
		case "selectUserAprvStatus":
			var objDs = this.gfnGetApplication().gdsTemp;
			var sStatus = objDs.getColumn(0, "CFM_ST_CD");
			if(sStatus == "02" || sStatus == "03") {
				//this.gfnAlert("MSG_ADM_EXIST_APRV");//요청이나 진행중인 결재가 존재합니다.
				//this.gvAprvPopOpen = "N";
				this.gvAprvPopOpen = "Y";
			} else {
				this.gvAprvPopOpen = "Y";
			}
			break;
		
		case "selectApproveStatus":
			var objDs = this.gfnGetApplication().gdsTemp;
			var sStatus = objDs.getColumn(0, "CFM_ST_CD");
			if(sStatus != "03") {
				this.gfnAlert("MSG_ADM_NOTPROC_APRV");//결재를 완료했거나 결재순번이 아닙니다.
				this.gvAprvPopOpen = "N";
			} else {
				this.gvAprvPopOpen = "Y";
			}
			break;
	}
};
/**
 * @class 공통 디자인이 적용된 팝업 오픈
 * @param {String} sPopupId	- 팝업ID
 * @param {String} sUrl	 - 팝업URL
 * @param {String} [oParam] - 전달값
 * @param {String} [sPopupCallback] - 팝업콜백
 * @param {Object} [oOption] - 팝업옵션 <br>
 *	oOption.top : 상단 좌표 <br>
 *	oOption.left : 좌측 좌표 <br>
 *	oOption.width : 넓이 <br>
 *	oOption.height : 높이 <br>
 *	oOption.popuptype : 팝업종류(modal:showModal, modeless:application.open, modalsync:showModalSync, modalwindow:showModalWindow) <br>
 *	oOption.layered : 투명 윈도우 <br>
 *	oOption.opacity : 투명도 <br>
 *	oOption.autosize : autosize <br>
  *	oOption.resizable : 리사이즈 가능여부. default:false <br>
 * @return N/A
 */
pForm.gfnPopup = function(sPopupId, sUrl, oParam, sPopupCallback, oOption)
{
	if (this.gfnIsNull(sPopupId)){
		this.gfnLog("[gfnPopup] Popup ID가 없습니다","info");
		return false;
	}
	if (this.gfnIsNull(sUrl)){
		this.gfnLog("[gfnPopup] Url이 없습니다","info");
		return false;
	}
	if (this.gfnIsNull(oOption["title"])){
		this.gfnLog("[gfnPopup] Title이 없습니다","info");
		return false;
	}
	if (this.gfnIsNull(oOption["width"])){
		this.gfnLog("[gfnPopup] Width가 없습니다","info");
		return false;
	}
	if (this.gfnIsNull(oOption["height"])){
		this.gfnLog("[gfnPopup] Height가 없습니다","info");
		return false;
	}
	
	var oArg = {};
	oArg["popupTitle"]	= oOption["title"];
	oArg["popupUrl"]	= sUrl;
	oArg["menuId"] 		= this.gfnGetArgument("menuId");		// 팝업은 부모의 값 그대로 가져감
	oArg["mainId"] 		= this.gfnGetArgument("mainId");		// 팝업은 부모의 값 그대로 가져감
	oArg["scrnId"] 		= this.gfnGetArgument("scrnId");		// 팝업은 부모의 값 그대로 가져감
	oArg["mdulCd"] 		= this.gfnGetArgument("mdulCd");		// 팝업은 부모의 값 그대로 가져감
	
	if (this.gfnIsNull(oOption))			oOption = {};
	oOption["width"]	= parseInt(oOption["width"]) + this.gvPopCommWidth;
	oOption["height"]	= parseInt(oOption["height"]) + this.gvPopCommHeight;
	
	this.gfnOpenPopup(sPopupId,"frm::framePopup.xfdl",oParam,sPopupCallback,oOption,oArg);	
};

/**
 * @class 팝업오픈
 * @param {String} sPopupId	- 팝업ID
 * @param {String} sUrl	 - 팝업URL
 * @param {String} [oParam] - 전달값
 * @param {String} [sPopupCallback] - 팝업콜백
 * @param {Object} [oOption] - 팝업옵션 <br>
 *	oOption.top : 상단 좌표 <br>
 *	oOption.left : 좌측 좌표 <br>
 *	oOption.width : 넓이 <br>
 *	oOption.height : 높이 <br>
 *	oOption.popuptype : 팝업종류(modal:showModal, modeless:application.open, modalsync:showModalSync, modalwindow:showModalWindow) <br>
 *	oOption.layered : 투명 윈도우 <br>
 *	oOption.opacity : 투명도 <br>
 *	oOption.autosize : autosize <br>
  *	oOption.resizable : 리사이즈 가능여부. default:false <br>
 * @param {Object} [oArg] - 개발자들은 사용하지 마세요 <br>
 * @return N/A
 * @example
 * this.gfnOpenPopup(this);
 */
pForm.gfnOpenPopup = function(sPopupId, sUrl, oParam, sPopupCallback, oOption, oArg)
{
    var objApp = pForm.gfnGetApplication();
	var nLeft = -1;
	var nTop = -1;
	var nWidth = -1;
	var nHeight = -1;
	var bShowTitle = false;	
	var bShowStatus = false;	
	var sPopupType = "modal";
	var bLayered = false;
	var nOpacity = 100;
	var bAutoSize = false;
	var bResizable = false;
	var bTopmost = false;

	var sPopupCallback = (this.gfnIsNull(sPopupCallback) && this["fnPopupAfter"]) ? "fnPopupAfter" : sPopupCallback;
	
	// 중복팝업 체크
	var arrPopFrame = nexacro.getPopupFrames();

	if (arrPopFrame[sPopupId]) {	
		if (system.navigatorname == "nexacro") {
			arrPopFrame[sPopupId].setFocus();
		} else {	
			arrPopFrame[sPopupId]._getWindowHandle().focus();
		}
		return;
	}
	
	var sTitleText = "";

	for (var key in oOption) {
       if (oOption.hasOwnProperty(key)) {
            switch (key) {
				case "top":				
					nTop = parseInt(oOption[key]);
					break;
				case "left":
					nLeft = parseInt(oOption[key]);
					break;
				case "width":
					nWidth = parseInt(oOption[key]);
					break;
				case "height":
					nHeight = parseInt(oOption[key]);
					break;
				case "popuptype":
					sPopupType = oOption[key];
					break;
				case "layered":
					bLayered = oOption[key];
					break;
				case "opacity":
					nOpacity = oOption[key];
					break;
				case "autosize":
					bAutoSize = oOption[key];
					break;
				case "titlebar":
					if ("" + oOption[key] == "true") {
						bShowTitle = true;
					}
					break;
				case "title":					
					sTitleText = oOption[key];	
					break;
				case "topmost":		
					bTopmost = oOption[key];
					break;
				case "resizable":		
					bResizable = oOption[key];
					break;
			}	
        }
    }

	var sOpenalign = "";
	if (nLeft == -1 && nTop == -1) {	
		sOpenalign = "center middle";
		
		if (system.navigatorname == "nexacro") {
			var curX = objApp.mainframe.left;
			var curY = objApp.mainframe.top;
		}
        else{
			var curX = window.screenLeft;
			var curY = window.screenTop;
		}
        nLeft =  curX + (objApp.mainframe.width / 2) - Math.round(nWidth / 2);
	    nTop  = curY + (objApp.mainframe.height / 2) - Math.round(nHeight / 2) ;				
		
	} else {
		nLeft =  this.getOffsetLeft() + nLeft;
		nTop =  this.getOffsetTop() + nTop;
	}

	if (nWidth == -1 || nHeight == -1) {
	    bAutoSize = true;
	}
	
	// modeless를 위해 팝업 Type 및 callBack함수 지정
	if (this.gfnIsNull(oArg))			oArg = {};
	if (this.gfnIsNull(oParam))			oParam = {};
	
	oArg["popupType"]		= sPopupType;
	oArg["popupId"]			= sPopupId;
	oArg["callback"]		= sPopupCallback;
	oArg["menuParam"]		= oParam;
	
	// 높이 체크
	var nMaxHeight;
	if (sPopupType == "modeless") {		// 모니터 해상도로 체크
		nMaxHeight = system.getScreenHeight();
	} else {							// 어플리케이션 크기로 체크
		nMaxHeight = objApp.mainframe.height;
	}
	
	nMaxHeight = parseInt(nMaxHeight) - 50;
	
	// 최대해상도보다 큰 경우
	if (nHeight > nMaxHeight) {
		nTop = 0;
		nHeight = nMaxHeight;
		bAutoSize = false;
		sOpenalign = "center top";
	}
	
	var objParentFrame = this.getOwnerFrame();

    if (sPopupType == "modeless") {
        var sOpenStyle= "showtitlebar=" + bShowTitle + " showstatusbar=false showontaskbar=true showcascadetitletext=false resizable=" + bResizable + " autosize=" + bAutoSize + " titletext=" + sTitleText;
		if (bTopmost == true)	sOpenStyle += " topmost=true";
		
		nexacro.open(sPopupId, sUrl, objParentFrame, {"arguments" : oArg}, sOpenStyle, nLeft, nTop, nWidth, nHeight, this);
		
	} else {
		newChild = new nexacro.ChildFrame;
		newChild.init(sPopupId, nLeft, nTop, nWidth, nHeight, null, null, sUrl);
		
		newChild.set_dragmovetype("all");
		newChild.set_showcascadetitletext(false);
		newChild.set_showtitlebar(bShowTitle);    //titlebar는 안보임
        if (bShowTitle) {
            newChild.set_titlebarheight(this.titlebarheight);
        }
		newChild.set_autosize(bAutoSize);	
		newChild.set_resizable(bResizable);    //resizable 안됨
		if (this.gfnIsNotNull(sTitleText)) {
            newChild.set_titletext(sTitleText);
        }
		newChild.set_showstatusbar(bShowStatus);    //statusbar는 안보임
		newChild.set_openalign(sOpenalign);
		newChild.set_layered(bLayered);
		newChild.set_topmost(bTopmost);
		newChild.set_overlaycolor("RGBA(0, 0, 0, 0.2)");
		newChild.showModal(sPopupId, objParentFrame, {"arguments" : oArg}, this, sPopupCallback);
    }
};

/**
 * @description 팝업화면에서 창 닫기
 * @param {Object} objRtn - 팝업 리턴값
 * @return N/A
*/
pForm._popReturn;
pForm.gfnClosePopup = function(objRtn)
{
	var objChild = this.getOwnerFrame().form;
	
	if (objChild == null) {
		return;
	}
	
	var objWorkForm = objChild.fvDivWork;
	
	// 화면 닫기체크
	if (objWorkForm != null) {
	
		// 마지막 컴포넌트 데이터셋  업데이트
		this.gfnUpdateToDataset(objWorkForm.form);
		
		var rtn = true;
		
		if (this.gfnIsNotNull(objChild.lookup("fnCheckClose"))) 
		{
			rtn = objChild.fnCheckClose();
		}
		
		if (rtn == false) {
			this._popReturn = objRtn;
			// (sMsgCd, sTrans, sCallback, sBeforeMsg, sPopupId)
			this.gfnConfirm("MSG_CFM_DATA_CURRENTCLOSE", "", "", "gfnMsgCallback");
			return;
		}
		
	}
	
	this._gfnClosePopup(objRtn);
};

pForm.gfnMsgCallback = function (strId, strVal)
{
	if (strId == "MSG_CFM_DATA_CURRENTCLOSE")	{	// 변경된 데이터가 있습니다. 현재 화면을 닫겠습니까?
		if(strVal == true)
		{
			this._gfnClosePopup(this._popReturn);
		}
	}
};

pForm._gfnClosePopup = function(objRtn)
{
	var objChild = this.getOwnerFrame().form;
	
	if (objChild == null) {
		return;
	}
	
	// modeless 팝업일때 부모창의 callBack 함수 실행
	if (objChild.opener) {		
		
		var sPopupType = this.gfnGetArgument("popupType");
		
		// 팝업이 modeless 일때
		if (sPopupType == "modeless") {
			var sPopupId  = this.gfnGetArgument("popupId");
			var sCallBack = this.gfnGetArgument("callback");

			// callBack 함수가 있을 때
			if (this.gfnIsNull(sCallBack) == false) {	
				if (typeof(sCallBack) == "function") {
					sCallBack.call(this.opener, sPopupId, objRtn);
				}
				else {
					objChild.opener.lookupFunc(sCallBack).call(sPopupId, objRtn);
				}
			}
		}
	}
	
	// 팝업창 닫기
	objChild.close(objRtn);
}

/**
 * 화면에서 debug 창 호출
 * @return    : N/A
 */
pForm.gfnShowDegug = function()
{
	var oArg = {};
	var oOption = {
		popuptype: "modeless"
	  , titlebar:true
	  , title: "디버그"
	  , width: 1080
	  , height:750
	};
	var sPopupCallBack = "";
	
	this.gfnOpenPopup("debugging", "pop::comDebugPop.xfdl", oArg, sPopupCallBack, oOption);
};

/**
* 레포트 출력 함수
* @param {string} sPopId : 팝업ID
* @param {string} sTitle : 팝업 타이틀
* @param {string} sReportPath : OZ레포트 위치
* @param {array} arrDataset : 전달할 데이터셋
* @return N/A
* @example
*/ 
pForm.gfnPopupReport = function(sPopId, sTitle, oParam)
{
	if (this.gfnIsNull(sPopId))					return;
	if (this.gfnIsNull(oParam))					return;
	if (this.gfnIsNull(oParam["reportPath"]))	return;
	
	var arrPopFrame = nexacro.getPopupFrames();

	// 기존에 열려있는 경우 닫고 다시 오픈
	if (arrPopFrame[sPopId]) {	
		arrPopFrame[sPopId].form.close();
	}
	
	var sPopupId	= sPopId;
    var sUrl		= "pop::comOzReportPop.xfdl";
	var sCallBack	= "";
    var oOption		= {title:sTitle, width:900, height:820, popuptype:"modeless"};
	
	this.gfnPopup(sPopupId, sUrl, oParam, sCallBack, oOption);			
};

/**
 * 공통 팝업 호출 함수
 * @return    : N/A
 */ 
pForm.gvPopObj1 = null;
pForm.gvPopObj2 = null;
pForm.gfnPopupCall = function(sPopupId, oParam, sCallBack, object1, object2, arrOptions, sSearchQueryId, sPlamChcYn) {
	
	if(this.gfnIsNull(sCallBack)) {		
		sCallBack = "_gfnPopupAfter";
	}
		
	if(this.gfnIsNull(oParam)) {
		oParam = {};
	}
	
	this.gvPopObj1 = object1;
	this.gvPopObj2 = object2;
	
	var sUrl = "";
	var oOption = "";
	if(sPopupId == "comFileUploadPop") {
		sUrl        = "pop::COMZZZ067.xfdl";
		oOption     = {title:this.gfnGetWord("FL_UPLD_PPUP"), width:500, height:243};
	}else if(sPopupId == "comExcelUploadViewPop") {
		sUrl        = "pop::COMZZZ068.xfdl";
		oOption     = {title:this.gfnGetWord("XLS_UPLD_PPUP"), width:976, height:383};
	}else if(sPopupId == "comExcelUploadDriectPop") {
		sUrl        = "pop::COMZZZ069.xfdl";
		oOption     = {title:this.gfnGetWord("XLS_UPLD_PPUP"), width:283, height:150};	
	}else if(sPopupId.indexOf("com") == 0) {
		//공통코드에서 공통팝업 정보 가져와서 팝업 호출
		var objDs  = this.gfnGetApplication().gdsCommCode;
		var nCnt   = objDs.findRow("CHR_TYP_ATTR_1_VAL", sPopupId);
		var sQuery = objDs.lookup("CHR_TYP_ATTR_1_VAL", sPopupId, "CHR_TYP_ATTR_2_VAL");
		
		if(nCnt >= 0) {
			var sPopNo = "";
			if(this.gfnIsNotNull(objDs.lookup("CHR_TYP_ATTR_1_VAL", sPopupId, "CHR_TYP_ATTR_5_VAL"))) {
				sPopNo = objDs.lookup("CHR_TYP_ATTR_1_VAL", sPopupId, "CHR_TYP_ATTR_5_VAL");
			} else {
				sPopNo = objDs.lookup("CHR_TYP_ATTR_1_VAL", sPopupId, "COMN_CD");
			}
			var sUrl     = "pop::COMZZZ" + sPopNo + ".xfdl";
			var sTitle   = objDs.lookup("CHR_TYP_ATTR_1_VAL", sPopupId, "COMN_CD_NM");
			var nWidth   = objDs.lookup("CHR_TYP_ATTR_1_VAL", sPopupId, "NUM_TYP_ATTR_1_VAL");
			var nHeight  = objDs.lookup("CHR_TYP_ATTR_1_VAL", sPopupId, "NUM_TYP_ATTR_2_VAL");
			var sQryCond = objDs.lookup("CHR_TYP_ATTR_1_VAL", sPopupId, "CHR_TYP_ATTR_4_VAL");
			
			//공통팝업 커스텀 팝업명
			if(this.gfnIsNotNull(oParam.RE_TITLE)) {
				sTitle = this.gfnGetWord(oParam.RE_TITLE);
			} else {
				// comShpprCoByVndrPop(화주사별 거래처 마스터) - VNDR_TPCD에 따라 타이틀 상이 적용
				if(sPopupId == "comShpprCoByVndrPop") {
					var sTemp = "VNDR_TPCD=";
					var nIdx  = oParam.COMN_ETC.indexOf(sTemp);
					
					if(nIdx > -1) {
						var sCode = oParam.COMN_ETC.substr(nIdx + sTemp.length, 2);
						var sReTitle = objDs.lookup("COMN_CD", sPopNo + "-" + sCode, "COMN_CD_NM");
						sTitle = sReTitle;
					}
				}
			}
			
			oOption     = {title:sTitle, width:nWidth, height:nHeight};
			if(this.gfnIsNotNull(sPlamChcYn)) {
				oParam.PLNM_CHC_YN = sPlamChcYn;
			}
			if(this.gfnIsNotNull(sQryCond)) {
				if(this.gfnIsNotNull(oParam.COMN_ETC)) {
					oParam.COMN_ETC += "," + sQryCond;
				} else {
					oParam.COMN_ETC = sQryCond;
				}
			}
		}
	} else {
		if(arrOptions != null && arrOptions.length > 0) {
			sUrl    = arrOptions[0];
			oOption = {title:arrOptions[1], width:Number(arrOptions[2]), height:Number(arrOptions[3])};
		}
	}
	
	this.gfnPopup(sPopupId, sUrl, oParam, sCallBack, oOption);
}

pForm._gfnPopupAfter = function(strId, strVal)
{
	// json Object 리턴
	if (this.gfnIsNotNull(strVal)) {
		var objRet = JSON.parse(strVal);
		var bPlamChc = this.gfnIsNull(objRet[0]);		//단건으로 넘어오는 케이스
		var cnt = Object.keys(objRet).length;
		var code = "";
		var codeNm = "";
				
		if(strId == "comMlangCdPop") {	
			if(bPlamChc) {
				if(this.gfnIsNotNull(this.gvPopObj1)) {
					this.gvPopObj1.set_value(objRet.field1);
				}
				if(this.gfnIsNotNull(this.gvPopObj2)) {
					this.gvPopObj2.set_value(objRet.field2);
				}
			}else {		//다건
				for(var i = 0 ; i < cnt ; i++) {
					code += objRet[i].field1;
					codeNm += objRet[i].field2;
					if(i != (cnt - 1)) {
						code += ",";
						codeNm += ",";
					}
					if(this.gfnIsNotNull(this.gvPopObj1)) {
						this.gvPopObj1.set_value(code);
					}
					if(this.gfnIsNotNull(this.gvPopObj2)) {
						this.gvPopObj2.set_value(codeNm);
					}					
				}
			}
		} else {
			if(bPlamChc) {			
				if(this.gfnIsNotNull(this.gvPopObj1)) {
					this.gvPopObj1.set_value(objRet.COMN_CD);
				}
				if(this.gfnIsNotNull(this.gvPopObj2)) {
					this.gvPopObj2.set_value(objRet.COMN_CD_NM);
				}
			}else {		//다건
				for(var i = 0 ; i < cnt ; i++) {
					code += objRet[i].COMN_CD;
					codeNm += objRet[i].COMN_CD_NM;
					if(i != (cnt - 1)) {
						code += ",";
						codeNm += ",";
					}
				}
				
				if(this.gfnIsNotNull(this.gvPopObj1)) {
					this.gvPopObj1.set_value(code);
				}
				if(this.gfnIsNotNull(this.gvPopObj2)) {
					this.gvPopObj2.set_value(codeNm);
				}				
			}
		}
	}
	
	//포커스 아웃시 fnCntSearch 함수 타는것을 방지
	if(this.gfnIsNotNull(this.gvPopObj1.parent.parent.setFocus)) {
		this.gvPopObj1.parent.parent.setFocus(false, false);
	}
	this.gvPopObj1 = null;
	this.gvPopObj2 = null;
};

pForm.gvBindId1Default = "codeBindItem";
pForm.gvBindId2Default = "nameBindItem";
pForm.gvBindId1 = null;
pForm.gvBindId2 = null;
pForm.gvBindId1No = 0;
pForm.gvBindId2No = 0;
/**
 * @class 공통팝업 Bind Dataset
 * @param {Object} objDiv   - 공통 코드 팝업을 호출한 div ID
 * @param {String} sDsId    - Bind 할 Dataset ID
 * @param {String} sCdColId - Mapping 할 Code Column ID
 * @param {String} sNmColId - Mappgin 할 Name Column ID
 * @return N/A
 * @example
 * this.gfnSetCommPopBindDataset(this.div67.form.div99, "tempDs", "CODE", "NAME");
 */
pForm.gfnSetBindDataset = function(objDiv, sDsId, sCdColId, sNmColId)
{
	//함수가 존재하는지 체크
	if(objDiv.form.lookupFunc("fnSetBindDataset")) {
		objDiv.form.lookupFunc("fnSetBindDataset").call(objDiv, sDsId, sCdColId, sNmColId);
	}
};

/**
 * @class 공통팝업 데이터 리셋
 * @param {Object} objDiv - 공통 코드 팝업을 호출한 div ID
 * @return N/A
 * @example
 * this.gfnSetCommPopData(this.div67);
 */
pForm.gfnSetCommPopReset = function(objDiv)
{
	var objEdtCode = objDiv.form.edtCode;
	
	objEdtCode.set_value("");
	if(this.gfnIsNotNull(objDiv.form.edtName)) {
		var objEdtName = objDiv.form.edtName;
		objEdtName.set_value("");
	}
};

/**
 * @class 공통팝업 데이터 셋팅
 * @param {Object} objDiv - 공통 코드 팝업을 호출한 div ID
 * @param {String} sCode  - 셋팅할 코드 값
 * @param {String} sName  - 셋팅할 네임 값
 * @return N/A
 * @example
 * this.gfnSetCommPopData(this.div67, "XXX1", "XXX2");
 */
pForm.gfnSetCommPopData = function(objDiv, sCode, sName)
{
	var objEdtCode = objDiv.form.edtCode;
	var objEdtName = objDiv.form.edtName;
	
	if(this.gfnIsNotNull(objEdtCode) && this.gfnIsNotNull(sCode)) {
		objEdtCode.set_value(sCode);
	}
	
	if(this.gfnIsNotNull(objEdtName) && this.gfnIsNotNull(sName)) {
		objEdtName.set_value(sName);
	}
	
	//objDiv.form.btnCallPop.setFocus();
};

/**
 * @class 공통팝업 데이터 가져오기
 * @param {Object} objDiv - 공통 코드 팝업을 호출한 div ID
 * @param {String} sType  - 데이터를 가져올 영역(CODE / NAME)
 * @return 코드값 / 이름값
 * @example
 * this.gfnGetCommPopData(this.div67, "CODE");
 */
pForm.gfnGetCommPopData = function(objDiv, sType)
{
	var objEdtCode = objDiv.form.edtCode;
	var objEdtName = objDiv.form.edtName;
	
	if(this.gfnIsNotNull(objEdtCode)) {
		if(sType == "CODE") {
			return objEdtCode.value;
		}
	}
	
	if(this.gfnIsNotNull(objEdtName)) {
		if(sType == "NAME") {
			return objEdtName.value;
		}
	}
};

/**
 * @class 공통팝업 데이터 가져오기
 * @param {Object} objDiv - 공통 코드 팝업을 호출한 div ID
 * @param {String} bVal   - 읽기 전용 여부
 * @return 
 * @example
 * this.gfnGetCommPopData(this.div67, true);
 */
pForm.gfnSetCommPopReadOnly = function(objDiv, bVal)
{
	var bValFalse = "";
	if(bVal) {
		bValFalse = false;
	} else {
		bValFalse = true;
	}
	var objEdtCode = objDiv.form.edtCode;
	var objEdtBtn  = objDiv.form.btnCallPop;
	objEdtCode.set_readonly(bVal);
	objEdtBtn.set_enable(bValFalse)
}

/**
 * @class 공통팝업 커스텀
 * @param {String} sReSrchCond - 공통 팝업 커스텀 조회조건명
 * @param {String} sReGridNm   - 공통 팝업 커스텀 그리드명
 * @return 
 * @example
 * this.gfnCustomePopup(this.div67, true);
 */ 
pForm.gfnCustomePopup = function(sReSrchCond, sReGridNm) {
	//공통 팝업 커스텀 조회조건명
	if (this.gfnIsNotNull(sReSrchCond)) {
		var srchConds = sReSrchCond.split(",");
		var comps = [];
		for(var i = 0 ; i < this.div00.form.components.length ; i++) {
			if(this.gfnIsNotNull(this.div00.form.components[i].form)) {
				var srchComps = this.div00.form.components[i].form.components;
				for(var j = 0 ; j < srchComps.length ; j++) {
					var comp = srchComps[j];
					if(comp instanceof nexacro.Static) {
						if(this.gfnIsNotNull(comp.uWord)) {
							comps.push(comp);
						}
					}
				}
			}
		}
		
		//taborder 순서대로 정렬		
		if(comps.length > 1) {
			comps.sort(function(a,b) {
				return Number(a.taborder) - Number(b.taborder);
			});
		}
		
		for(var i = 0 ; i < srchConds.length ; i++) {
			if(this.gfnIsNotNull(comps[i])) {
				comps[i].uWord = srchConds[i];
			}
		}
		
	}
	
	//공통 팝업 커스텀 그리드명
	if (this.gfnIsNotNull(sReGridNm)) {
		var gridNms = sReGridNm.split(",");
		var grid = this.div02.form.grd00;
		for(var i = 0 ; i < gridNms.length ; i++) {
			if(this.gfnIsNotNull( grid.getCellProperty("Head", i, "subsumtext") )) {
				grid.setCellProperty("Head", i, "subsumtext",gridNms[i]);
			}
		}
	}
	
}