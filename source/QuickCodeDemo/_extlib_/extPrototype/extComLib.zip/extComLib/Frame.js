/**
*  BPO 플랫폼
*  @FileName 	Frame.js 
*  @Creator 	PJY
*  @CreateDate 	2019.06.24
*  @Desction    
************** 소스 수정 이력 ***********************************************
*  date          		Modifier                Description
*******************************************************************************
*  2019.06.24     		PJY       	      		최초 생성
*******************************************************************************
*/

var pForm  = nexacro.Form.prototype;

pForm.titlebarheight = 24;			// 타이틀바 사이즈

pForm.FRAME_MENUCOLUMNS = {
	menuId 		: "MNU_ID",    		// MENU ID
	menuNm 		: "MNU_NM",
	menuUrl 	: "SCRN_PATH",
	scrnId 		: "SCRN_ID",    	// pageId PROGRAM_ID
	moduleCd 	: "MDUL_CD",		// groupId
	menuLevel 	: "LEAF",     		// 메뉴레벨	
    upMenuId    : "UP_MNU_ID",
	menuNavi	: "NAVI",
	winId 		: "WIN_ID",      	// 윈도우(프레임)아이디(열린 메뉴의 윈도우 아이디)
	title 		: "TITLE"
};

/**
 * @class Application 오브젝트를 반환하는 메소드
 * @param  none
 * @return {Object}
 */
pForm.gfnGetApplication = function()
{
	var objApp = nexacro.getApplication();	
	return objApp;
}

/**
 * @class Environment 오브젝트를 반환하는 메소드
 * @param  none
 * @return {Object}
 */
pForm.gfnGetEnvironment = function()
{
	var objEnv = nexacro.getEnvironment();	
	return objEnv;
}

/**
 * @class Profile을 반환하는 메소드
 * @param  none
 * @return {String} 서버구분(loc, dev, tst, prd)
 */
pForm.gfnGetProfile = function()
{
	return nexacro.getApplication().gvServer;
}

/**
 * @class Nexacro browser 여부 확인
 * @return {Boolean} Nexacro browser 여부
 */
pForm.gfnIsNexaBrowser = function()
{
	return (system.navigatorname == "nexacro");
}

/**
 * @class 로그인 처리
 */
pForm.gfnSetLogin = function()
{
	var objApp = nexacro.getApplication();
	
	objApp.gvClosecheck 	= true;

	//URL 연결
	objApp.gvTopFrame.set_formurl("frm::frameTop.xfdl");
	objApp.gvLeftFrame.set_formurl("frm::frameLeft.xfdl");
	objApp.gvMdiFrame.set_formurl("frm::frameMDI.xfdl");
	objApp.gvLoginFrame.set_formurl("");
	
	// 글로벌 변수 설정
	this.gfnSetAppVar();
	
	//컨텍스트 메뉴 다국어 설정
	this.gfnSetContextMenu();
	
	// 최근메뉴
	sKey = "BPO" + this.gfnGetUserInfo("BPO_USR_ID") + "/" + "gdsRecentMenu";
	sXML = this.gfnGetLocalStorage(sKey);
	objApp.gdsRecentMenu.loadXML(sXML);
	
	// 테마설정
	var sThemeCd = this.gfnGetUserInfo("THMA_CD");
	var nRow = objApp.gdsCommCode.findRowExpr("COMN_CD_GRP_CD=='C01092' && COMN_CD=='" + sThemeCd + "'");
	var sThemeNm =this.gfnNvl(objApp.gdsCommCode.getColumn(nRow,"CHR_TYP_ATTR_1_VAL") ,"default");
	nexacro.loadStyle( "xcssrc::theme_" + sThemeNm + ".xcss" );
		
	pForm.gfnSetMain(true);			// 메인화면셋팅
};

/**
 * @class 글로벌 변수 설정
 * @param	{String} sType - "clear" : 변수 초기화, 그외는 gdsUserInfo값으로 글로벌 변수 셋팅
 * @return	N/A
 */
pForm.gfnSetAppVar = function(sType)
{
	var objApp = nexacro.getApplication();
	
	// 변수설정
	objApp.gvServer = this.gfnDecode(sType,"clear","loc",this.gfnGetUserInfo("SYSTEM"));
	objApp.gvBpoUserId = this.gfnDecode(sType,"clear","",this.gfnGetUserInfo("BPO_USR_ID"));
	objApp.gvUserId = this.gfnDecode(sType,"clear","",this.gfnGetUserInfo("USR_ID"));
	objApp.gvUserNm = this.gfnDecode(sType,"clear","",this.gfnGetUserInfo("USR_NM"));
	objApp.gvLanguage = this.gfnDecode(sType,"clear","",this.gfnNvl(this.gfnGetUserInfo("LANG_TPCD"),"ko_KR"));	
	objApp.gvWinMax = this.gfnDecode(sType,"clear","",objApp.gdsTemp.getColumn(0,"OPEN_MDI_CNT"));	
	objApp.gdsTemp.clear();
	
	// 데이터셋 설정
	if (sType == "clear") {
		objApp.gdsUserInfo.clearData();
		objApp.gdsMenu.clearData();
		objApp.gdsOpenMenu.clearData();
		objApp.gdsMyMenu.clearData();
		objApp.gdsCommCode.clearData();
		objApp.gdsGridPersonal.clearData();
		objApp.gdsSrchCondition.clearData();
		objApp.gdsMenuBtn.clearData();
		objApp.gdsRecentMenu.clearData();
		objApp.gdsShppCommCode.clearData();
		objApp.gdsShprHdr.clearData();
		objApp.gdsPsnPrntr.clearData();
	}
};

/**
 * @class 컨텍스트 메뉴 다국어 설정
 * @return	N/A
 */
pForm.gfnSetContextMenu = function() {			  
	var gds = nexacro.getApplication().gdsGridPopupMenu;
	
	gds.set_enableevent(false);
	for(var i = 0 ; i < gds.getRowCount() ; i++) {
		if (this.gfnIsNotNull(gds.getColumn(i,"MLANGID"))) {
			gds.setColumn(i, "CAPTION", this.gfnGetWord(gds.getColumn(i,"MLANGID"))); 		
		}
	}
	gds.set_enableevent(true);
}

/**
 * @class 메인화면으로 이동
 * @param	{Boolean} bInit - Application 시작인지 여부(시작인 경우에는 각 화면 초기화 안함.)
 * @return	N/A
 */
pForm.gfnSetMain = function(bInit)
{
	if (this.gfnIsNull(bInit))			bInit = false;
	
	var objApp = nexacro.getApplication();
	
	objApp.gvFramestat	= "main";
	
	// Layout
	objApp.gvVFrameSet.set_separatesize("0,40,*,10");
	objApp.gvVFrameSet1.set_separatesize("40,*,0");
	
 	if (bInit == false) {
 		objApp.gvMdiFrame.form.fnSetStyle("main");
 	}
	
	objApp.gvMainFrame.set_formurl("frm::frameMain.xfdl");
	objApp.gvMainFrame.form.setFocus();
};

/**
 * @class 서브화면으로 이동
*/
pForm.gfnSetSub = function()
{
	var objApp = nexacro.getApplication();
	
	objApp.gvFramestat	= "sub";
	
	objApp.gvVFrameSet1.set_separatesize("40,0,*");
	
 	objApp.gvMdiFrame.form.fnSetStyle("sub");

	objApp.gvMainFrame.set_formurl("");
};

/**
 * @class Login화면으로 이동(로그아웃처리)
*/
pForm.gfnGoLogin = function()
{
	var objApp = nexacro.getApplication();
	
	if (objApp.gvFramestat == "login")		return;
	
	if (system.navigatorname == "nexacro") {
		
		objApp.gvFramestat	= "login";
		
		// 현재 오픈된 메뉴 저장
		this.gfnSaveOpenMenu();
		
		// 닫을때 체크안함.
		objApp.gvClosecheck = false;
		
		//폼닫기
		try {
			objApp.gvMdiFrame.form.fnCloseAll(false);
		} catch(e){}
		
		// 글로벌 변수 초기화
		this.gfnSetAppVar("clear");
		
		// URL 초기화
		objApp.gvTopFrame.set_formurl("");
		objApp.gvLeftFrame.set_formurl("");
		objApp.gvMdiFrame.set_formurl("");
		objApp.gvMainFrame.set_formurl("");
		objApp.gvLoginFrame.set_formurl("frm::frameLogin.xfdl");
		
		objApp.gvVFrameSet.set_separatesize("*,0,0,0");
		objApp.gvHFrame.set_separatesize("10,*,10");
 	} else {
 		window.top.location.reload(true);
 	}
};

/**
 * @class 폼 초기화 함수
 * @param  {object} objForm - Form 객체
 * @param  {object} objCommBtn - 상단버튼 설정 객체
 * @param  {Number} nMinWidth - 화면기본 넓이. 기본사이즈일때 설정 불필요(기본값:1920)
 * @param  {Number} nMinHeight - 화면기본 높이. 기본사이즈일때 설정 불필요(기본값:652)
 * @return N/A
 * @example	
	this.gfnFormOnLoad(objForm, objCommBtn, nMinWidth, nMinHeight);
 */
pForm.gfnFormOnLoad = function(objForm, objCommBtn, nMinWidth, nMinHeight)
{
	// TODO : 숫자,날짜 나라별 로케일처리 안함.
// 	if (objForm instanceof nexacro.Form) {
// 		this.gfnSetLocale(this);
// 	}
	
	if (objForm.parent.name == "divWork") {
		
		// WorkForm 최소사이즈 설정
		this.gfnSetWorkSize(nMinWidth, nMinHeight);
		
		// 상단 공통버튼 셋팅 - CFM_REQ_ID(승인요청ID)가 존재하지 않을 경우
		if(this.gfnIsNull(this.gfnGetMenuParam("CFM_REQ_ID"))) this.gfnSetCommBtn(objCommBtn);
		
		// 키다운 이벤트 추가
		objForm.addEventHandler("onkeydown", this.gfnOnkeydown, this);
		
		//Menu Log		
		this.fnMenuLog();
	}
	  
	// 팝업 일때 처리
	if (objForm.opener)
	{
		if (objForm.parent instanceof nexacro.ChildFrame)
		{
			// 키다운 이베트 추가
			objForm.addEventHandler("onkeydown", this.gfnOnkeydown, this);
		}
	}

	// QuikView 일때 처리
	if (nexacro.getEnvironmentVariable("evQuikView") == "Y") 
	{
		if (this.gfnIsNull(objForm.opener) && objForm.parent instanceof nexacro.ChildFrame)
		{
			// 키다운 이베트 추가
			objForm.addEventHandler("onkeydown", this.gfnOnkeydown, this);
		}
	}


	// Component 초기화 처리
	this.gfnInitComp(objForm);
	
	// 다국어 처리
	// gfnInitComp()과 같이 호출하면 컴포넌트 갯수만큼 중복 호출되어 gfnInitComp()에서 처리하도록 수정
	//this.gfnInitLang(objForm);	
};

/**
 * TODO 메뉴 권한이 없을경우 처리할 로직 추가 필요(처리방식을 정해야 함)
 * @description Menu Click Log
*/
pForm.fnMenuLog = function()
{
	var sMdulCd = this.gfnGetArgument("mdulCd"); 
	var sMnuId  = this.gfnGetArgument("menuId"); 
	
	var sSvcId	= "menuLog";
	var sSvcUrl	= this.gfnGetPreUrl() + "/common/traceMnuLog.do";
	
	var sArgs  = "";
		sArgs += " MNU_ID=" + nexacro.wrapQuote(sMnuId);
		sArgs += " ONLOAD=" + nexacro.wrapQuote("Y");
	
	var sOutData = "gdsTemp=OUT_CHRG_APRV_LIST";
	
	this.gfnGetApplication().gdsTemp.clear();
	
	this.gfnTransaction(sSvcId, sSvcUrl, "", sOutData, sArgs, "_frameCallback");
};

/**
* @Frame에서 사용하는 전용 Transation Callback <br>
* @param {Object} svcId     - 서비스 ID
* @param {Object} errorCode - 에러코드
* @param {Object} errorMsg  - 에러메세지
* @return N/A
* @example 
*/
pForm._frameCallback = function(svcId, errorCode, errorMsg)
{
	// 에러 시 화면 처리 내역
	if(errorCode != 0){
		return;
	}
	
	switch(svcId)
	{
		case "menuLog":
			// Top Frame 결재목록 카운트
			var objApp = this.gfnGetApplication();
			var objDs  = objApp.gdsTemp;
			var objTop = objApp.gvTopFrame.form;
			
			if(objDs.rowcount > 0) {
				objTop.dsApprove.clearData();
				objTop.dsApprove.copyData(objDs);
				objDs.clear();
				objTop.fnSetApproveCnt();
			}
		break;
	}
};

/**
* @class form open 시 Component 초기화 처리 <br>
* @param {Object} obj - 화면
* @return N/A
* @example 
* this.gfnInitComp(this);
*/
pForm.gfnInitComp = function(objForm)
{
	var arrComp  = objForm.components;
	var nLength  = arrComp.length;
	var sNowLang = nexacro.getApplication().gvLanguage;
	var nUserCnt = this.gfnGetApplication().gdsUserInfo.getRowCount();

	for (var i=0; i<nLength; i++)
	{
		if (arrComp[i] instanceof nexacro.Div)
		{
			// URL로 링크된 경우에는 존재하는 경우에는 해당 링크된 Form Onload에서 처리하도록 한다.
			if (this.gfnIsNull(arrComp[i].url))	{
				this.gfnInitComp(arrComp[i].form);
			}
		}
		else if (arrComp[i] instanceof nexacro.Tab)
		{
			var nPages = arrComp[i].tabpages.length;
			
			for (var j=0; j<nPages;j++)
			{	
				// URL로 링크된 경우에는 존재하는 경우에는 해당 링크된 Form Onload에서 처리하도록 한다.
				if (this.gfnIsNull(arrComp[i].tabpages[j].url))	{
					this.gfnInitComp(arrComp[i].tabpages[j].form);
					
					// 다국어 처리	//TODO sepia 20200219 다국어 처리 
					//if (sNowLang != "ko_KR") {
					if(nUserCnt > 0) {
						this.gfnChangeLang(arrComp[i].tabpages[j]);
					}
					//}
				}
			}
		}
		else
		{	
			// Grid 처리
			if (arrComp[i] instanceof nexacro.Grid) {
			
// 				// 피봇 그리드 제외
// 				if (arrComp[i].name == "grdPivot" || arrComp[i].name == "popGrdItemFilterGrid")	{ continue; }
// 				
				//sepia hotkey 설정을 위한 keydown 설정
				//arrComp[i].addEventHandler("onkeydown", this.gfnOnkeydown, this);				
		
				// commSet이 false인 경우 제외
				if (arrComp[i].commSet == "false")		{ continue; }
					
				this.gfnSetGrid(arrComp[i]);
			}
			
			// 다국어 처리	//TODO sepia 20200219 다국어 처리
			//if (sNowLang != "ko_KR") {
			if(nUserCnt > 0) {
				this.gfnChangeLang(arrComp[i]);
			}
			//}
		}
	}
	
	//TODO sepia 20200219 다국어 처리
	//if (sNowLang != "ko_KR") {
	if(nUserCnt > 0) {
		objForm.resetScroll();
	}
	//}
};

/**
 * @class gfnOpenMenu (frame open) 
* @param  : sMenuId : 화면ID
* @param  : oParam	: 화면에 넘길 파라미터 Object 
* @param  : bReload	: 화면을 리로드 할지 여부
* @return : N/A
* @example :  this.gfnOpenMenu(sMenuId, oParam);
*/
pForm.gfnOpenMenu  = function(sMenuId, oParam, bReload)
{
	var ret = false;
	
	// 팝업에서 부모쪽 제어할때 IE에서 느려지는 제약사항이 있어서 함수 호출 분리함. 
	if (this.gfnIsNull(this.getOwnerFrame().form.opener)) {
		ret = this._gfnOpenMenu(sMenuId, oParam, bReload);
	} else {
		ret = nexacro.getApplication().gvLeftFrame.form._gfnOpenMenu(sMenuId, oParam, bReload);
	}
	
	return ret;
};


pForm._gfnOpenMenu  = function(sMenuId, oParam, bReload)
{
	// Null Check
	if (this.gfnIsNull(sMenuId)){
		this.gfnLog("[gfnOpenMenu] MENU ID가 없습니다","info");
		return false;
	}
	
	var objApp = nexacro.getApplication();
	
	//설정에서 오픈되는 화면갯수 설정
	if (this.gfnIsNull(objApp.gvWinMax)) 
	{
		this.fvWinMax = 10;
	}else {
		this.fvWinMax = objApp.gvWinMax;
	}
	
	if (this.gfnIsNull(bReload)) 		bReload = true;

	var nRow = objApp.gdsMenu.findRow(this.FRAME_MENUCOLUMNS.menuId, sMenuId);

	if (nRow < 0) 
	{
		// 권한이 없습니다.
		this.gfnAlert("MSG_ALT_DATA_NOAUTH");
		return false;
	}

	var sMainMenuId		= this.gfnGetMainMenuId(sMenuId);
	var sMenuUrl		= objApp.gdsMenu.getColumn(nRow, this.FRAME_MENUCOLUMNS.menuUrl);
	
	var sWinId 		= objApp.gdsOpenMenu.lookupAs(this.FRAME_MENUCOLUMNS.menuId, sMainMenuId, this.FRAME_MENUCOLUMNS.winId);
	var sMenuNm		= objApp.gdsOpenMenu.lookupAs(this.FRAME_MENUCOLUMNS.menuId, sMainMenuId, this.FRAME_MENUCOLUMNS.title);
	
	var objForm = objApp.gvWorkFrame.all[sWinId];
	
	// 기존에 오픈된 화면이 있는 경우 처리
	if (objForm != null) {
		if (bReload == true) {		// 리로드(화면에서 오픈)
			// 변경된 데이터가 있는 경우 confirm, 그외는 그냥 reload
			if (this.gfnIsNotNull(objForm.form.fnWorkFrameClose) && objForm.form.fnWorkFrameClose() == false) {
				// 변경된 데이터가 있습니다. 화면을 다시 여시겠습니까?
				this.gfnConfirm("MSG_ALT_DATA_REOPEN",[sMenuNm],"MSG_ALT_DATA_REOPEN" + "^" + sWinId,function(strId, strVal){
					if (strVal) {
						objForm.arguments["menuId"] 	= sMenuId;
						objForm.arguments["menuParam"] 	= oParam;
						objForm.arguments["menuUrl"] 	= sMenuUrl;
						objApp.gvMdiFrame.form.isActiveFrame(sWinId);
						objForm.form.reload();
						return;
					} else {
						objApp.gvMdiFrame.form.isActiveFrame(sWinId);
					}
				});	
				
			} else {
				objForm.arguments["menuId"] 	= sMenuId;
				objForm.arguments["menuParam"] 	= oParam;
				objForm.arguments["menuUrl"] 	= sMenuUrl;
				objApp.gvMdiFrame.form.isActiveFrame(sWinId);
				objForm.form.reload();
			}
		} else {						// 리로드 안함(left메뉴쪽에서 클릭)
			objApp.gvMdiFrame.form.isActiveFrame(sWinId);
		}
		return;
	}
	
	var sModule 	= objApp.gdsMenu.getColumn(nRow, this.FRAME_MENUCOLUMNS.moduleCd);
	var sMenuUrl	= objApp.gdsMenu.getColumn(nRow, this.FRAME_MENUCOLUMNS.menuUrl);
	var sMenuNm		= objApp.gdsMenu.getColumn(nRow, this.FRAME_MENUCOLUMNS.menuNm);
	
	if(this.gfnIsNull(sModule)) 		return;
	if(this.gfnIsNull(sMenuUrl)) 		return;
	if(this.gfnIsNull(sMenuNm)) 		return;
	
	if (objApp.gdsOpenMenu.rowcount >= this.fvWinMax) 
	{
		//this.gfnAlert("MSG_ALT_FUNC_MAXOPEN", [this.fvWinMax]);
		//return false;
		
		// 화면 10개 이상 열렸을 경우 맨처음 열린 Tab 화면 닫고 새로운 화면 여는 로직
		var bRtn  = false;
		var sMsg  = this.gfnGetMessage("MSG_ALT_FUNC_MAXOPEN", [this.fvWinMax]);
		    sMsg += "\n";
			sMsg += this.objApp.gvWorkFrame.frames[0].titletext;
			sMsg += " 화면을(를) 닫고\n";
			sMsg += sMenuNm + " 화면을(를) 오픈하시겠습니까?";
		this.gfnConfirm(sMsg, "", "confirm_screen", function(msg, flag) {
			if(flag == true) {
				var sFstMenuId = this.objApp.gvWorkFrame.frames[0].arguments["menuId"];
				
				if (this.gfnIsNull(sFstMenuId)) return false;
				
				var winid      = this.objApp.gvWorkFrame.frames[0].name;
				var objForm    = this.objApp.gvWorkFrame[winid].form;
				var objMdiForm = this.objApp.gvMdiFrame.form;
				var rtn        = objForm.fnWorkFrameClose(true);
				
				if(rtn == false) {
					this.gfnConfirm("MSG_CFM_DATA_CURRENTCLOSE", "", "MSG_CFM_DATA_CURRENTCLOSE^" + winid, function(inMsg, inFlag) {
						if(inFlag == true) {
							objMdiForm.fnTabOnClose(winid);
							this.gfnNewMdi(objApp.gdsMenu, nRow, oParam, bReload);
						} else {
							bRtn = false;
						}
					});
				} else {
					objMdiForm.fnTabOnClose(winid);
					this.gfnNewMdi(objApp.gdsMenu, nRow, oParam, bReload);
				}
			} else {
				bRtn = false;
			}
		});
		
		return bRtn;
	} else {
		this.gfnNewMdi(objApp.gdsMenu,nRow,oParam, bReload);
	}
	
	return true;
};

/**
 * @class gds_menu의 해당 Row의 정보를 기준으로 신규 윈도우 화면을 생성하고 open 시킴 <br>
 * @param {String} sMenuId - menuId
 * @param {Number} nRow - gds_menu의rowpostion
 * @param {Boolean} bReload	- 화면을 리로드 할지 여부(디폴트 : false)
 * @return N/A
 */
pForm.gfnNewMdi = function(objDs, nRow, oParam, bReload)
{
	var objApp   	= pForm.gfnGetApplication();
	var gdsOpen  	= objApp.gdsOpenMenu;		//열린 dataset

	var sMenuId		= objDs.getColumn(nRow, this.FRAME_MENUCOLUMNS.menuId);
	var sMenuUrl	= objDs.getColumn(nRow, this.FRAME_MENUCOLUMNS.menuUrl);
	var sModule 	= objDs.getColumn(nRow, this.FRAME_MENUCOLUMNS.moduleCd);
	var sMenuNm  	= objDs.getColumn(nRow, this.FRAME_MENUCOLUMNS.menuNm);
	var sMenuPath	= objDs.getColumn(nRow, this.FRAME_MENUCOLUMNS.menuNavi);
	var sScrnId		= objDs.getColumn(nRow, this.FRAME_MENUCOLUMNS.scrnId);
	
	if(this.gfnIsNull(sModule)) return;			//sModule 이 없으면 return
	if(this.gfnIsNull(sMenuUrl)) return;		//pageURl 이 없으면 return
	
	var sMainMenuId		= this.gfnGetMainMenuId(sMenuId);
	var winid    	= "FRAMEWORK_" + sMainMenuId + "_" + gdsOpen.getRowCount() + "_" + parseInt(Math.random() * 1000);
	
	this.gfnSetOpenMenuDs(winid, sMainMenuId, sMenuNm, sMenuUrl, sModule);		// 열린메뉴 화면 삽입
	this.gfnSetRecentMenuDs(sMainMenuId, sMenuNm, sModule);						// 최근메뉴 삽입
	
	var objNewWin = new ChildFrame;
	objNewWin.init(winid, 0, 0, objApp.gvWorkFrame.getOffsetWidth() - 0, objApp.gvWorkFrame.getOffsetHeight() - 0);
	objApp.gvWorkFrame.addChild(winid, objNewWin);

	//objNewWin.set_tooltiptext(winid);
	objNewWin.arguments = [];
	objNewWin.set_background("#f4f4f4");
	objNewWin.set_dragmovetype("all");
	objNewWin.set_showtitlebar(false);
	objNewWin.set_titlebarheight(pForm.titlebarheight);
	objNewWin.set_resizable(true);
	objNewWin.set_openstatus("maximize");
	objNewWin.set_titletext(sMenuNm);
	objNewWin.set_showcascadetitletext(false);
	objNewWin.arguments["winKey"] 		= winid;
	objNewWin.arguments["menuId"] 		= sMenuId;
	objNewWin.arguments["mainId"] 		= sMainMenuId;
	objNewWin.arguments["menuNm"] 		= sMenuNm;
	objNewWin.arguments["menuUrl"] 		= sMenuUrl;
	objNewWin.arguments["scrnId"] 		= sScrnId;
	objNewWin.arguments["menuParam"] 	= oParam;
	objNewWin.arguments["mdulCd"] 		= sModule;
	objNewWin.arguments["menuPath"] 	= sMenuPath;
	
	//TMS인 경우 Webbrowser Component를 이용한 링크기능 이용
	if(sModule == "TMS" || sModule == "PTL" || sModule == "PTC" || sModule == "PTP") {
		objNewWin.set_formurl("frm::frameTms.xfdl");
	} else {
		objNewWin.set_formurl("frm::frameWork.xfdl");
	}

	objApp.gvMdiFrame.form.fnAddTab(winid, sMenuNm);   //mdi tab button add	
	objApp.gvMdiFrame.form.isActiveFrame(winid);
	
	objNewWin.show();
	
	objApp.gvWorkFrame.set_border("0px none");				// 화면 새로 열릴때 WorkFrame 보더 빼기
};

/**
 * @class gfnOpenSubMenu (frame open) 
 * @param  : sMenuId : 화면ID
 * @param  : oParam	: 화면에 넘길 파라미터 Object 
 * @param  : bCloseCheck : fnCheckClose()함수 체크여부
 * @return : N/A
 * @example :  this.gfnOpenMenu(sMenuId, oParam);
*/
pForm.gfnOpenSubMenu  = function(sMenuId, oParam, bCloseCheck)
{
	var objOwnerFrame = this.getOwnerFrame();
	var objForm;
	
	if (this.gfnIsNotNull(objOwnerFrame)) {
		objForm = objOwnerFrame.form;
		objForm.fnOpenSubMenu(sMenuId, oParam, bCloseCheck);
	}
};

/**
 * @description 화면 닫기
*/
pForm.gfnCloseMenu = function(sMenuId,bCloseCheck)
{
	if (this.gfnIsNull(bCloseCheck))		bCloseCheck = true;
	
	var objApp = pForm.gfnGetApplication();
	var sFormId;
	
	if (this.gfnIsNull(sMenuId)) {
		sWinId = this.getOwnerFrame().name;
		sMenuId = objApp.gdsOpenMenu.lookupAs(this.FRAME_MENUCOLUMNS.winId, sWinId, this.FRAME_MENUCOLUMNS.menuId);
	} else {
		sMenuId = this.gfnGetMainMenuId(sMenuId);
	}
	
	var nRow = objApp.gdsOpenMenu.findRow(this.FRAME_MENUCOLUMNS.menuId,sMenuId);
	if (nRow == -1)		return;
	
	objApp.gvMdiFrame.form.fnCloseMenu(sMenuId);
};

/**
 * @class 열린화면 데이터셋에 추가 <br>
 * @param {String} winid : childframe key
 * @param {String} menuId : 메뉴ID
 * @param {String} strTitle : 화면명
 * @param {String} sMenuUrl : 화면 URL
 * @param {String} sModule : 모듈코드
 * @return N/A
 */
pForm.gfnSetOpenMenuDs = function(sWinid, sMenuid, sTitle, sMenuUrl, sModule)
{
	var objApp  = pForm.gfnGetApplication();
	var gdsOpen = objApp.gdsOpenMenu ;  //열린 dataset
	var nRow = gdsOpen.addRow();
	
	gdsOpen.setColumn(nRow, this.FRAME_MENUCOLUMNS.winId, sWinid);
	gdsOpen.setColumn(nRow, this.FRAME_MENUCOLUMNS.menuId, sMenuid);
	gdsOpen.setColumn(nRow, this.FRAME_MENUCOLUMNS.title, sTitle);	
	gdsOpen.setColumn(nRow, this.FRAME_MENUCOLUMNS.menuUrl, sMenuUrl);
	gdsOpen.setColumn(nRow, this.FRAME_MENUCOLUMNS.moduleCd, sModule);
	
};

/**
 * @class 열린메뉴 데이터셋에 삭제 <br>
 * @param {String} winid : childframe key
 * @return N/A
 */
pForm.gfnRemoveOpenMenuDs = function(sWinid)
{
	var objApp = pForm.gfnGetApplication();
	var nRow = objApp.gdsOpenMenu.findRow(this.FRAME_MENUCOLUMNS.winId, sWinid);
	objApp.gdsOpenMenu.deleteRow(nRow);
};

/**
 * @class 최근메뉴(gdsRecentMenu) 데이터셋에 추가 <br>
 * @param {String} menuId : 메뉴ID
 * @param {String} sTitle : 화면명
 * @param {String} sModule : 모듈코드
 * @return N/A
 */
pForm.gfnSetRecentMenuDs = function(sMenuid, sTitle, sModule)
{
	var objApp  = pForm.gfnGetApplication();
	var gdsRecMenu = objApp.gdsRecentMenu;  				// 최근 dataset
	
	var nFRow = gdsRecMenu.findRow(this.FRAME_MENUCOLUMNS.menuId,sMenuid);
	if (nFRow >= 0) {
		gdsRecMenu.moveRow(nFRow,0);
	} else {
		// 최근오픈메뉴 추가
		var nRow = gdsRecMenu.insertRow(0);
		gdsRecMenu.setColumn(nRow, this.FRAME_MENUCOLUMNS.menuId, sMenuid);
		gdsRecMenu.setColumn(nRow, this.FRAME_MENUCOLUMNS.menuNm, sTitle);	
		gdsRecMenu.setColumn(nRow, this.FRAME_MENUCOLUMNS.moduleCd, sModule);
		
		for(var i=gdsRecMenu.rowcount-1; i>=5; i--) {
			gdsRecMenu.deleteRow(i);
		}
	}
	gdsRecMenu.set_rowposition(0);
	
	// 로컬 캐쉬에 저장
	var sKey = "BPO" + this.gfnGetUserInfo("BPO_USR_ID") + "/" + "gdsRecentMenu";
	var sXML = gdsRecMenu.saveXML();
	this.gfnSetLocalStorage(sKey, sXML);
};

/**
 * @description 현재 열린화면을 로컬캐쉬에 저장
*/
pForm.gfnSaveOpenMenu = function()
{
	var objApp  = pForm.gfnGetApplication();
	var gdsOpen = objApp.gdsOpenMenu;
	var arrOpenMenu = new Array();
	
	for(var i=0; i < gdsOpen.rowcount; i++) {
		arrOpenMenu.push(gdsOpen.getColumn(i, pForm.FRAME_MENUCOLUMNS.menuId));
	}
	
	// 로컬 캐쉬에 저장
	var sKey = "BPO" + pForm.gfnGetUserInfo("BPO_USR_ID") + "/" + "openMenu";
	this.gfnSetLocalStorage(sKey, arrOpenMenu.toString());
};

/**
 * @description 각 화면에서 단축키 지정
*/
pForm.gfnOnkeydown = function(obj, e)
{
	//console.log("e.ctrlkey : " + e.ctrlkey + " / e.shiftkey" + e.shiftkey + " / e.keycode : " + e.keycode);
	
	// 디버그 창 : Ctrl + Q
	if (e.ctrlkey && e.keycode == 81) {
		// 운영환경에서는 실행 방지
		if (this.gfnGetProfile() == "prd")		return;
		
		this.gfnShowDegug();
		return true;
	//sepia hotkey		
	}/*else if(e.ctrlkey && e.keycode == 49) {		//ctrl + + 1 그리드 row <-> area 변환		
		if(this.gfnIsNull(obj.getFocus)) {
			return ;
		}
		var gridComp = obj.getFocus();
		if(gridComp instanceof nexacro.Grid) {
			var comps = gridComp.parent.components;
			for(var i = 0 ; i < comps.length ; i++) {
				var comp = comps[i];
				if(comp instanceof nexacro.Div) {
					if (this.gfnIsNotNull(comp.form.rdoSelectType)) {
						comp.set_enableevent(false);
						var value = comp.form.rdoSelectType.value;						
						if(value != "none") {
							if(value == "row") {
								comp.form.rdoSelectType.set_value("multiarea");
								comp.form.fnSetSelectType("multiarea")
							}else if(value == "multiarea") {
								comp.form.rdoSelectType.set_value("row");
								comp.form.fnSetSelectType("select")
							}
						}
						comp.set_enableevent(true);
						break;
					}
				}
			}
		}
	}else if(e.ctrlkey && e.shiftkey && e.keycode == 70) {
		// 전체화면 : ctrl + shift + F
		if(system.navigatorname != "nexacro") {
			var docV = document.documentElement;
			if(docV.requestFullscreen) {
				docV.requestFullscreen();
			} else if(docV.webkitRequestFullscreen) { 	// Chrome, Safari (webkit)
				docV.webkitRequestFullscreen();
			} else if(docV.mozRequestFullScreen) { 		// FilreFox
				docV.mozRequestFullScreen();
			} else if (docV.msRequestFullscreen) { 		// IE or Edge
				docV.msRequestFullscreen();
			}
		}
		
		this.gfnFullScreen(); // 미완성
	// 전체화면 해제 : ctrl + shift + R
	} else if(e.ctrlkey && e.shiftkey && e.keycode == 82) {
		if(system.navigatorname != "nexacro") {
			if (document.exitFullscreen) {
				document.exitFullscreen();
			} else if (document.webkitExitFullscreen) { // Chrome, Safari (webkit)
				document.webkitExitFullscreen();
			} else if (document.mozCancelFullScreen) {	// Firefox
				document.mozCancelFullScreen();
			} else if (document.msExitFullscreen) {		// IE or Edge
				document.msExitFullscreen();
			}
		}
		
		this.gfnRestoreScreen();	// 미완성
	}else if(e.ctrlkey && e.shiftkey && e.keycode == 13) {		//hot key 그리드 행추가(ctrl + shift + enter)	
		if(obj instanceof nexacro.Grid) {
			var comp = this._gfnObjAuthBtn(obj);
			var btn = comp.form.btnBTN_GRID_ROW_ADD;
			if (this.gfnIsNotNull(btn) && btn.staus == "S") {
				btn.click();
			}
		}
	}else if(e.ctrlkey && e.shiftkey && e.keycode == 8) {		//hot key 그리드 행삭제 (ctrl + shift + back space)
		if(obj instanceof nexacro.Grid) {
			var comp = this._gfnObjAuthBtn(obj);
			var btn = comp.form.btnBTN_GRID_ROW_DEL;
			if (this.gfnIsNotNull(btn) && btn.staus == "S") {
				this.gfnDeleteRow(obj.getBindDataset(),obj.getBindDataset().rowposition);
			}
		}
	}else if(e.ctrlkey && e.shiftkey && e.keycode == 32) {		//hot key 그리드 Reset (ctrl + shift + space)
		if(obj instanceof nexacro.Grid) {
			var comp = this._gfnObjAuthBtn(obj);
			var btn = comp.form.btnBTN_GRID_ROW_RESET;
			if (this.gfnIsNotNull(btn) && btn.staus == "S") {
				var objDs = obj.getBindDataset();
				var status = objDs.getColumn(objDs.rowposition, "STATUS");
				if(status != "C") {
					objDs.set_enableevent(false);
					this.gfnResetRow(objDs,objDs.rowposition);		
					objDs.set_enableevent(true);
				}
			}
		}
	}else if(e.ctrlkey && e.shiftkey && (e.keycode == 85 || e.keycode == 117)) {		//hot key 그리드 엑셀업로드 (ctrl + shift + U)
		if(obj instanceof nexacro.Grid) {
			var comp = this._gfnObjAuthBtn(obj);
			var btn = comp.form.btnBTN_GRID_XLS_UP;
			if (this.gfnIsNotNull(btn) && btn.staus == "S") {
				btn.click();
			}
		}
	}else if(e.ctrlkey && e.shiftkey && (e.keycode == 68 || e.keycode == 100)) {		//hot key 그리드 엑셀다운로드 (ctrl + shift + D)
		if(obj instanceof nexacro.Grid) {
			var comp = this._gfnObjAuthBtn(obj);
			var btn = comp.form.btnBTN_GRID_XLS_DN;
			if (this.gfnIsNotNull(btn) && btn.staus == "S") {
				btn.click();
			}
		}
	}*/
	
	/*else if(e.altkey && e.keycode == 77) {
		// Left Menu Focus 단축키 Alt + M
		var objApp       = this.gfnGetApplication();
		var objTopFrame  = objApp.gvTopFrame.form;
		var objMenuBtn   = objTopFrame.btnMenu;
		var sMenuCss     = objMenuBtn.cssclass;
		var objLeftFrame = objApp.gvLeftFrame.form;
		var objMenuGrid  = objLeftFrame.divMenu.form.grdTree;
		var isTreeFocus  = objLeftFrame.isGrdTreeSetForcus;
		
		if(isTreeFocus) {
			if(sMenuCss == "btn_TF_menu") {
				// Menu 닫혀 있는 상태
			} else {
				// Menu 열려 있는 상태
				objTopFrame.btnMenu_onclick(objMenuBtn);
			}
		} else {
			if(sMenuCss == "btn_TF_menu") {
				// Menu 닫혀 있는 상태
				objTopFrame.btnMenu_onclick(objMenuBtn);
			} else {
				// Menu 열려 있는 상태
			}
		}
		sMenuCss = objMenuBtn.cssclass;
		
		if(sMenuCss == "btn_TF_menu") {
			// Menu 닫혀 있는 상태
			objLeftFrame.divMenu_grdTree_onkillfocus(objMenuGrid);
		} else {
			// Menu 열려 있는 상태
			objMenuGrid.setFocus();
			objLeftFrame.divMenu_grdTree_onsetfocus(objMenuGrid);
		}
	} else if(e.altkey && (e.keycode == 49 || e.keycode == 50 || e.keycode == 51 || e.keycode == 52 || e.keycode == 53 || e.keycode == 54 || e.keycode == 55 || e.keycode == 56 || e.keycode == 57 || e.keycode == 48)) {
		var objApp       = this.gfnGetApplication();
		var objLeftFrame = objApp.gvLeftFrame.form;
		var objMenuGrid  = objLeftFrame.divMenu.form.grdTree;
		var objTopFrame  = objApp.gvTopFrame.form;
		var objMenuBtn   = objTopFrame.btnMenu;
		var sMenuCss     = objMenuBtn.cssclass;
		var objButton    = "";
		var objDsMdul    = objLeftFrame.dsModule;
		var nOrder       = 47;
		
		for(var i = 0; i < objDsMdul.rowcount; i++) {
			var strID     = objDsMdul.getColumn(i, this.FRAME_MENUCOLUMNS.moduleCd);
			var sObjId    = "MDUL_" + strID;
			var strButton = "this.gfnGetApplication().gvLeftFrame.form.divMenu.form.divModule.form." + sObjId;
			objButton     = eval(strButton);
			nOrder++;
			
			if(e.keycode == nOrder) {
				if(sMenuCss == "btn_TF_menu") {
					// Menu 닫혀 있는 상태
				} else {
					// Menu 열려 있는 상태
					objLeftFrame.btnTopMenu_onclick(objButton);
					objMenuGrid.setFocus();
					break;
				}
			}
		}
	} else if(e.keycode == 37 || e.keycode == 39) {
		// 왼쪽 방향키(37), 오른쪽 방향키(39)
		var objApp       = this.gfnGetApplication();
		var objLeftFrame = objApp.gvLeftFrame.form;
		var objGrid      = objLeftFrame.divMenu.form.grdTree;
		var isTreeFocus  = objLeftFrame.isGrdTreeSetForcus;
		var nPrevTreeRow = objLeftFrame.nPrevGrdTreeRow;
		var objBindDs    = objGrid.getBindDataset();
		var nCurRow      = objBindDs.rowposition;
		var nTreeRow     = objGrid.getTreeRow(nCurRow);
		var isCallspan   = objGrid.isTreeCollapsedRow(nTreeRow);
		var isExpand     = objGrid.isTreeExpandedRow(nTreeRow);
		var isLeaf       = objGrid.isTreeLeafRow(nTreeRow);
		var nStat        = objGrid.getTreeStatus(nTreeRow)^1;
		
		if(isTreeFocus) {
			if(e.keycode == 37) {
				// 왼쪽 방향키
				if(nStat == 0 || nStat == 2) {
					var isExpand2 = objGrid.isTreeExpandedRow(nTreeRow + 1);
					var isLeaf2   = objGrid.isTreeLeafRow(nTreeRow + 1);
					var nStat2    = objGrid.getTreeStatus(nTreeRow + 1)^1;
					if(!isLeaf2 && isExpand2 && nStat2 == 0 && nPrevTreeRow > 0) {
						objGrid.setTreeStatus(nTreeRow + 1, 0);
						objGrid.selectRow(nTreeRow + 1);
					} else {
						if((!isLeaf && nStat2 == 0 && nPrevTreeRow > 0) || (!isLeaf2 && nStat == 0 && nPrevTreeRow > 0) || (isLeaf && isLeaf2)) {
							objGrid.setTreeStatus(nTreeRow + 1, 0);
							objGrid.selectRow(nTreeRow + 1);
						} else if(nTreeRow == 0 && nStat == 0) {
							objGrid.setTreeStatus(nTreeRow, 0);
							objGrid.selectRow(nTreeRow);
						} else {
							objGrid.setTreeStatus(nTreeRow + 1, 0);
							objGrid.selectRow(nTreeRow + 1);
						}
					}
				} else {
					if(nPrevTreeRow != 0) {
						objGrid.setTreeStatus(nTreeRow + 1, 0);
						objGrid.selectRow(nTreeRow + 1);
					} else {
						objGrid.setTreeStatus(nTreeRow, 0);
						objGrid.selectRow(nTreeRow);
					}
				}
			} else if(e.keycode == 39) {
				// 오른쪽 방향키
				if(nStat == 1) {
					var nStat2    = objGrid.getTreeStatus(nTreeRow - 1)^1;
					var nStat3    = objGrid.getTreeStatus(nTreeRow + 1)^1;
					var nTreeRow2 = nTreeRow - 1;
					var nTreeRow3 = nTreeRow + 1;
					
					if(nStat2 == 1) {
						if(nStat3 >= 0 || nPrevTreeRow == 0) {
							objGrid.setTreeStatus(nTreeRow - 1, 1);
							objGrid.selectRow(nTreeRow - 1);
						} else {
							if(nTreeRow != nPrevTreeRow) {
								objGrid.setTreeStatus(nTreeRow - 1, 1);
								objGrid.selectRow(nTreeRow - 1);
							} else {
								objGrid.setTreeStatus(nTreeRow, 1);
								objGrid.selectRow(nTreeRow);
							}
						}
					} else {
						//if(nStat3 >= 0) {
						if(nPrevTreeRow != nTreeRow) {
							objGrid.setTreeStatus(nTreeRow - 1, 1);
							objGrid.selectRow(nTreeRow - 1);
						} else {
							objGrid.setTreeStatus(nTreeRow, 1);
							objGrid.selectRow(nTreeRow);
						}
					}
				} else {
					if(nPrevTreeRow != nTreeRow) {
						objGrid.setTreeStatus(nTreeRow - 1, 1);
						objGrid.selectRow(nTreeRow - 1);
					} else {
						objGrid.setTreeStatus(nTreeRow, 1);
						objGrid.selectRow(nTreeRow);
					}
				}
			}
		}
	}*/
};

/**
 * @description 그리드 버튼 영역의 component를 반환
*/

pForm._gfnObjAuthBtn = function(obj) {
	var comps = obj.parent.components;
	for(var i = 0 ; i < comps.length ; i++) {
		if(comps[i] instanceof nexacro.Div) {
			if (this.gfnIsNotNull(comps[i].form.components) && this.gfnIsNotNull(comps[i].form.components["divComBtn"])) {
				return comps[i].form.components["divComBtn"];
			}
		}
	}
}

/**
 * @description 메인 메뉴ID반환(서브화면에서 메인 메뉴ID를 얻기위해 사용)
*/
pForm.gfnGetMainMenuId = function(sMenuId)
{
	var objApp = nexacro.getApplication();
	var sMainMenuId = sMenuId;
	var sSubYn, sUpMenuId, sEndYn;
	
	var nFRow 			= objApp.gdsMenu.findRow(this.FRAME_MENUCOLUMNS.menuId, sMenuId);
	
	if (nFRow >= 0) {
		sSubYn			= objApp.gdsMenu.getColumn(nFRow, "HIDN_YN");
		sUpMenuId		= objApp.gdsMenu.getColumn(nFRow, "UP_MNU_ID");
		
		// 부모가 폴더인 경우, HIDN_YN이 "Y"여도 Sub화면이 아님.
		sEndYn			= objApp.gdsMenu.lookup(this.FRAME_MENUCOLUMNS.menuId, sUpMenuId, "END_YN");
		
		if (sSubYn == "Y") {
			if (sEndYn == "N") {			// 폴더
				sMainMenuId = sMenuId;
			} else {
				sMainMenuId = sUpMenuId;
			}
		} else {
			sMainMenuId = sMenuId;
		}
	}
	
	return sMainMenuId;
};

/**
 * @description 화면에 설정된 파라미터객체 반환
*/
pForm.gfnGetArgument = function(sName)
{
	var ret;
	
	try {
		ret = this.getOwnerFrame().arguments[sName];
	} catch(e){}
	
	return ret;
};

pForm.gfnSetArgument = function(sName, value)
{
	try {
		this.getOwnerFrame().arguments[sName] = value;
	} catch(e){}
};

/**
 * @class 화면 파라미터 반환
 * @param  {string} sParamNm - 파라미터명 
 * @return 파라미터값
 * @example	this.gfnGetMenuParam("paramNo");
 */
pForm.gfnGetMenuParam = function(sParamNm)
{	
	var ret;
	
	try {
		var oParam = this.gfnGetArgument("menuParam");
		if (this.gfnIsNull(sParamNm)) {
			ret = oParam;
		} else if (oParam) {
			ret = oParam[sParamNm];
		}
		
	} catch(e){
		this.gfnLog(sParamNm + " 파라미터 객체가가 선언되지 않았습니다.","info");
	}
	
	return ret;
};

pForm.gfnGetUserInfo = function (sKey)
{
	return pForm.gfnGetData("USER_INFO", sKey);
};

pForm.gfnSetUserInfo = function (sKey, sValue)
{
	pForm.gfnSetData("USER_INFO", sKey, sValue);
};

pForm.gfnGetParam = function (sKey)
{
	return pForm.gfnGetData("PARAM", sKey);
};

pForm.gfnSetParam = function (sKey, sValue)
{
	pForm.gfnSetData("PARAM", sKey, sValue);
};

pForm.gfnGetOutput = function (sKey)
{
	return pForm.gfnGetData("OUT", sKey);
};

pForm.gfnSetData = function (sCategory, sKey, sValue)
{
	if (sCategory == null || sKey == null) 
	{
		return;
	}

	switch (sCategory.toUpperCase()) 
	{
		case "PARAM":
			if (!nexacro.getApplication().gdsParam.setColumn(0, sKey, sValue)) 
			{
				nexacro.getApplication().gdsParam.addColumn(sKey, "string");
				if (nexacro.getApplication().gdsParam.getRowCount() == 0) 
				{
					nexacro.getApplication().gdsParam.addRow();
				}
				nexacro.getApplication().gdsParam.setColumn(0, sKey, sValue);
			}
			break;
		case "USERINFO":
		case "USER_INFO":
			if (!nexacro.getApplication().gdsUserInfo.setColumn(0, sKey, sValue)) 
			{
				if (nexacro.getApplication().gdsUserInfo.getRowCount() == 0) 
				{
					nexacro.getApplication().gdsUserInfo.addRow();
				}
				nexacro.getApplication().gdsUserInfo.setColumn(0, sKey, sValue);
			}
			break;
	}
};

pForm.gfnGetData = function (sCategory, sKey)
{
	var returnValue = "";
	if (sCategory == null || sKey == null) 
	{
		return returnValue;
	}

	switch (sCategory.toUpperCase()) 
	{
		case "PARAM":
			returnValue = nexacro.getApplication().gdsParam.getColumn(0, sKey);
			break;
		case "USERINFO":
		case "USER_INFO":
			returnValue = nexacro.getApplication().gdsUserInfo.getColumn(0, sKey);
			break;
		case "OUT":
			returnValue = nexacro.getApplication().gdsOutput.getColumn(0, sKey);
			break;
	}
	return returnValue;
};

/**
 * @class 서버 root URL반환하는 메소드
 * @param  N/A
 * @return {string} 서버 URL
 * @example	
	this.gfnGetServerUrl();
 */
pForm.gfnGetServerUrl = function()
{
	var urlPath = "";
	
    var objEnv = nexacro.getEnvironment();
		urlPath = objEnv.services["svc"].url;
		
	//this.gfnLog("urlPath : " + urlPath);
	return urlPath;
};

/**
 * @class WorkForm 반환함수
 */
pForm.gfnGetWorkForm = function ()
{
	var sQuikView = nexacro.getEnvironmentVariable("evQuikView");
	var objWorkDiv;
	var objWorkForm;
	
	if (sQuikView == "Y") {
		objWorkForm = this.getOwnerFrame().form;
	} else {
		objWorkDiv = this.getOwnerFrame().form["fvDivWork"];
		if (this.gfnIsNotNull(objWorkDiv)) {
			objWorkForm = objWorkDiv.form;
		} else {
			objWorkForm = this.getOwnerFrame().form;
		}
	}
	
	return objWorkForm;
};

/**
 * @class WorkForm 최소사이즈 설정 함수
 */
pForm.gfnSetWorkSize = function (nMinWidth, nMinHeight)
{
	this.getOwnerFrame().form.fnSetWorkSize(nMinWidth, nMinHeight);
};

/**
 * @class 로컬캐쉬값 반환
 * @param  {String}	key	: 구분키값
 * @return 로컬 캐쉬값
 * @example	
	this.gfnGetLocalStorage();
 */
pForm.gfnGetLocalStorage = function (key)
{
	if (system.navigatorname == "nexacro") 
	{
		return nexacro.getPrivateProfile(key);
	}
	else 
	{
		return window.localStorage.getItem(key);
	}
};

/**
 * @class 로컬캐쉬값 설정
 * @param  {String}	key	: 구분키값
 * @param  {String} value : 설정할 값
 * @return N/A
 * @example	
	this.gfnSetLocalStorage();
 */
pForm.gfnSetLocalStorage = function (key, value)
{
	if (system.navigatorname == "nexacro") 
	{
		return nexacro.setPrivateProfile(key, value);
	}
	else 
	{
		return window.localStorage.setItem(key, value);
	}
};

/**
 * @class locale 반환 함수
 */
pForm.gfnGetLocale = function()
{
	var sLocale = this.gfnNvl(this.gfnGetUserInfo("LOCALE"),system.locale);
	return sLocale;
};

/**
 * @class form에 locale 설정 함수
 */
pForm.gfnSetLocale = function (obj)
{
	var sLocale = this.gfnGetLocale();
	obj.set_locale(sLocale);
};

/**
 * @class 화면 상단버튼 설정
 * @param  {Object} objCommBtn - 버튼권한 설정객체 
 *	- 객체명(FUNC_ID)
		. BTN_COM_SAVE : 저장권한
		. BTN_COM_DEL : 삭제권한
		. EXCEL : 엑셀권한
 *	- 객체속성
		. S : Show - 버튼 보이기
		. H : Hide - 버튼 숨기기
		. D : Disable - 버튼 비활성화
 * @return N/A
 * @example	
	var objCommBtn = {
		  BTN_COM_SAVE	: "S"
		, BTN_COM_DEL	: "H"
		, BTN_COM_PRINT	: "D"
	};
	this.gfnSetCommBtn(objCommBtn);
 */
pForm.gfnSetCommBtn = function(objCommBtn)
{
	var objOwnerFrame = this.getOwnerFrame();
	
	if (this.gfnIsNotNull(objOwnerFrame)) {
		objOwnerFrame.form.fnSetCommBtn(objCommBtn);
	}
};

/**
 * @class 메뉴의 권한값 반환 함수
 * @param  {String} sFuncId - 버튼ID
 * @param  {String} sFuncGrp - 버튼그룹ID(디폴트:COM)
 * @return {String} 권한여부(Y/N)
 */
pForm.gfnGetAuth = function (sFuncId, sFuncGrp)
{
	if (this.gfnIsNull(sFuncGrp))		sFuncGrp = "COM";
	
	var objOwnerFrame = this.getOwnerFrame();
	var ret;
	
	if (this.gfnIsNotNull(objOwnerFrame)) {
		ret = objOwnerFrame.form.fnGetAuth(sFuncId, sFuncGrp);
	}
	
	return ret;
};

/**
 * @class 해당 모듈 권한이 있는지 여부
 * @return {Boolean} 모듈 권한이 있는지 여부
 * @example	
	this.gfnIsMdulAdmin();
 */
pForm.gfnIsMdulAdmin = function ()
{
	var sRet = false;
	var sQuikView = nexacro.getEnvironmentVariable("evQuikView");
	var sAdmYn, sMdulArr, sMdulCd;
	
	if (sQuikView == "Y") {
		sRet = true;
	} else {
		sAdmYn		= pForm.gfnNvl(this.gfnGetUserInfo("ADM_YN"),"N");
		
		sMdulCd 	= this.gfnGetArgument("mdulCd");
		
		if (sAdmYn == "Y") {
			if (sMdulCd == "SA10000000") {		// 샘플일때는 모든권한
				sRet = true;
			} else {
				sMdulArr	= this.gfnGetUserInfo("MDUL_ARR");
				
				if (this.gfnIsNotNull(sMdulArr)) {
					var arrMdulArr = sMdulArr.split(",");
					if (pForm.gfnIsExistInArray(arrMdulArr, sMdulCd)) {
						sRet = true;
					}
				}
			}
		}
	}
	return sRet;
};

/**
 * @class 트렌젝션시 "모듈명/메뉴ID" URL반환 함수
 * @param  {String} sModule - 모듈ID
 * @param  {String} sMenuId - 메뉴ID
 * @return {String} 모듈 + "/" + 메뉴ID URL반환
 * @example	
	this.gfnIsMdulAdmin();
 */
pForm.gfnGetPreUrl = function (sModule, sMenuId)
{
	if (this.gfnIsNull(sModule))		sModule = this.gfnGetArgument("mdulCd");
	if (this.gfnIsNull(sMenuId))		sMenuId = this.gfnGetArgument("menuId");
	
	var arrUrl = new Array();
	var sUrl = "";
	
	if (sModule == "SA10000000") {					// 샘플예외처리
		sModule = this.MODULE.cmm;
		sMenuId = "";
	} else if (sModule == pForm.MODULE.fwk) {		// frame에서 쓰는 경우 "cmm"으로 예외처리
		sModule = this.MODULE.cmm;
		sMenuId = "";
	} else if (sModule == pForm.MODULE.cmm) {		// cmm인 경우 모듈 + "cmm"으로 예외처리
		sMenuId = "";
	}
	
	if (this.gfnIsNotNull(sModule)) {
		arrUrl.push(sModule.toLowerCase());
	}
	
	if (this.gfnIsNotNull(sMenuId)) {
		arrUrl.push(sMenuId.toLowerCase());
	}
	
	sUrl = arrUrl.join("/");
	
	return sUrl;
};