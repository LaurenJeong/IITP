/**
*  BPO 플랫폼
*  @FileName 	Transaction.js 
*  @Creator 	PJY
*  @CreateDate 	2019.06.24
*  @Desction    서비스 호출 및 콜백처리
************** 소스 수정 이력 ***********************************************
*  date          		Modifier                Description
*******************************************************************************
*  2019.06.24     		PJY		       	      	최초 생성
*******************************************************************************
*/

var pForm = nexacro.Form.prototype;

// 서비스 모듈CD
pForm.MODULE = {
	  adm : "adm"
	, wms : "wms"
	, oms : "oms"
	, tms : "tms"
	, mdm : "mdm"
	, cms : "cms"
	, ptl : "ptl"
	, bms : "bms"
	, pms : "pms"
	, cmm : "cmm"
	, fwk : "fwk"			/* frame쪽 예외 */
};

// 서비스 메뉴 예외처리용
pForm.SVC = {
	  cmm : "cmm"
	, pop : "pop"
};

/******************************************************************************************************
 * @class 서비스 호출 공통함수 <br>
 * Dataset의 값을 갱신하기 위한 서비스를 호출하고, 트랜젝션이 완료되면 콜백함수을 수행하는 함수
 * @param {String} sSvcId - 서비스 ID
 * @param {String} sSvcUrl - 서비스 호출 Service URL
 * @param {String} [sInDs]	- input Dataset list("입력ID=DataSet ID" 형식으로 설정하며 빈칸으로 구분)
 * @param {String} [sOutDs] - output Dataset list("DataSet ID=출력ID" 형식으로 설정하며 빈칸으로 구분)
 * @param {String} [sArgs]	- 서비스 호출시 Agrgument
 * @param {String} [sCallback] - Callback 함수명
 * @param {Boolean} [bAsync] - 비동기통신 여부 (true : (default) 비동기, false : 동기)
 * @param {Boolean} [bErrMute] - Error 오류 처리 무시 (true : 처리 무시, false : (default) 처리)
 * @param {Boolean} [bLoadingImg] - 로딩 이미지 여부 (true : (default) 보임, false : 숨김)
 * @return N/A
 * @example
 * var sService = "transactionSaveTest.do";
 * var inData    = "dsList=dsList:U";
 * var outData   = "dsList=dsList";
 * var strArg    = "";
 * this.gfnTransaction("save", sService, inData, outData, strArg, "fn_callback", true);
*****************************************************************************************************/ 
pForm.gfnTransaction = function(sSvcId, sService, sInDs, sOutDs, sArgs, sCallback, bAsync, bLoadingImg, bErrMute)
{	
	if (this.gfnIsNull(sSvcId) || this.gfnIsNull(sService))
	{
		trace("Error : gfnTransaction() 함수의 인자값이 부족합니다.");
		return false;
	}
	
	// callback 함수 기본값 설정
	if (pForm.gfnIsNull(sCallback)) {
		sCallback = "fnCallback";
	}
	// Async
	if ((bAsync != true) && (bAsync != false)) {
		bAsync = true;	
	}
	// bErrMute
	if ((bErrMute != true) && (bErrMute != false)) {
		bErrMute = false;	
	}
	// bLoadingImg
	if ((bLoadingImg != true) && (bLoadingImg != false)) {
		bLoadingImg = true;	
	}
	
	var dStartDate = new Date();
	var sStartTime = dStartDate.getTime();
	
	
	// 1. callback에서 처리할 서비스 정보 저장
	var objSvcId = { 
		svcId		: sSvcId
	  , svcUrl    	: sService
	  , callback	: sCallback
	  , isAsync   	: bAsync
	  , loadingImg	: bLoadingImg
	  , errMute		: bErrMute
	  , startTime	: sStartTime
	};

	// 2. strServiceUrl
	var sServiceUrl = "svc::" + sService;
	var sArgument = "";
	var sMenuId = this.gfnGetArgument("menuId");
	
	// 3. sArgs
	if (pForm.gfnIsNotNull(sArgs)) {
		sArgument = sArgs;
	}
	
	// 공통파라미터 설정
	if (pForm.gfnIsNotNull(sMenuId)) {
		sArgument +=  " CMM_MNU_ID="		+ nexacro.wrapQuote(sMenuId);
		sArgument +=  " CMM_SCRN_ID="		+ nexacro.wrapQuote(pForm.gfnIsNullEmpty(this.gfnGetArgument("scrnId")));
		sArgument +=  " CMM_MDUL_CD="		+ nexacro.wrapQuote(pForm.gfnIsNullEmpty(this.gfnGetArgument("mdulCd")));
	}
	
	// 4. nDataType
	var nDataType = 0;
 	var sProfile = pForm.gfnGetProfile();
	
	// 로컬, 개발서버는 xml, 테스트서버/운영서버는 SSV로 통신
 	if (!(sProfile == "loc" || sProfile == "dev")) {
 		nDataType = 2;
 	}	
	
	nDataType = 0;		//20.04.24 sepia, 운영소스도 임시로 XML, 테스트 완료 후 이 부분 삭제
	
	// Loading 이미지 여부
	if (bLoadingImg == false) {
		nexacro.getEnvironment().set_usewaitcursor(false);
	}
	
	var sIngds = "IN_PARAM=gdsParam IN_SEARCHLIST=dsSearchList ";
	sInDs = sIngds + sInDs;
	
	var sOutgds = "gdsOutput=OUT_PARAM ";
	sOutDs = sOutgds + sOutDs;
	
	nexacro.getApplication().gdsOutput.clear();
	
	this.transaction(JSON.stringify(objSvcId)	//1.svcId
					, sServiceUrl             	//2.strSvcUrl
					, sInDs                 	//3.inDataSet
					, sOutDs                	//4.outDataSet
					, sArgument             	//5.arguments
					, "gfnCallback"				//6.sCallback
					, bAsync                   	//7.bAsync
					, nDataType                 //8.nDataType : 0(XML 타입), 1((Binary 타입),  2(SSV 타입) --> HTML5에서는 Binary 타입은 지원안함
					, false);                   //9.bCompress ( default : false ) 
};

/**
 * @class 공통 Callback 함수 <br>
 * 이 함수가 먼저 수행되고 사용자지정Callback함수가 수행된다.
 * @param {String} svcID - 서비스 ID
 * @param {Number} errCd - 에러코드(정상 0, 에러 음수값)
 * @param {String} errMsg - 에러메시지
 * @return N/A
 */
pForm.gfnCallback = function(svcId, errCd, errMsg)
{
	var objSvcId = JSON.parse(svcId);
	
	// loadingImg 처리
	if (objSvcId.loadingImg == false) {
		nexacro.getEnvironment().set_usewaitcursor(true);
	}
	
	// 서비스 실행결과 출력
	var dEndDate = new Date();
	var nElapseTime = (dEndDate.getTime() - objSvcId.startTime) / 1000;
	this.gfnLog("[gfnCallback] SvcId >> " + objSvcId.svcId + ", ElapseTime >> " + nElapseTime + ", ErrCd >> " + errCd + ", ErrMsg >> " + errMsg);
	
	// 에러 공통 처리
	if (errCd != 0 ) {
		if (objSvcId.svcId != "selectSessionInfo") {		// frameLogin화면에서 세션체크용 서비스는 예외처리함.(세션없는 경우 -401이 무조건 넘어옴)
			var objRtn = this.gfnCommSetError(errCd, errMsg, objSvcId.errMute);
			if (objRtn == false)		return;
		}
		
		if(errCd == -4000){		//허용되지 않은 문자열로 검색
			this.gfnAlert(errMsg);
			return ;
		}
	}
	
	// form에 callback 함수가 있을때
	if (this[objSvcId.callback]) {
        this.lookupFunc(objSvcId.callback).call(objSvcId.svcId, errCd, errMsg);
    }
};

/**
 * @class Callback함수에서 서비스 에러를 처리
 * @param {Number} errCd - 에러코드(정상 0, 에러 음수값)
 * @param {String} errMsg - 에러메시지
 * @param {Boolean} errMute - Error 오류 처리 무시 (true : 처리 무시, false : (default) 처리)
 * @param {Boolean} bFile - 파일에서 발생하는 오류인지 여부
 * @return N/A
 */
pForm.gfnCommSetError = function(errCd, errMsg, errMute, bFile)
{
	var bCallback = true;

	if (errCd == 0 || errCd == "0")		return true;
	if (this.gfnIsNull(errCd))			return true;
	if (this.gfnIsNull(errMute))		errMute = false;
	if (this.gfnIsNull(bFile))			bFile = false;
	
	// 파일쪽 에러처리
	if (bFile) {
		if (errCd == "9901") { 
			errCd = -2;
		} else { 
			errCd = -1;
		}
	}
	
	// TODO
	if (errCd == -401) {			// 세션인증 오류
		this.gfnAlert("MSG_ALT_SESN_TIMEOUT", "", "goLogin", "gfnCommonMsgCallback");
		bCallback = false;
	} else if (errCd == -403) {		// 세션인가 오류
		this.gfnAlert("MSG_ALT_DATA_NOAUTH", "", "errAuth", "gfnCommonMsgCallback");
		bCallback = false;
	} else if (errMute == false) {		// errMute가 false일때만 공통에서 alert 띄움
		if (errCd == -1) {				// 시스템오류
			this.gfnAlert("MSG_ERR_PROC_EXCEPTION");
			bCallback = false;
		} else if (errCd == -2) {		// 파일오류
			this.gfnAlert("MSG_ERR_PROC_EXCEPTION");
			bCallback = false;
		} else if (errCd == -9999) {	// 서버오류
			this.gfnAlert("MSG_ALT_FREETEXT",errMsg);
			bCallback = false;
		}
	}
	
	return bCallback;
};

pForm.gfnCommonMsgCallback = function(strId, strVal) {
	if (strId == "goLogin") {
		this.gfnGoLogin();
	} else if(strId == "errAuth") {
		this.gfnGoLogin();
	}
};

/**
 * 오늘날짜 구하는 함수.
 * @return date
 */
pForm.gfnTranToday = function(objDs)
{
	if(this.gfnIsNull(objDs))	objDs = this.gfnGetApplication().gdsTemp;
	
	objDs.clear();
	
	// 오늘날짜 조회
	var oParam = {
			  searchId	: "com.bpo.com.svc.service.CommonService.selectCurrentTime"
			, preurl	: this.gfnGetPreUrl(pForm.MODULE.cmm)
			, bData		: true
		};
	
	this.gfnTranCommSearch("gfnTranToday", oParam, objDs, "", "gfnCommonCallback", false);
};

/**
 * 오늘날짜 구하는 함수.
 * @return date
 */
pForm.gfnGetToday = function()
{
	var ret = this.gfnGetTime();
	
	if (ret != "") {
		ret = ret.substr(0,8);
	}
	return ret;
};

/**
 * 현재시간 구하는 함수.
 * @return date
 */
pForm.gfnGetTime = function()
{
	var ret = "";
	var objDs = this.gfnGetApplication().gdsTemp;
	
	this.gfnTranToday(objDs);
				   
	if (objDs.rowcount > 0)
	{
		ret = objDs.getColumn(0,"CURRENT_TIME");
	}
	else
	{
		this.gfnLog("날짜 조회에 실패했습니다.","error");
	}
	return ret;
};

/******************************************************************************************************
 * @class 공통 조회함수 <br>
 * @param {String} [sSvcId] - 서비스 ID
 * @param {String} [oParam] - 서비스 파라미터
 * @param {String} [sOutDs] - output Dataset
 * @param {String} [sArgs]	- 서비스 호출시 Agrgument
 * @param {String} [sCallback] - Callback 함수명
 * @param {Boolean} [bAsync] - 비동기통신 여부 (true : (default) 비동기, false : 동기)
 * @param {Boolean} [bErrMute] - Error 오류 처리 무시 (true : 처리 무시, false : (default) 처리)
 * @param {Boolean} [bLoadingImg] - 로딩 이미지 여부 (true : (default) 보임, false : 숨김)
 * @return N/A
 * @example
 * var oParam = {
		  searchId		: ""
		, searchCntId	: ""
		, preurl		: ""
	};
 * this.gfnTranCommSearch("search", sService, inData, outData, strArg, "fn_callback", true);
*****************************************************************************************************/ 
pForm.gfnTranCommSearch = function(sSvcId, oParam, oOutDs, sArgs, sCallback, bAsync, bLoadingImg, bErrMute)
{
	if (this.gfnIsNull(sSvcId) || this.gfnIsNull(oParam) || this.gfnIsNull(oOutDs))
	{
		trace("Error : gfnTranCommSearch() 함수의 인자값이 부족합니다.");
		return false;
	}
	
	var bData	    = this.gfnNvl(oParam["bData"],false);
	var sInDsNm	    = this.gfnNvl(oParam["inDs"],"");
	var sInPsnDsNm	= this.gfnNvl(oParam["inPsnDs"],"");
	var sPreUrl	    = this.gfnNvl(oParam["preurl"],this.gfnGetPreUrl());
	
	// 리스트 조회시 서비스명, 리터명
	var sUrl		= "/common/selectCommonList.do";
	var sOutNm		= "OUT_LIST";
	
	// 단건 조회시 서비스명과 리턴데이터셋 명이 다름.
	if (bData == true) {
		sUrl		= "/common/selectCommonDetail.do";
		sOutNm		= "OUT_RETURN_MAP";
	}
	
	var objDs = this.gfnGetApplication().gdsComTran;
	objDs.clear();
	objDs.addColumn("SEARCH_ID", "STRING", 256);
	objDs.addColumn("SEARCH_CNT_ID", "STRING", 256);
	
	var nRow = objDs.addRow();
	objDs.setColumn(nRow,"SEARCH_ID", this.gfnNvl(oParam["searchId"],""));
	objDs.setColumn(nRow,"SEARCH_CNT_ID", this.gfnNvl(oParam["searchCntId"],""));
	
	var sService	= sPreUrl + sUrl;
	var sInDs		= "IN_TRANINFO=gdsComTran";
	if (sInDsNm != "")	sInDs += " IN_SEARCH_PARAM=" + sInDsNm;
	if (sInPsnDsNm != "")	sInDs += " IN_MSK_PARAM=" + sInPsnDsNm;
	var sOutDs		= oOutDs.name + "=" + sOutNm;
	
	this.gfnTransaction(sSvcId, sService, sInDs, sOutDs, sArgs, sCallback, bAsync, bLoadingImg, bErrMute);
};

/******************************************************************************************************
 * @class 공통 저장함수 <br>
 * @param {String} [sSvcId] - 서비스 ID
 * @param {String} [oParam] - 서비스 파라미터
 * @param {String} [sInDs] - in Dataset
 * @param {String} [sArgs] - 서비스 호출시 Agrgument
 * @param {String} [sCallback] - Callback 함수명
 * @param {Boolean} [bAsync] - 비동기통신 여부 (true : (default) 비동기, false : 동기)
 * @param {Boolean} [bErrMute] - Error 오류 처리 무시 (true : 처리 무시, false : (default) 처리)
 * @param {Boolean} [bLoadingImg] - 로딩 이미지 여부 (true : (default) 보임, false : 숨김)
 * @return N/A
 * @example
 * var oParam = {
		  insertId		: ""
		, updateId		: ""
		, deleteId		: ""
		, preurl		: ""
	};
	this.gfnTranCommSearch("search", sService, inData, outData, strArg, "fn_callback", true);
*****************************************************************************************************/ 
pForm.gfnTranCommSave = function(sSvcId, oParam, sInDs, sArgs, sCallback, bAsync, bLoadingImg, bErrMute)
{
	if (this.gfnIsNull(sSvcId) || this.gfnIsNull(oParam) || this.gfnIsNull(sInDs))
	{
		trace("Error : gfnTranCommSave() 함수의 인자값이 부족합니다.");
		return false;
	}
	
	var sInPsnDsNm	= this.gfnNvl(oParam["inPsnDs"],"");
	var sPreUrl	    = this.gfnNvl(oParam["preurl"],this.gfnGetPreUrl());
	
	var objDs = this.gfnGetApplication().gdsComTran;
	objDs.clear();
	objDs.addColumn("INSERT_ID", "STRING", 256);
	objDs.addColumn("UPDATE_ID", "STRING", 256);
	objDs.addColumn("DELETE_ID", "STRING", 256);
	
	var nRow = objDs.addRow();
	objDs.setColumn(nRow,"INSERT_ID", this.gfnNvl(oParam["insertId"],""));
	objDs.setColumn(nRow,"UPDATE_ID", this.gfnNvl(oParam["updateId"],""));
	objDs.setColumn(nRow,"DELETE_ID", this.gfnNvl(oParam["deleteId"],""));
	
	var sService	= sPreUrl + "/common/saveCommon.do";
	var sInDs		= "IN_TRANINFO=gdsComTran IN_LIST=" + sInDs.name + ":U";
	if (sInPsnDsNm != "")	sInDs += " IN_MSK_PARAM=" + sInPsnDsNm;
	var sOutDs		= "";
	
	this.gfnTransaction(sSvcId, sService, sInDs, sOutDs, sArgs, sCallback, bAsync, bLoadingImg, bErrMute);
};

/* Login 화면 전용 Transation - 절대로 다른 화면에서 사용하지 마세요 */
pForm._gfnTranCommSearch = function(sSvcId, oParam, oOutDs, sArgs, sCallback, bAsync, bLoadingImg, bErrMute)
{
	if (this.gfnIsNull(sSvcId) || this.gfnIsNull(oParam) || this.gfnIsNull(oOutDs))
	{
		return false;
	}
	
	var bData	= this.gfnNvl(oParam["bData"],false);
	var sInDsNm	= this.gfnNvl(oParam["inDs"],"");
	var sPreUrl	= this.gfnGetPreUrl(this.MODULE.fwk);//this.gfnNvl(oParam["preurl"],this.gfnGetPreUrl());
	
	// 리스트 조회시 서비스명, 리터명
	var sUrl		= "/entrance/selectCommonList.do";
	var sOutNm		= "OUT_LIST";
	
	// 단건 조회시 서비스명과 리턴데이터셋 명이 다름.
	if (bData == true) {
		sUrl		= "/entrance/selectCommonDetail.do";
		sOutNm		= "OUT_RETURN_MAP";
	}
	
	var objDs = this.gfnGetApplication().gdsComTran;
	objDs.clear();
	objDs.addColumn("SEARCH_ID", "STRING", 256);
	objDs.addColumn("SEARCH_CNT_ID", "STRING", 256);
	
	var nRow = objDs.addRow();
	objDs.setColumn(nRow,"SEARCH_ID", this.gfnNvl(oParam["searchId"],""));
	objDs.setColumn(nRow,"SEARCH_CNT_ID", this.gfnNvl(oParam["searchCntId"],""));
	
	var sService	= sPreUrl + sUrl;
	var sInDs		= "IN_TRANINFO=gdsComTran";
	if (sInDsNm != "")	sInDs += " IN_SEARCH_PARAM=" + sInDsNm;
	var sOutDs		= oOutDs.name + "=" + sOutNm;
	
	this.gfnTransaction(sSvcId, sService, sInDs, sOutDs, sArgs, sCallback, bAsync, bLoadingImg, bErrMute);
};